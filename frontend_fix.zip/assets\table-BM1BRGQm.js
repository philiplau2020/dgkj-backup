import{a as t}from"./entry/index-D3MBwwXl-1778597016356.js";const r=e=>t.get({url:"/table/getDemoList",params:e,headers:{ignoreCancelToken:!0}});export{r as d};

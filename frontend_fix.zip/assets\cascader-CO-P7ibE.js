import{a as r}from"./entry/index-D3MBwwXl-1778597016356.js";const o=a=>r.post({url:"/cascader/getAreaRecord",data:a});export{o as a};

import{a as o}from"./entry/index-D3MBwwXl-1778597016356.js";const s=t=>o.get({url:"/select/getDemoOptions",params:t});export{s as o};

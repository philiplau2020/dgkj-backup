import{a as t}from"./entry/index-D3MBwwXl-1778597016356.js";const e=()=>t.get({url:"/account/getAccountInfo"}),n=()=>t.post({url:"/user/tokenExpired"});export{e as a,n as t};

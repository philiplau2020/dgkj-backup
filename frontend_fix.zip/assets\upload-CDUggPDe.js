import{a as u,e as a}from"./entry/index-D3MBwwXl-1778597016356.js";const{uploadUrl:e=""}=a();function p(o,t){return u.uploadFile({url:e,onUploadProgress:t},o)}export{p as u};

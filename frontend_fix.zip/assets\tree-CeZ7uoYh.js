import{a as e}from"./entry/index-D3MBwwXl-1778597016356.js";const p=t=>e.get({url:"/tree/getDemoOptions",params:t});export{p as t};

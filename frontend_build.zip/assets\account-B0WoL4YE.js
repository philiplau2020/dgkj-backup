import{a as t}from"./entry/index-CsH4vubF-1778657945241.js";const e=()=>t.get({url:"/account/getAccountInfo"}),n=()=>t.post({url:"/user/tokenExpired"});export{e as a,n as t};

import{a as t}from"./entry/index-CsH4vubF-1778657945241.js";const r=e=>t.get({url:"/table/getDemoList",params:e,headers:{ignoreCancelToken:!0}});export{r as d};

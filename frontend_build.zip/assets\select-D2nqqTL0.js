import{a as o}from"./entry/index-CsH4vubF-1778657945241.js";const s=t=>o.get({url:"/select/getDemoOptions",params:t});export{s as o};

import{a as u,e as a}from"./entry/index-CsH4vubF-1778657945241.js";const{uploadUrl:e=""}=a();function p(o,t){return u.uploadFile({url:e,onUploadProgress:t},o)}export{p as u};

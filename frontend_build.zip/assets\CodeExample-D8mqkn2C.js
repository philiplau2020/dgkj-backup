import{bT as P,am as x,bU as j,as as w,at as _,Q as B,B as h,an as y,j as U}from"./antd-COE7FMLH.js";import{d as I,f as H,Z as u,_ as k,k as o,u as t,a9 as l,F as z,aa as G,a8 as O,$ as e,G as L,a0 as i,ab as J,a2 as R,a3 as A}from"./vue-D3PsneZf.js";import{_ as V}from"./entry/index-CsH4vubF-1778657945241.js";const r=b=>(R("data-v-a4a2e587"),b=b(),A(),b),K={class:"code-example"},M={key:0},D={class:"example-section"},F={class:"example-info"},Q={class:"example-url"},X={key:0,class:"example-headers"},Z=r(()=>e("h5",null,"请求头",-1)),W={class:"code-block dark"},Y={key:1,class:"example-body"},ee=r(()=>e("h5",null,"请求体",-1)),se={class:"code-block dark"},te={class:"code-header"},oe=r(()=>e("span",{class:"code-lang"},"JSON",-1)),ne={class:"example-section"},ae={class:"code-block dark"},le={class:"code-header"},ce=r(()=>e("span",{class:"code-lang"},"JSON",-1)),de={class:"example-section"},ie={class:"code-block dark"},re={class:"code-header"},ue=r(()=>e("span",{class:"code-lang"},"Bash",-1)),pe={class:"code-block dark"},_e={class:"code-header"},he=r(()=>e("span",{class:"code-lang"},"Java",-1)),ye={class:"code-block dark"},be={class:"code-header"},ve=r(()=>e("span",{class:"code-lang"},"PHP",-1)),ke={class:"example-section"},fe={class:"code-block dark"},$e={class:"code-header"},me=r(()=>e("span",{class:"code-lang"},"Python",-1)),Ce=I({__name:"CodeExample",props:{examples:{},baseUrl:{default:"/api/v1"}},setup(b){const f=b,C=H([0]),E={GET:"green",POST:"blue",PUT:"orange",DELETE:"red"};function $(n){return JSON.stringify(n,null,2)}function p(n){const d=typeof n=="string"?n:JSON.stringify(n,null,2);navigator.clipboard.writeText(d),U.success("已复制到剪贴板")}function g(n){const{method:d="GET",url:s,headers:a,body:c}=n.request;let v=`curl -X ${d} '${f.baseUrl}${s}'`;if(a)for(const[m,N]of Object.entries(a))v+=` \\
  -H '${m}: ${N}'`;return c&&(v+=` \\
  -H 'Content-Type: application/json' \\
  -d '${JSON.stringify(c)}'`),v}function q(n){const{method:d="GET",url:s,body:a}=n.request,c=d.toLowerCase(),v=a?`String body = "${JSON.stringify(a).replace(/"/g,'\\"')}";`:"",m=a?`
    .body(RequestBody.create(body, MediaType.APPLICATION_JSON))`:"";return`import okhttp3.*;
import java.io.IOException;

public class ApiExample {
    public static void main(String[] args) throws IOException {
        OkHttpClient client = new OkHttpClient();
        ${v}
        
        Request request = new Request.Builder()
            .url("${f.baseUrl}${s}")
            .${c}()${m}
            .addHeader("Content-Type", "application/json")
            .build();
        
        try (Response response = client.newCall(request).execute()) {
            System.out.println(response.body().string());
        }
    }
}`}function T(n){const{method:d="GET",url:s,body:a}=n.request,c=a?`
$data = '${JSON.stringify(a)}';
$options['http']['content'] = $data;`:"";return`<?php
$url = '${f.baseUrl}${s}';${c}

$context = stream_context_create($options);
$result = file_get_contents($url, false, $context);

echo $result;
`}function S(n){const{method:d="GET",url:s,body:a}=n.request;return`import requests
import json
${a?`
data = ${JSON.stringify(a,null,4)}`:""}

url = '${f.baseUrl}${s}'
headers = {
    'Content-Type': 'application/json'
}

response = requests.${d.toLowerCase()}(url, headers=headers${a?", json=data":""})
print(response.json())
`}return(n,d)=>(u(),k("div",K,[n.examples&&n.examples.length>0?(u(),k("div",M,[o(t(P),{activeKey:C.value,"onUpdate:activeKey":d[0]||(d[0]=s=>C.value=s),bordered:!1},{default:l(()=>[(u(!0),k(z,null,G(n.examples,(s,a)=>(u(),O(t(j),{key:a,header:s.title||`示例 ${a+1}`},{default:l(()=>[o(t(w),null,{default:l(()=>[o(t(_),{key:"request",tab:"请求"},{default:l(()=>[e("div",D,[e("div",F,[o(t(B),{color:E[s.request.method]},{default:l(()=>[L(i(s.request.method),1)]),_:2},1032,["color"]),e("code",Q,i(n.baseUrl)+i(s.request.url),1)]),s.request.headers?(u(),k("div",X,[Z,e("div",W,[e("pre",null,[e("code",null,i($(s.request.headers)),1)])])])):J("",!0),s.request.body?(u(),k("div",Y,[ee,e("div",se,[e("div",te,[oe,o(t(h),{size:"small",type:"text",onClick:c=>p(s.request.body)},{icon:l(()=>[o(t(y))]),_:2},1032,["onClick"])]),e("pre",null,[e("code",null,i($(s.request.body)),1)])])])):J("",!0)])]),_:2},1024),o(t(_),{key:"response",tab:"响应"},{default:l(()=>[e("div",ne,[e("div",ae,[e("div",le,[ce,o(t(h),{size:"small",type:"text",onClick:c=>p(s.response)},{icon:l(()=>[o(t(y))]),_:2},1032,["onClick"])]),e("pre",null,[e("code",null,i($(s.response)),1)])])])]),_:2},1024),o(t(_),{key:"curl",tab:"cURL"},{default:l(()=>[e("div",de,[e("div",ie,[e("div",re,[ue,o(t(h),{size:"small",type:"text",onClick:c=>p(g(s))},{icon:l(()=>[o(t(y))]),_:2},1032,["onClick"])]),e("pre",null,[e("code",null,i(g(s)),1)])])])]),_:2},1024),o(t(_),{key:"java",tab:"Java"},{default:l(()=>[e("div",pe,[e("div",_e,[he,o(t(h),{size:"small",type:"text",onClick:c=>p(q(s))},{icon:l(()=>[o(t(y))]),_:2},1032,["onClick"])]),e("pre",null,[e("code",null,i(q(s)),1)])])]),_:2},1024),o(t(_),{key:"php",tab:"PHP"},{default:l(()=>[e("div",ye,[e("div",be,[ve,o(t(h),{size:"small",type:"text",onClick:c=>p(T(s))},{icon:l(()=>[o(t(y))]),_:2},1032,["onClick"])]),e("pre",null,[e("code",null,i(T(s)),1)])])]),_:2},1024),o(t(_),{key:"python",tab:"Python"},{default:l(()=>[e("div",ke,[e("div",fe,[e("div",$e,[me,o(t(h),{size:"small",type:"text",onClick:c=>p(S(s))},{icon:l(()=>[o(t(y))]),_:2},1032,["onClick"])]),e("pre",null,[e("code",null,i(S(s)),1)])])])]),_:2},1024)]),_:2},1024)]),_:2},1032,["header"]))),128))]),_:1},8,["activeKey"])])):(u(),O(t(x),{key:1,message:"暂无示例",type:"info","show-icon":""}))]))}}),Se=V(Ce,[["__scopeId","data-v-a4a2e587"]]);export{Se as default};

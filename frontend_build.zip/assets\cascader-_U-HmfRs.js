import{a as r}from"./entry/index-CsH4vubF-1778657945241.js";const o=a=>r.post({url:"/cascader/getAreaRecord",data:a});export{o as a};

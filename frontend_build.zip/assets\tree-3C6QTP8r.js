import{a as e}from"./entry/index-CsH4vubF-1778657945241.js";const p=t=>e.get({url:"/tree/getDemoOptions",params:t});export{p as t};

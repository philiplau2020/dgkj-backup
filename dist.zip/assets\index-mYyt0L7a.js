var se=Object.defineProperty,pe=Object.defineProperties;var ne=Object.getOwnPropertyDescriptors;var I=Object.getOwnPropertySymbols;var re=Object.prototype.hasOwnProperty,ue=Object.prototype.propertyIsEnumerable;var K=(u,p,n)=>p in u?se(u,p,{enumerable:!0,configurable:!0,writable:!0,value:n}):u[p]=n,U=(u,p)=>{for(var n in p||(p={}))re.call(p,n)&&K(u,n,p[n]);if(I)for(var n of I(p))ue.call(p,n)&&K(u,n,p[n]);return u},B=(u,p)=>pe(u,ne(p));var E=(u,p,n)=>new Promise((S,g)=>{var x=v=>{try{m(n.next(v))}catch(O){g(O)}},c=v=>{try{m(n.throw(v))}catch(O){g(O)}},m=v=>v.done?S(v.value):Promise.resolve(v.value).then(x,c);m((n=n.apply(u,p)).next())});import{X as w,Y as h,Z as j,$ as y,a0 as T,a1 as d,W as q,E as k,bQ as J,B as A,a2 as ie,bV as de,Q as M,a9 as ce,aa as R,al as z,bx as ve,bP as D,ak as fe,j as b}from"./antd-JXlm2PCC.js";import{d as me,f as C,r as F,o as ye,Z as $,_ as V,k as e,a9 as t,u as a,G as o,$ as f,a0 as N,ab as xe,a1 as _e,a2 as Se,a3 as ge}from"./vue-BgPDgpOs.js";import{_ as Oe}from"./entry/index-D9YMi87w-1778590413429.js";const P=u=>(Se("data-v-406a0f1b"),u=u(),ge(),u),Te={class:"api-debug"},Ae={class:"auth-section"},be=P(()=>f("h4",null,"认证参数",-1)),we={class:"params-section"},Ce=P(()=>f("h4",null,"请求参数 (JSON)",-1)),Ne={class:"response-section"},Pe=P(()=>f("h4",null,"响应结果",-1)),he={key:0,class:"response-meta"},ke=P(()=>f("h4",null,"HMAC-SHA256 签名流程",-1)),De=P(()=>f("h4",null,"发起支付接口签名",-1)),Ee=P(()=>f("code",null,"https://sandbox-api.dgkjpay.com",-1)),Me=`输入参数:
{
  "appKey": "DGKJxxx",
  "timestamp": "20260512000000",
  "mchNo": "Mxxx",
  "orderNo": "ORD001"
}

Step 1: 过滤空值和 sign 参数
Step 2: 按字典序排序
Step 3: 拼接
appKey=DGKJxxx&mchNo=Mxxx&orderNo=ORD001&timestamp=20260512000000

Step 4: HMAC-SHA256(AppSecret="your_secret")
= hex(hmac_sha256("appKey=DGKJxxx&mchNo=Mxxx&...", "your_secret"))

Step 5: 转大写
= 7B2C3D4E5F6A7B8C9D0E1F2A3B4C5D6E7F8A9B0C1D2E3F4A5B6C7D8E9F0A1B2`,Z=`// Node.js HMAC-SHA256 签名示例
const crypto = require('crypto');

function sign(params, appSecret) {
  const sorted = Object.keys(params)
    .filter(k => k !== 'sign' && params[k] !== undefined && params[k] !== '')
    .sort()
    .map(k => \`\${k}=\${params[k]}\`)
    .join('&');
  return crypto.createHmac('sha256', appSecret)
    .update(sorted)
    .digest('hex')
    .toUpperCase();
}

// 发起支付的签名参数
const params = {
  appKey: 'DGKJxxx',
  timestamp: '20260512000000',
  mchNo: 'Mxxx',
  appId: 'APPxxx',
  payType: 'wx_native',
  amount: 100,
  subject: '商品标题',
  orderNo: 'ORD20260512001',
  notifyUrl: 'https://example.com/notify'
};

const signature = sign(params, 'your_app_secret');
// 结果: 7B2C3D4E5F6A7B8C9D0E1F2A3B4C5D6E7F8A9B0...`,Ge=me({__name:"index",setup(u){const p=C(""),n=C(!1),S=C(""),g=C(""),x=C(null),c=F({appKey:"",appSecret:"",signType:"HMAC-SHA256",timestamp:new Date().toISOString().replace(/[-:T.Z]/g,"").slice(0,14)}),m=F({secret:"",algorithm:"HMAC-SHA256",params:'{"appKey": "DGKJxxx", "timestamp": "20260512000000", "mchNo": "Mxxx", "payType": "wx_native", "amount": 100, "subject": "测试商品", "orderNo": "ORD001", "notifyUrl": "https://example.com/notify"}'}),v=C(""),O={"POST|/api/v1/pay/gateway":`{
  "mchNo": "Mxxx",
  "appId": "APPxxx",
  "payType": "wx_native",
  "amount": 100,
  "subject": "测试商品",
  "orderNo": "ORD20260512001",
  "notifyUrl": "https://example.com/notify",
  "clientIp": "1.2.3.4",
  "attach": "测试订单"
}`,"POST|/api/v1/refund/apply":`{
  "orderNo": "OPxxx",
  "refundAmount": 100,
  "refundReason": "用户取消订单"
}`,"POST|/api/v1/transfer/pay":`{
  "outNo": "T20260512001",
  "amount": 10000,
  "accountType": "bank_card",
  "accountName": "张三",
  "accountNo": "6222021234567890",
  "bankName": "中国工商银行",
  "remark": "佣金发放"
}`};function G(){c.timestamp=new Date().toISOString().replace(/[-:T.Z]/g,"").slice(0,14)}function Q(){O[p.value]&&(S.value=O[p.value])}function W(){O[p.value]?(S.value=O[p.value],b.success("示例已加载")):b.info("该接口暂无示例")}function X(){return E(this,null,function*(){try{const i=JSON.parse(S.value||"{}"),l=B(U({},i),{appKey:c.appKey,timestamp:c.timestamp}),s=require?window.crypto:null,r=Object.keys(l).filter(_=>l[_]!==void 0&&l[_]!=="").sort().map(_=>`${_}=${l[_]}`).join("&");if(typeof s!="undefined"){const _=new TextEncoder,ae=yield s.subtle.importKey("raw",_.encode(c.appSecret),{name:"HMAC",hash:"SHA-256"},!1,["sign"]),te=yield s.subtle.sign("HMAC",ae,_.encode(r)),le=Array.from(new Uint8Array(te)).map(oe=>oe.toString(16).padStart(2,"0")).join("").toUpperCase();v.value=le,b.success("签名已计算，请复制到请求头")}else v.value="需在浏览器环境计算"}catch(i){b.error("签名计算失败: "+i.message)}})}function Y(){return E(this,null,function*(){if(!p.value){b.warning("请先选择接口");return}n.value=!0;const[i,l]=p.value.split("|"),s=Date.now();try{yield new Promise(_=>setTimeout(_,500+Math.random()*500));const r=L(l);g.value=JSON.stringify(r,null,2),x.value={code:r.code,status:200,time:Date.now()-s,size:new Blob([g.value]).size}}catch(r){g.value=JSON.stringify({code:"OP9001",message:r.message},null,2),x.value={code:"OP9001",status:500,time:Date.now()-s,size:0}}finally{n.value=!1}})}function L(i){return{"/api/v1/dev/login":{code:"OP0000",message:"操作成功",data:{developerId:"DEVxxx",developerName:"测试开发者",token:"mock_token_xxx",level:"trial",status:"active"}},"/api/v1/pay/gateway":{code:"OP0000",message:"操作成功",data:{orderNo:"OP"+Date.now().toString(36).toUpperCase(),payUrl:"weixin://wxpay/bizpayurl?pr="+Date.now(),qrCode:"https://api.dgkjpay.com/qr/"+Date.now(),amount:100,status:"pending",expireTime:new Date(Date.now()+72e5).toISOString()}},"/api/v1/query/order/:orderNo":{code:"OP0000",data:{orderNo:"OPxxx",mchNo:"Mxxx",payType:"wx_native",amount:100,status:"paid",paidTime:new Date().toISOString()}},"/api/v1/refund/apply":{code:"OP0000",data:{refundNo:"RF"+Date.now().toString(36).toUpperCase(),orderNo:"OPxxx",refundAmount:100,status:"pending"}}}[i]||{code:"OP0000",message:"操作成功",data:{success:!0,message:"Mock 响应"}}}function ee(){try{const i=JSON.parse(m.params),l=Object.keys(i).filter(s=>i[s]!==void 0&&i[s]!=="").sort().map(s=>`${s}=${i[s]}`).join("&");v.value="[使用浏览器 Web Crypto API 计算]"+l.slice(0,50)+"...",b.info("请在浏览器控制台使用 crypto.subtle 计算实际签名")}catch(i){b.error("参数 JSON 格式错误")}}function H(i){i&&navigator.clipboard.writeText(i).then(()=>b.success("已复制"))}return ye(()=>G()),(i,l)=>($(),V("div",Te,[e(a(q),{gutter:24},{default:t(()=>[e(a(w),{span:14},{default:t(()=>[e(a(h),{title:"API 在线调试",class:"tester-card"},{default:t(()=>{var s;return[e(a(j),{layout:"vertical"},{default:t(()=>[e(a(y),{label:"选择接口"},{default:t(()=>[e(a(T),{value:p.value,"onUpdate:value":l[0]||(l[0]=r=>p.value=r),style:{width:"100%"},size:"large",onChange:Q},{default:t(()=>[e(a(T).OptGroup,{label:"开发者接口"},{default:t(()=>[e(a(d),{value:"POST|/api/v1/dev/register"},{default:t(()=>[o("POST /api/v1/dev/register - 注册")]),_:1}),e(a(d),{value:"POST|/api/v1/dev/login"},{default:t(()=>[o("POST /api/v1/dev/login - 登录")]),_:1}),e(a(d),{value:"GET|/api/v1/dev/info"},{default:t(()=>[o("GET /api/v1/dev/info - 开发者信息")]),_:1})]),_:1}),e(a(T).OptGroup,{label:"应用管理"},{default:t(()=>[e(a(d),{value:"POST|/api/v1/app"},{default:t(()=>[o("POST /api/v1/app - 创建应用")]),_:1}),e(a(d),{value:"GET|/api/v1/app/list"},{default:t(()=>[o("GET /api/v1/app/list - 应用列表")]),_:1}),e(a(d),{value:"GET|/api/v1/app/:appId"},{default:t(()=>[o("GET /api/v1/app/:appId - 应用详情")]),_:1})]),_:1}),e(a(T).OptGroup,{label:"支付接口"},{default:t(()=>[e(a(d),{value:"POST|/api/v1/pay/gateway"},{default:t(()=>[o("POST /api/v1/pay/gateway - 发起支付")]),_:1}),e(a(d),{value:"GET|/api/v1/query/order/:orderNo"},{default:t(()=>[o("GET /api/v1/query/order/:orderNo - 查询订单")]),_:1}),e(a(d),{value:"POST|/api/v1/order/:orderNo/close"},{default:t(()=>[o("POST /api/v1/order/:orderNo/close - 关闭订单")]),_:1})]),_:1}),e(a(T).OptGroup,{label:"退款接口"},{default:t(()=>[e(a(d),{value:"POST|/api/v1/refund/apply"},{default:t(()=>[o("POST /api/v1/refund/apply - 申请退款")]),_:1}),e(a(d),{value:"GET|/api/v1/query/refund/:refundNo"},{default:t(()=>[o("GET /api/v1/query/refund/:refundNo - 查询退款")]),_:1})]),_:1}),e(a(T).OptGroup,{label:"转账接口"},{default:t(()=>[e(a(d),{value:"POST|/api/v1/transfer/pay"},{default:t(()=>[o("POST /api/v1/transfer/pay - 发起转账")]),_:1}),e(a(d),{value:"GET|/api/v1/query/transfer/:transferNo"},{default:t(()=>[o("GET /api/v1/query/transfer/:transferNo - 查询转账")]),_:1})]),_:1}),e(a(T).OptGroup,{label:"账户接口"},{default:t(()=>[e(a(d),{value:"GET|/api/v1/account/balance"},{default:t(()=>[o("GET /api/v1/account/balance - 查询余额")]),_:1})]),_:1})]),_:1},8,["value"])]),_:1}),f("div",Ae,[be,e(a(q),{gutter:12},{default:t(()=>[e(a(w),{span:12},{default:t(()=>[e(a(y),{label:"AppKey"},{default:t(()=>[e(a(k),{value:c.appKey,"onUpdate:value":l[1]||(l[1]=r=>c.appKey=r),placeholder:"DGKJxxx"},null,8,["value"])]),_:1})]),_:1}),e(a(w),{span:12},{default:t(()=>[e(a(y),{label:"AppSecret"},{default:t(()=>[e(a(J),{value:c.appSecret,"onUpdate:value":l[2]||(l[2]=r=>c.appSecret=r),placeholder:"your_app_secret"},null,8,["value"])]),_:1})]),_:1}),e(a(w),{span:12},{default:t(()=>[e(a(y),{label:"签名算法"},{default:t(()=>[e(a(T),{value:c.signType,"onUpdate:value":l[3]||(l[3]=r=>c.signType=r),style:{width:"100%"}},{default:t(()=>[e(a(d),{value:"HMAC-SHA256"},{default:t(()=>[o("HMAC-SHA256 (推荐)")]),_:1}),e(a(d),{value:"MD5"},{default:t(()=>[o("MD5 (兼容)")]),_:1})]),_:1},8,["value"])]),_:1})]),_:1}),e(a(w),{span:12},{default:t(()=>[e(a(y),{label:"时间戳"},{default:t(()=>[e(a(k),{value:c.timestamp,"onUpdate:value":l[4]||(l[4]=r=>c.timestamp=r)},null,8,["value"]),e(a(A),{type:"link",size:"small",onClick:G},{default:t(()=>[o("刷新")]),_:1})]),_:1})]),_:1})]),_:1})]),f("div",we,[Ce,e(a(k).TextArea,{value:S.value,"onUpdate:value":l[5]||(l[5]=r=>S.value=r),rows:10,placeholder:'{"mchNo": "Mxxx", "amount": 100}',style:{"font-family":"monospace","font-size":"12px"}},null,8,["value"])]),e(a(y),null,{default:t(()=>[e(a(ie),null,{default:t(()=>[e(a(A),{type:"primary",size:"large",loading:n.value,onClick:Y},{default:t(()=>[e(a(de)),o(" 发送请求 ")]),_:1},8,["loading"]),e(a(A),{onClick:X},{default:t(()=>[o("生成签名")]),_:1}),e(a(A),{onClick:W},{default:t(()=>[o("加载示例")]),_:1}),e(a(A),{onClick:l[6]||(l[6]=r=>{S.value="",g.value=""})},{default:t(()=>[o("清空")]),_:1})]),_:1})]),_:1})]),_:1}),f("div",Ne,[Pe,x.value?($(),V("div",he,[e(a(M),{color:x.value.code==="OP0000"?"green":"red"},{default:t(()=>[o(" HTTP "+N(x.value.status),1)]),_:1},8,["color"]),e(a(M),null,{default:t(()=>[o("耗时 "+N(x.value.time)+"ms",1)]),_:1}),e(a(M),null,{default:t(()=>[o("大小 "+N(x.value.size),1)]),_:1})])):xe("",!0),f("pre",{class:_e(["response-block",{"response-error":((s=x.value)==null?void 0:s.code)!=="OP0000"}])},N(g.value||"响应结果将显示在这里"),3)])]}),_:1})]),_:1}),e(a(w),{span:10},{default:t(()=>[e(a(h),{title:"签名生成工具",class:"sign-card"},{default:t(()=>[e(a(j),{layout:"vertical"},{default:t(()=>[e(a(y),{label:"签名密钥 (AppSecret)"},{default:t(()=>[e(a(J),{value:m.secret,"onUpdate:value":l[7]||(l[7]=s=>m.secret=s),placeholder:"输入密钥"},null,8,["value"])]),_:1}),e(a(y),{label:"签名算法"},{default:t(()=>[e(a(ce),{value:m.algorithm,"onUpdate:value":l[8]||(l[8]=s=>m.algorithm=s)},{default:t(()=>[e(a(R),{value:"HMAC-SHA256"},{default:t(()=>[o("HMAC-SHA256")]),_:1}),e(a(R),{value:"MD5"},{default:t(()=>[o("MD5")]),_:1})]),_:1},8,["value"])]),_:1}),e(a(y),{label:"参数列表 (JSON)"},{default:t(()=>[e(a(k).TextArea,{value:m.params,"onUpdate:value":l[9]||(l[9]=s=>m.params=s),rows:8,placeholder:'{"appKey": "xxx", "timestamp": "xxx"}',style:{"font-family":"monospace","font-size":"12px"}},null,8,["value"])]),_:1}),e(a(y),null,{default:t(()=>[e(a(A),{type:"primary",block:"",onClick:ee},{default:t(()=>[o("计算签名")]),_:1})]),_:1}),e(a(y),{label:"签名结果"},{default:t(()=>[e(a(k),{value:v.value,"onUpdate:value":l[10]||(l[10]=s=>v.value=s),readOnly:"",style:{"font-family":"monospace",color:"#52c41a","font-weight":"600"}},null,8,["value"]),e(a(A),{type:"link",onClick:l[11]||(l[11]=s=>H(v.value))},{default:t(()=>[e(a(z)),o(" 复制")]),_:1})]),_:1})]),_:1})]),_:1}),e(a(h),{title:"签名示例",class:"sign-example-card",style:{"margin-top":"16px"}},{default:t(()=>[ke,e(a(ve),{direction:"vertical",size:"small",current:0},{default:t(()=>[e(a(D),{title:"Step 1: 过滤参数",description:"移除 sign 参数和空值参数"}),e(a(D),{title:"Step 2: 字典序排序",description:"按参数名的 ASCII 码从小到大排序"}),e(a(D),{title:"Step 3: 拼接字符串",description:"格式: key1=value1&key2=value2"}),e(a(D),{title:"Step 4: 计算签名",description:"使用 HMAC-SHA256 算法，密钥为 AppSecret"}),e(a(D),{title:"Step 5: 转大写",description:"将签名结果转为十六进制大写字符串"})]),_:1}),f("pre",{class:"sign-demo"},N(Me))]),_:1}),e(a(h),{title:"支付签名示例",class:"pay-example-card",style:{"margin-top":"16px"}},{default:t(()=>[De,f("pre",{class:"code-block"},N(Z)),e(a(A),{type:"link",onClick:l[12]||(l[12]=s=>H(Z))},{default:t(()=>[e(a(z)),o(" 复制")]),_:1})]),_:1})]),_:1})]),_:1}),e(a(h),{title:"沙箱环境说明",style:{"margin-top":"16px"}},{default:t(()=>[e(a(fe),{type:"info","show-icon":""},{message:t(()=>[o("沙箱环境")]),description:t(()=>[o(" 开发调试时请使用沙箱环境: "),Ee,o("。沙箱环境的 AppKey/AppSecret 与生产环境隔离，支付均为模拟支付，不会产生真实交易。沙箱环境配置同生产环境，可在开发者中心创建测试应用。 ")]),_:1})]),_:1})]))}}),Be=Oe(Ge,[["__scopeId","data-v-406a0f1b"]]);export{Be as default};

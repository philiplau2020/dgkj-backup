import{a as e}from"./entry/index-D9YMi87w-1778590413429.js";const p=t=>e.get({url:"/tree/getDemoOptions",params:t});export{p as t};

import{a as t}from"./entry/index-D9YMi87w-1778590413429.js";const r=e=>t.get({url:"/table/getDemoList",params:e,headers:{ignoreCancelToken:!0}});export{r as d};

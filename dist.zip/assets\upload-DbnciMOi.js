import{a as u,e as a}from"./entry/index-D9YMi87w-1778590413429.js";const{uploadUrl:e=""}=a();function p(o,t){return u.uploadFile({url:e,onUploadProgress:t},o)}export{p as u};

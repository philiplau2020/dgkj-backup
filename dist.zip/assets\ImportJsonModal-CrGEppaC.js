var y=Object.defineProperty,I=Object.defineProperties;var M=Object.getOwnPropertyDescriptors;var h=Object.getOwnPropertySymbols;var U=Object.prototype.hasOwnProperty,j=Object.prototype.propertyIsEnumerable;var C=(e,o,a)=>o in e?y(e,o,{enumerable:!0,configurable:!0,writable:!0,value:a}):e[o]=a,c=(e,o)=>{for(var a in o||(o={}))U.call(o,a)&&C(e,a,o[a]);if(h)for(var a of h(o))j.call(o,a)&&C(e,a,o[a]);return e},i=(e,o)=>I(e,M(o));import{u as k}from"./useFormDesignState-C2sxsDfo.js";import{f as J,g as S}from"./index-BnQdKTa1.js";import{C as g,M as w}from"./index-C9pHAKrM.js";import{c as O,_ as E}from"./entry/index-D9YMi87w-1778590413429.js";import{M as N,aK as D}from"./antd-JXlm2PCC.js";import{d as $,r as F,I as x,a7 as r,Z as B,a8 as K,a9 as n,$ as b,k as l,G as m,a2 as T,a3 as V}from"./vue-BgPDgpOs.js";import"./useWindowSizeFn-q45J9j6G.js";const L=$({name:"ImportJsonModal",components:{CodeEditor:g,Upload:D,Modal:N},setup(){const{createMessage:e}=O(),o=F({visible:!1,json:`{
  "schemas": [
    {
      "component": "input",
      "label": "输入框",
      "field": "input_2",
      "span": 24,
      "props": {
        "type": "text"
      }
    }
  ],
  "layout": "horizontal",
  "labelLayout": "flex",
  "labelWidth": 100,
  "labelCol": {},
  "wrapperCol": {}
}`,jsonData:{schemas:{},config:{}},handleSetSelectItem:null}),{formDesignMethods:a}=k(),p=()=>{o.visible=!1},f=()=>{o.visible=!0},d=()=>{try{const s=JSON.parse(o.json);s.schemas&&J(s.schemas,t=>{S(t)}),a.setFormConfig(i(c({},s),{activeKey:1,currentItem:{component:""}})),p(),e.success("导入成功")}catch(s){e.error("导入失败，数据格式不对")}};return i(c({handleImportJson:d,beforeUpload:s=>{const t=new FileReader;return t.readAsText(s),t.onload=function(){o.json=this.result,d()},!1},handleCancel:p,showModal:f},x(o)),{MODE:w})}}),R=e=>(T("data-v-62ebfefa"),e=e(),V(),e),z=R(()=>b("p",{class:"hint-box"},"导入格式如下:",-1)),A={class:"v-json-box"};function G(e,o,a,p,f,d){const u=r("CodeEditor"),s=r("a-button"),t=r("Upload"),_=r("Modal");return B(),K(_,{title:"JSON数据",open:e.visible,onOk:e.handleImportJson,onCancel:e.handleCancel,cancelText:"关闭",destroyOnClose:!0,wrapClassName:"v-code-modal",style:{top:"20px"},width:850},{footer:n(()=>[l(s,{onClick:e.handleCancel},{default:n(()=>[m("取消")]),_:1},8,["onClick"]),l(t,{class:"upload-button",beforeUpload:e.beforeUpload,showUploadList:!1,accept:"application/json"},{default:n(()=>[l(s,{type:"primary"},{default:n(()=>[m("导入json文件")]),_:1})]),_:1},8,["beforeUpload"]),l(s,{type:"primary",onClick:e.handleImportJson},{default:n(()=>[m("确定")]),_:1},8,["onClick"])]),default:n(()=>[z,b("div",A,[l(u,{value:e.json,"onUpdate:value":o[0]||(o[0]=v=>e.json=v),ref:"myEditor",mode:e.MODE.JSON},null,8,["value","mode"])])]),_:1},8,["open","onOk","onCancel"])}const ee=E(L,[["render",G],["__scopeId","data-v-62ebfefa"]]);export{ee as default};

import{a as r}from"./entry/index-D9YMi87w-1778590413429.js";const o=a=>r.post({url:"/cascader/getAreaRecord",data:a});export{o as a};

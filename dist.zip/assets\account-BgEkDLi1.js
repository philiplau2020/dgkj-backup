import{a as t}from"./entry/index-D9YMi87w-1778590413429.js";const e=()=>t.get({url:"/account/getAccountInfo"}),n=()=>t.post({url:"/user/tokenExpired"});export{e as a,n as t};

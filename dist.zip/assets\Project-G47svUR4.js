import{_ as o}from"./Project.vue_vue_type_style_index_0_lang-DOLco8gs.js";import"./data-NRFjrms5.js";import"./antd-JXlm2PCC.js";import"./vue-BgPDgpOs.js";export{o as default};

import{a as o}from"./entry/index-D9YMi87w-1778590413429.js";const s=t=>o.get({url:"/select/getDemoOptions",params:t});export{s as o};

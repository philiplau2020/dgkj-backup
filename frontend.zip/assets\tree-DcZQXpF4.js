import{a as e}from"./entry/index-Cqtx2hlS-1778652592320.js";const p=t=>e.get({url:"/tree/getDemoOptions",params:t});export{p as t};

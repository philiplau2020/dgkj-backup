import{a as t}from"./entry/index-Cqtx2hlS-1778652592320.js";const e=()=>t.get({url:"/account/getAccountInfo"}),n=()=>t.post({url:"/user/tokenExpired"});export{e as a,n as t};

import{a as t}from"./entry/index-Cqtx2hlS-1778652592320.js";const r=e=>t.get({url:"/table/getDemoList",params:e,headers:{ignoreCancelToken:!0}});export{r as d};

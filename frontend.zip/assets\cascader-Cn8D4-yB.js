import{a as r}from"./entry/index-Cqtx2hlS-1778652592320.js";const o=a=>r.post({url:"/cascader/getAreaRecord",data:a});export{o as a};

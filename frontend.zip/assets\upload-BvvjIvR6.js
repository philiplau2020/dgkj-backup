import{a as u,e as a}from"./entry/index-Cqtx2hlS-1778652592320.js";const{uploadUrl:e=""}=a();function p(o,t){return u.uploadFile({url:e,onUploadProgress:t},o)}export{p as u};

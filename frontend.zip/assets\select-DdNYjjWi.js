import{a as o}from"./entry/index-Cqtx2hlS-1778652592320.js";const s=t=>o.get({url:"/select/getDemoOptions",params:t});export{s as o};

import{a as t}from"./entry/index-H5yh8qbf-1778647823115.js";const e=()=>t.get({url:"/account/getAccountInfo"}),n=()=>t.post({url:"/user/tokenExpired"});export{e as a,n as t};

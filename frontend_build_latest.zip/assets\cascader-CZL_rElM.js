import{a as r}from"./entry/index-H5yh8qbf-1778647823115.js";const o=a=>r.post({url:"/cascader/getAreaRecord",data:a});export{o as a};

import{a as o}from"./entry/index-H5yh8qbf-1778647823115.js";const s=t=>o.get({url:"/select/getDemoOptions",params:t});export{s as o};

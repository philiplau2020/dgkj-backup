import{a as t}from"./entry/index-H5yh8qbf-1778647823115.js";const r=e=>t.get({url:"/table/getDemoList",params:e,headers:{ignoreCancelToken:!0}});export{r as d};

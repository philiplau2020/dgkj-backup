import{a as e}from"./entry/index-H5yh8qbf-1778647823115.js";const p=t=>e.get({url:"/tree/getDemoOptions",params:t});export{p as t};

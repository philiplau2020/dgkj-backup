import{a as u,e as a}from"./entry/index-H5yh8qbf-1778647823115.js";const{uploadUrl:e=""}=a();function p(o,t){return u.uploadFile({url:e,onUploadProgress:t},o)}export{p as u};

import{a as e}from"./entry/index-DdZxXA41-1778607966958.js";const p=t=>e.get({url:"/tree/getDemoOptions",params:t});export{p as t};

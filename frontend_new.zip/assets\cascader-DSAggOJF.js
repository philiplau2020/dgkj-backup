import{a as r}from"./entry/index-DdZxXA41-1778607966958.js";const o=a=>r.post({url:"/cascader/getAreaRecord",data:a});export{o as a};

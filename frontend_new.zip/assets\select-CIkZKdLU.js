import{a as o}from"./entry/index-DdZxXA41-1778607966958.js";const s=t=>o.get({url:"/select/getDemoOptions",params:t});export{s as o};

import{a as u,e as a}from"./entry/index-DdZxXA41-1778607966958.js";const{uploadUrl:e=""}=a();function p(o,t){return u.uploadFile({url:e,onUploadProgress:t},o)}export{p as u};

import{a as t}from"./entry/index-DdZxXA41-1778607966958.js";const e=()=>t.get({url:"/account/getAccountInfo"}),n=()=>t.post({url:"/user/tokenExpired"});export{e as a,n as t};

const t="https://github.com/vbenjs/vue-vben-admin",s="https://doc.vvbin.cn/",n="https://dgpay.dgutech.cn/";export{s as D,t as G,n as S};

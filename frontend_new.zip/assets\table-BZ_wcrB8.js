import{a as t}from"./entry/index-DdZxXA41-1778607966958.js";const r=e=>t.get({url:"/table/getDemoList",params:e,headers:{ignoreCancelToken:!0}});export{r as d};

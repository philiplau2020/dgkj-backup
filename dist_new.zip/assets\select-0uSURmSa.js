import{a as o}from"./entry/index-DQGWShWP-1778647144030.js";const s=t=>o.get({url:"/select/getDemoOptions",params:t});export{s as o};

import{a as t}from"./entry/index-DQGWShWP-1778647144030.js";const r=e=>t.get({url:"/table/getDemoList",params:e,headers:{ignoreCancelToken:!0}});export{r as d};

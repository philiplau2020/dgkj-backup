import{a as e}from"./entry/index-DQGWShWP-1778647144030.js";const p=t=>e.get({url:"/tree/getDemoOptions",params:t});export{p as t};

import{X as w,Y as C,bj as M,x as H,bW as y,a8 as n,Q as g,am as R,a6 as P,as as U,at as B,B as O,an as T,W as G,j as J}from"./antd-gFvAnYP4.js";import{d as X,f as S,c as $,Z as r,_ as p,k as a,a9 as t,u as e,G as s,F as A,$ as d,a0 as u,a8 as k,ab as l,a1 as z,aa as F,a2 as V,a3 as L}from"./vue-BgPDgpOs.js";import{_ as Q}from"./entry/index-DQGWShWP-1778647144030.js";const m=f=>(V("data-v-8a23aee5"),f=f(),L(),f),W={class:"api-document"},Y={class:"doc-header"},Z={key:1,class:"endpoint-block"},ee={class:"endpoint-url"},te={key:2,class:"params-section"},ae=m(()=>d("h3",null,"请求参数",-1)),se={key:3,class:"example-section"},oe=m(()=>d("h3",null,"请求示例",-1)),ne={class:"code-block"},re={key:4,class:"params-section"},de=m(()=>d("h3",null,"响应参数",-1)),le={key:5,class:"example-section"},pe=m(()=>d("h3",null,"响应示例",-1)),ue={class:"code-block"},ce={key:6,class:"params-section"},ie=m(()=>d("h3",null,"错误码",-1)),ye={key:7,class:"example-section"},me=m(()=>d("h3",null,"SDK 示例代码",-1)),xe={class:"code-block"},_e={key:1},ke={class:"code-block"},fe={key:8,class:"example-section"},he=m(()=>d("h3",null,"签名算法 (HMAC-SHA256)",-1)),I=`// 1. 将所有参数按字典序排序
// 2. 拼接成 key=value&key=value 格式
// 3. 使用 AppSecret 作为密钥进行 HMAC-SHA256 签名
// 4. 将签名结果转为大写

const crypto = require('crypto');

function sign(params, appSecret) {
  const sorted = Object.keys(params)
    .filter(k => k !== 'sign' && params[k] !== undefined)
    .sort()
    .map(k => k + '=' + params[k])
    .join('&');
  return crypto.createHmac('sha256', appSecret)
    .update(sorted)
    .digest('hex')
    .toUpperCase();
}

// 示例参数
const params = {
  appKey: 'DGKJxxx',
  timestamp: '20260512000000',
  mchNo: 'Mxxx',
  orderNo: 'ORDxxx',
  payType: 'wx_native',
  amount: 100,
  subject: '测试商品',
  notifyUrl: 'https://example.com/notify'
};

const sign = sign(params, 'your_app_secret');
// 签名: 7B2C3D...`,ve=X({__name:"index",setup(f){const q=S(""),h=S(["intro-overview"]),D=[{title:"参数名",dataIndex:"name",width:150},{title:"类型",dataIndex:"type",width:80},{title:"必填",key:"required",width:70},{title:"说明",dataIndex:"desc"}],K=[{title:"字段名",dataIndex:"name",width:150},{title:"类型",key:"type",width:80},{title:"说明",dataIndex:"desc"}],j=[{title:"错误码",key:"code",width:120},{title:"说明",dataIndex:"desc",width:200},{title:"解决方案",dataIndex:"solution"}],b={"intro-overview":{key:"intro-overview",title:"平台简介",type:"document",desc:"DGKJ 开放平台为第三方开发者提供标准化支付 API 接口，支持聚合支付、退款、转账、账户查询等功能。平台基于金融级安全标准构建，支持 HMAC-SHA256、RSA、SM2 等多种签名验签方式。",requestExample:`基础地址: https://api.dgkjpay.com

接口版本: v1

数据格式: JSON

编码: UTF-8

通信协议: HTTPS`},"intro-auth":{key:"intro-auth",title:"认证说明",type:"document",desc:"所有 API 请求必须通过 AppKey + 签名进行身份认证。请求头中需要包含以下参数：",requestExample:`请求头 (Headers):
  X-App-Key: your_app_key
  X-Sign: generated_signature
  X-Sign-Type: HMAC-SHA256
  X-Timestamp: 20260512000000
  X-Nonce: random_string_32chars
  Content-Type: application/json

认证流程:
1. 在开放平台创建应用，获取 AppKey 和 AppSecret
2. 使用 AppSecret 对请求参数进行签名
3. 将签名结果和其他认证参数放入请求头
4. 发起 API 调用`},"intro-sign":{key:"intro-sign",title:"签名机制",type:"document",desc:"采用 HMAC-SHA256 签名算法，签名过程如下：",requestExample:I},"intro-callback":{key:"intro-callback",title:"回调通知",type:"document",desc:"支付结果、退款结果、转账结果会通过 HTTP POST 方式通知到应用配置的回调地址。回调地址需要在创建应用时配置。",requestExample:`回调地址: https://your-domain.com/notify (支付通知)
                   https://your-domain.com/refund-notify (退款通知)

回调请求头:
  Content-Type: application/json
  X-Sign: signature_from_platform

回调请求体:
{
  "code": "OP0000",
  "message": "success",
  "data": {
    "orderNo": "OPxxxx",
    "mchNo": "Mxxxx",
    "payType": "wx_native",
    "amount": 100,
    "status": "paid",
    "paidTime": "2026-05-12 10:30:00",
    "channelOrderNo": "Cxxxx"
  }
}

回调通知需返回: {"code": "OP0000", "message": "success"}`},"intro-error":{key:"intro-error",title:"错误码说明",type:"document",desc:"所有 API 响应都包含 code 字段，当 code 为 OP0000 时表示成功，否则表示失败。",errorCodes:[{code:"OP0000",desc:"操作成功",solution:"正常处理"},{code:"OP1001",desc:"签名验证失败",solution:"检查签名算法和密钥"},{code:"OP1002",desc:"时间戳过期",solution:"检查服务器时间"},{code:"OP1003",desc:"AppKey 不存在",solution:"检查 AppKey 是否正确"},{code:"OP1004",desc:"AppKey 已禁用",solution:"联系平台客服"},{code:"OP1006",desc:"IP 不在白名单",solution:"在应用配置中添加 IP 白名单"},{code:"OP2001",desc:"API 接口未授权",solution:"联系平台开通对应接口权限"},{code:"OP3001",desc:"请求频率超限",solution:"降低请求频率"},{code:"OP3002",desc:"日配额已用完",solution:"明日再试或升级套餐"},{code:"OP4001",desc:"订单不存在",solution:"检查订单号是否正确"},{code:"OP4002",desc:"订单已过期",solution:"重新创建订单"},{code:"OP4004",desc:"订单已支付",solution:"订单不可重复支付"},{code:"OP4008",desc:"退款金额超限",solution:"检查退款金额"},{code:"OP5001",desc:"开发者未审核",solution:"等待审核或联系客服"}]},"pay-gateway":{key:"pay-gateway",title:"发起支付",method:"POST",path:"/api/v1/pay/gateway",desc:"商户通过此接口发起支付请求，平台根据 payType 返回对应的支付链接或二维码。",params:[{name:"mchNo",type:"string",required:!0,desc:"商户号"},{name:"appId",type:"string",required:!0,desc:"应用ID"},{name:"payType",type:"string",required:!0,desc:"支付方式: wx_native/wx_jsapi/wx_h5/alipay_qr/alipay/alipay_wap/unionpay/bank"},{name:"amount",type:"int",required:!0,desc:"金额(单位: 分)"},{name:"subject",type:"string",required:!0,desc:"商品标题(最多100字)"},{name:"orderNo",type:"string",required:!0,desc:"商户订单号(唯一)"},{name:"notifyUrl",type:"string",required:!0,desc:"异步通知地址"},{name:"returnUrl",type:"string",required:!1,desc:"支付完成跳转地址(H5支付必填)"},{name:"clientIp",type:"string",required:!1,desc:"客户端IP"},{name:"attach",type:"string",required:!1,desc:"附加数据(透传)"}],requestExample:`{
  "mchNo": "M1234567890",
  "appId": "APPxxx",
  "payType": "wx_native",
  "amount": 100,
  "subject": "测试商品",
  "orderNo": "ORD2026051200001",
  "notifyUrl": "https://example.com/notify",
  "clientIp": "1.2.3.4",
  "attach": "order_123"
}`,responseExample:`{
  "code": "OP0000",
  "message": "操作成功",
  "data": {
    "orderNo": "OPxxx",
    "payUrl": "weixin://wxpay/bizpayurl?pr=xxx",
    "qrCode": "https://api.dgkjpay.com/qr/OPxxx",
    "amount": 100,
    "status": "pending",
    "expireTime": "2026-05-12T12:00:00Z"
  }
}`,sdkExample:{multiple:!0,codes:{"Node.js":`const DgkjPay = require('dgkj-pay-sdk');

const client = new DgkjPay({
  appId: 'APPxxx',
  appKey: 'DGKJxxx',
  appSecret: 'your_app_secret',
  mchNo: 'Mxxx'
});

// 发起支付
const result = await client.pay({
  payType: 'wx_native',
  amount: 100, // 分
  subject: '测试商品',
  orderNo: 'ORD' + Date.now(),
  notifyUrl: 'https://example.com/notify'
});

console.log(result.qrCode); // 二维码链接
console.log(result.orderNo); // 平台订单号`,Java:`import com.dgkj.pay.*;

DgkjPayClient client = new DgkjPayClient(
  "APPxxx", "DGKJxxx", "app_secret", "Mxxx");

PayRequest request = PayRequest.builder()
  .payType("wx_native")
  .amount(100)
  .subject("测试商品")
  .orderNo("ORD" + System.currentTimeMillis())
  .notifyUrl("https://example.com/notify")
  .build();

PayResponse response = client.pay(request);
System.out.println(response.getQrCode());`,PHP:`<?php
require_once 'DgkjPay.php';

$client = new DgkjPayClient([
  'app_id' => 'APPxxx',
  'app_key' => 'DGKJxxx',
  'app_secret' => 'your_secret',
  'mch_no' => 'Mxxx'
]);

$result = $client->pay([
  'pay_type' => 'wx_native',
  'amount' => 100,
  'subject' => '测试商品',
  'order_no' => 'ORD' . time(),
  'notify_url' => 'https://example.com/notify'
]);

echo $result['qr_code'];`}}},"pay-query":{key:"pay-query",title:"查询订单",method:"GET",path:"/api/v1/query/order/:orderNo",desc:"通过平台订单号查询订单状态。",params:[{name:"orderNo",type:"string",required:!0,desc:"平台订单号"}],responseExample:`{
  "code": "OP0000",
  "data": {
    "orderNo": "OPxxx",
    "mchNo": "Mxxx",
    "payType": "wx_native",
    "amount": 100,
    "status": "paid",
    "paidTime": "2026-05-12 10:30:00",
    "createTime": "2026-05-12 10:00:00"
  }
}`},"refund-apply":{key:"refund-apply",title:"申请退款",method:"POST",path:"/api/v1/refund/apply",desc:"商户通过此接口申请退款，支持全额或部分退款。",params:[{name:"orderNo",type:"string",required:!0,desc:"原订单号"},{name:"refundAmount",type:"int",required:!0,desc:"退款金额(分)"},{name:"refundReason",type:"string",required:!0,desc:"退款原因"},{name:"notifyUrl",type:"string",required:!1,desc:"退款通知地址"}],requestExample:`{
  "orderNo": "OPxxx",
  "refundAmount": 100,
  "refundReason": "用户申请取消订单"
}`,responseExample:`{
  "code": "OP0000",
  "data": {
    "refundNo": "RFxxx",
    "orderNo": "OPxxx",
    "refundAmount": 100,
    "status": "pending"
  }
}`},"transfer-pay":{key:"transfer-pay",title:"发起转账",method:"POST",path:"/api/v1/transfer/pay",desc:"商户通过此接口向用户银行卡或账户转账，支持实时到账。",params:[{name:"outNo",type:"string",required:!0,desc:"商户转账单号"},{name:"amount",type:"int",required:!0,desc:"转账金额(分)"},{name:"accountType",type:"string",required:!0,desc:"账户类型: bank_card/bank_account"},{name:"accountName",type:"string",required:!0,desc:"账户姓名(需实名)"},{name:"accountNo",type:"string",required:!0,desc:"账户号/银行卡号"},{name:"bankName",type:"string",required:!0,desc:"银行名称"},{name:"remark",type:"string",required:!1,desc:"转账备注"}],requestExample:`{
  "outNo": "T202605120001",
  "amount": 10000,
  "accountType": "bank_card",
  "accountName": "张三",
  "accountNo": "6222021234567890",
  "bankName": "中国工商银行",
  "remark": "佣金发放"
}`,responseExample:`{
  "code": "OP0000",
  "data": {
    "transferNo": "TRxxx",
    "outNo": "T202605120001",
    "amount": 10000,
    "fee": 10,
    "actualAmount": 9990,
    "status": "pending"
  }
}`},"account-balance":{key:"account-balance",title:"查询余额",method:"GET",path:"/api/v1/account/balance",desc:"查询商户账户余额信息。",params:[{name:"mchNo",type:"string",required:!1,desc:"商户号(不填默认应用绑定的商户)"}],responseExample:`{
  "code": "OP0000",
  "data": {
    "mchNo": "Mxxx",
    "availableBalance": 100000.00,
    "frozenBalance": 5000.00,
    "totalBalance": 105000.00,
    "currency": "CNY"
  }
}`}},o=$(()=>b[h.value[0]]||b["intro-overview"]);function E({key:v}){h.value=[v]}function N(v){navigator.clipboard.writeText(v).then(()=>J.success("代码已复制"))}return(v,x)=>(r(),p("div",W,[a(e(G),{gutter:24},{default:t(()=>[a(e(w),{span:5},{default:t(()=>[a(e(C),{class:"nav-card"},{default:t(()=>[a(e(M),{value:q.value,"onUpdate:value":x[0]||(x[0]=_=>q.value=_),placeholder:"搜索 API",style:{"margin-bottom":"16px"}},null,8,["value"]),a(e(H),{selectedKeys:h.value,"onUpdate:selectedKeys":x[1]||(x[1]=_=>h.value=_),mode:"inline",onClick:E},{default:t(()=>[a(e(y),{key:"intro",title:"概述"},{default:t(()=>[a(e(n),{key:"intro-overview"},{default:t(()=>[s("平台简介")]),_:1}),a(e(n),{key:"intro-auth"},{default:t(()=>[s("认证说明")]),_:1}),a(e(n),{key:"intro-sign"},{default:t(()=>[s("签名机制")]),_:1}),a(e(n),{key:"intro-callback"},{default:t(()=>[s("回调通知")]),_:1}),a(e(n),{key:"intro-error"},{default:t(()=>[s("错误码")]),_:1})]),_:1}),a(e(y),{key:"dev",title:"开发者接口"},{default:t(()=>[a(e(n),{key:"dev-register"},{default:t(()=>[s("注册开发者")]),_:1}),a(e(n),{key:"dev-login"},{default:t(()=>[s("开发者登录")]),_:1}),a(e(n),{key:"dev-info"},{default:t(()=>[s("获取用户信息")]),_:1})]),_:1}),a(e(y),{key:"app",title:"应用管理"},{default:t(()=>[a(e(n),{key:"app-create"},{default:t(()=>[s("创建应用")]),_:1}),a(e(n),{key:"app-list"},{default:t(()=>[s("应用列表")]),_:1}),a(e(n),{key:"app-detail"},{default:t(()=>[s("应用详情")]),_:1}),a(e(n),{key:"app-update"},{default:t(()=>[s("更新应用")]),_:1}),a(e(n),{key:"app-secret"},{default:t(()=>[s("重置密钥")]),_:1}),a(e(n),{key:"app-ip"},{default:t(()=>[s("IP白名单")]),_:1}),a(e(n),{key:"app-key"},{default:t(()=>[s("API Key管理")]),_:1})]),_:1}),a(e(y),{key:"pay",title:"支付接口"},{default:t(()=>[a(e(n),{key:"pay-gateway"},{default:t(()=>[s("发起支付")]),_:1}),a(e(n),{key:"pay-query"},{default:t(()=>[s("查询订单")]),_:1}),a(e(n),{key:"pay-close"},{default:t(()=>[s("关闭订单")]),_:1})]),_:1}),a(e(y),{key:"refund",title:"退款接口"},{default:t(()=>[a(e(n),{key:"refund-apply"},{default:t(()=>[s("申请退款")]),_:1}),a(e(n),{key:"refund-query"},{default:t(()=>[s("查询退款")]),_:1})]),_:1}),a(e(y),{key:"transfer",title:"转账接口"},{default:t(()=>[a(e(n),{key:"transfer-pay"},{default:t(()=>[s("发起转账")]),_:1}),a(e(n),{key:"transfer-query"},{default:t(()=>[s("查询转账")]),_:1})]),_:1}),a(e(y),{key:"account",title:"账户接口"},{default:t(()=>[a(e(n),{key:"account-balance"},{default:t(()=>[s("查询余额")]),_:1})]),_:1}),a(e(y),{key:"sdk",title:"SDK下载"},{default:t(()=>[a(e(n),{key:"sdk-node"},{default:t(()=>[s("Node.js SDK")]),_:1}),a(e(n),{key:"sdk-java"},{default:t(()=>[s("Java SDK")]),_:1}),a(e(n),{key:"sdk-php"},{default:t(()=>[s("PHP SDK")]),_:1}),a(e(n),{key:"sdk-python"},{default:t(()=>[s("Python SDK")]),_:1}),a(e(n),{key:"sdk-go"},{default:t(()=>[s("Go SDK")]),_:1}),a(e(n),{key:"sdk-csharp"},{default:t(()=>[s("C# SDK")]),_:1})]),_:1})]),_:1},8,["selectedKeys"])]),_:1})]),_:1}),a(e(w),{span:19},{default:t(()=>[a(e(C),{class:"content-card"},{default:t(()=>{var _;return[o.value?(r(),p(A,{key:0},[d("div",Y,[d("h2",null,u(o.value.title),1),a(e(g),{color:o.value.method?"blue":"green"},{default:t(()=>[s(u(o.value.method||o.value.type),1)]),_:1},8,["color"])]),o.value.desc?(r(),k(e(R),{key:0,type:"info",message:o.value.desc,"show-icon":"",style:{"margin-bottom":"16px"}},null,8,["message"])):l("",!0),o.value.path?(r(),p("div",Z,[d("div",ee,[d("span",{class:z(["method-badge",(_=o.value.method)==null?void 0:_.toLowerCase()])},u(o.value.method),3),d("code",null,u(o.value.path),1)])])):l("",!0),o.value.params&&o.value.params.length?(r(),p("div",te,[ae,a(e(P),{"data-source":o.value.params,columns:D,pagination:!1,size:"small",bordered:""},{bodyCell:t(({column:c,record:i})=>[c.key==="required"?(r(),k(e(g),{key:0,color:i.required?"red":"default"},{default:t(()=>[s(u(i.required?"是":"否"),1)]),_:2},1032,["color"])):l("",!0)]),_:1},8,["data-source"])])):l("",!0),o.value.requestExample?(r(),p("div",se,[oe,d("pre",ne,u(o.value.requestExample),1)])):l("",!0),o.value.response&&o.value.response.length?(r(),p("div",re,[de,a(e(P),{"data-source":o.value.response,columns:K,pagination:!1,size:"small",bordered:""},{bodyCell:t(({column:c,record:i})=>[c.key==="type"?(r(),k(e(g),{key:0,color:"purple"},{default:t(()=>[s(u(i.type),1)]),_:2},1024)):l("",!0)]),_:1},8,["data-source"])])):l("",!0),o.value.responseExample?(r(),p("div",le,[pe,d("pre",ue,u(o.value.responseExample),1)])):l("",!0),o.value.errorCodes?(r(),p("div",ce,[ie,a(e(P),{"data-source":o.value.errorCodes,columns:j,pagination:!1,size:"small",bordered:""},{bodyCell:t(({column:c,record:i})=>[c.key==="code"?(r(),k(e(g),{key:0,color:"orange"},{default:t(()=>[s(u(i.code),1)]),_:2},1024)):l("",!0)]),_:1},8,["data-source"])])):l("",!0),o.value.sdkExample?(r(),p("div",ye,[me,o.value.sdkExample.multiple?(r(),k(e(U),{key:0},{default:t(()=>[(r(!0),p(A,null,F(o.value.sdkExample.codes,(c,i)=>(r(),k(e(B),{key:i,tab:i},{default:t(()=>[d("pre",xe,u(c),1),a(e(O),{type:"primary",onClick:ge=>N(c),style:{"margin-top":"8px"}},{default:t(()=>[a(e(T)),s(" 复制代码")]),_:2},1032,["onClick"])]),_:2},1032,["tab"]))),128))]),_:1})):(r(),p("div",_e,[d("pre",ke,u(o.value.sdkExample.code),1),a(e(O),{type:"primary",onClick:x[2]||(x[2]=c=>N(o.value.sdkExample.code)),style:{"margin-top":"8px"}},{default:t(()=>[a(e(T)),s(" 复制代码")]),_:1})]))])):l("",!0),o.value.key==="intro-sign"?(r(),p("div",fe,[he,d("pre",{class:"code-block"},u(I))])):l("",!0)],64)):l("",!0)]}),_:1})]),_:1})]),_:1})]))}}),Ne=Q(ve,[["__scopeId","data-v-8a23aee5"]]);export{Ne as default};

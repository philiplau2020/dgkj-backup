import{a as r}from"./entry/index-DQGWShWP-1778647144030.js";const o=a=>r.post({url:"/cascader/getAreaRecord",data:a});export{o as a};

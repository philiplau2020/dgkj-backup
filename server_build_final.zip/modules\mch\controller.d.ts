import { Request, Response, NextFunction } from 'express';
export declare class MchController {
    private mchRepo;
    private appRepo;
    private storeRepo;
    private rateRepo;
    getMchList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getMchById(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    createMch(req: Request, res: Response, next: NextFunction): Promise<void>;
    updateMch(req: Request, res: Response, next: NextFunction): Promise<void>;
    reviewMch(req: Request, res: Response, next: NextFunction): Promise<void>;
    getAppList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createApp(req: Request, res: Response, next: NextFunction): Promise<void>;
    updateApp(req: Request, res: Response, next: NextFunction): Promise<void>;
    getStoreList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createStore(req: Request, res: Response, next: NextFunction): Promise<void>;
    updateStore(req: Request, res: Response, next: NextFunction): Promise<void>;
    getRateList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createRate(req: Request, res: Response, next: NextFunction): Promise<void>;
    updateRate(req: Request, res: Response, next: NextFunction): Promise<void>;
}
declare const _default: MchController;
export default _default;
//# sourceMappingURL=controller.d.ts.map
"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const controller_1 = __importDefault(require("./controller"));
const auth_middleware_1 = require("../../common/middleware/auth.middleware");
const router = (0, express_1.Router)();
router.use(auth_middleware_1.authGuard);
// Merchant routes
router.get('/list', controller_1.default.getMchList.bind(controller_1.default));
router.get('/:id', controller_1.default.getMchById.bind(controller_1.default));
router.post('/', controller_1.default.createMch.bind(controller_1.default));
router.put('/:id', controller_1.default.updateMch.bind(controller_1.default));
router.put('/:id/review', controller_1.default.reviewMch.bind(controller_1.default));
// App routes
router.get('/app/list', controller_1.default.getAppList.bind(controller_1.default));
router.post('/app', controller_1.default.createApp.bind(controller_1.default));
router.put('/app/:id', controller_1.default.updateApp.bind(controller_1.default));
// Store routes
router.get('/store/list', controller_1.default.getStoreList.bind(controller_1.default));
router.post('/store', controller_1.default.createStore.bind(controller_1.default));
router.put('/store/:id', controller_1.default.updateStore.bind(controller_1.default));
// Rate routes
router.get('/rate/list', controller_1.default.getRateList.bind(controller_1.default));
router.post('/rate', controller_1.default.createRate.bind(controller_1.default));
router.put('/rate/:id', controller_1.default.updateRate.bind(controller_1.default));
exports.default = router;
//# sourceMappingURL=routes.js.map
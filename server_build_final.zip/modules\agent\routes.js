"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const controller_1 = __importDefault(require("./controller"));
const auth_middleware_1 = require("../../common/middleware/auth.middleware");
const router = (0, express_1.Router)();
router.use(auth_middleware_1.authGuard);
// Agent routes
router.get('/list', controller_1.default.getAgentList.bind(controller_1.default));
router.get('/:id', controller_1.default.getAgentById.bind(controller_1.default));
router.post('/', controller_1.default.createAgent.bind(controller_1.default));
router.put('/:id', controller_1.default.updateAgent.bind(controller_1.default));
router.put('/:id/review', controller_1.default.reviewAgent.bind(controller_1.default));
// Profit routes
router.get('/profit/list', controller_1.default.getProfitList.bind(controller_1.default));
// Withdraw routes
router.get('/withdraw/list', controller_1.default.getWithdrawList.bind(controller_1.default));
router.post('/withdraw', controller_1.default.createWithdraw.bind(controller_1.default));
router.put('/withdraw/:id/review', controller_1.default.reviewWithdraw.bind(controller_1.default));
exports.default = router;
//# sourceMappingURL=routes.js.map
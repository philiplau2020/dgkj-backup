export declare enum UserStatus {
    DISABLED = 0,
    ENABLED = 1
}
export declare enum UserType {
    SUPER_ADMIN = 0,
    ADMIN = 1,
    AGENT = 2,
    MERCHANT = 3
}
export declare class SysUser {
    id: string;
    username: string;
    password: string;
    nickname: string;
    email: string;
    mobile: string;
    avatar: string;
    deptId: string;
    userType: UserType;
    status: UserStatus;
    lastLoginIp: string;
    lastLoginTime: Date;
    createTime: Date;
    updateTime: Date;
}
export declare class SysRole {
    id: string;
    roleName: string;
    roleCode: string;
    roleDesc: string;
    status: number;
    sort: number;
    createTime: Date;
    updateTime: Date;
}
export declare class SysDept {
    id: string;
    parentId: string;
    deptName: string;
    deptCode: string;
    leader: string;
    phone: string;
    email: string;
    status: number;
    sort: number;
    createTime: Date;
    updateTime: Date;
}
export declare class SysMenu {
    id: string;
    parentId: string;
    menuName: string;
    menuCode: string;
    icon: string;
    path: string;
    component: string;
    redirect: string;
    menuType: number;
    visible: number;
    status: number;
    perms: string;
    sort: number;
    keepAlive: number;
    createTime: Date;
    updateTime: Date;
}
export declare class SysUserRole {
    userId: string;
    roleId: string;
}
export declare class SysRoleMenu {
    roleId: string;
    menuId: string;
}
export declare class SysDict {
    id: string;
    dictName: string;
    dictCode: string;
    description: string;
    status: number;
    createTime: Date;
    updateTime: Date;
}
export declare class SysDictData {
    id: string;
    dictId: string;
    dictLabel: string;
    dictValue: string;
    dictType: string;
    sort: number;
    cssClass: string;
    listClass: string;
    isDefault: number;
    status: number;
    createTime: Date;
    updateTime: Date;
}
export declare class SysConfig {
    id: string;
    configName: string;
    configKey: string;
    configValue: string;
    configType: string;
    groupName: string;
    remark: string;
    status: number;
    createTime: Date;
    updateTime: Date;
}
export declare class SysLog {
    id: string;
    userId: string;
    username: string;
    operation: string;
    method: string;
    url: string;
    ip: string;
    location: string;
    params: string;
    result: string;
    status: number;
    errorMsg: string;
    duration: number;
    createTime: Date;
}
export declare class SysNotice {
    id: string;
    noticeTitle: string;
    noticeType: number;
    noticeContent: string;
    status: number;
    createTime: Date;
    updateTime: Date;
}
//# sourceMappingURL=sys.entity.d.ts.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MchController = void 0;
const uuid_1 = require("uuid");
const data_source_1 = require("../../config/data-source");
const mch_entity_1 = require("../../database/entities/mch.entity");
class MchController {
    constructor() {
        this.mchRepo = data_source_1.AppDataSource.getRepository(mch_entity_1.MchInfo);
        this.appRepo = data_source_1.AppDataSource.getRepository(mch_entity_1.MchApp);
        this.storeRepo = data_source_1.AppDataSource.getRepository(mch_entity_1.MchStore);
        this.rateRepo = data_source_1.AppDataSource.getRepository(mch_entity_1.MchRate);
    }
    // ============== Merchant Info ==============
    async getMchList(req, res, next) {
        try {
            const { page = 1, pageSize = 10, mchNo, mchName, status, agentId } = req.query;
            const skip = (Number(page) - 1) * Number(pageSize);
            const queryBuilder = this.mchRepo.createQueryBuilder('mch');
            if (mchNo)
                queryBuilder.andWhere('mch.mchNo LIKE :mchNo', { mchNo: `%${mchNo}%` });
            if (mchName)
                queryBuilder.andWhere('mch.mchName LIKE :mchName', { mchName: `%${mchName}%` });
            if (status !== undefined)
                queryBuilder.andWhere('mch.status = :status', { status });
            if (agentId)
                queryBuilder.andWhere('mch.agentId = :agentId', { agentId });
            const [list, total] = await queryBuilder
                .skip(skip)
                .take(Number(pageSize))
                .orderBy('mch.createTime', 'DESC')
                .getManyAndCount();
            res.json({ code: 0, message: 'success', data: { list, total }, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async getMchById(req, res, next) {
        try {
            const { id } = req.params;
            const mch = await this.mchRepo.findOne({ where: { id } });
            if (!mch)
                return res.status(404).json({ code: 404, message: '商户不存在', data: null, timestamp: new Date().toISOString() });
            res.json({ code: 0, message: 'success', data: mch, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async createMch(req, res, next) {
        try {
            const { mchName, mchShortName, mchType, agentId, contactName, contactPhone, contactEmail, province, city, district, address, bankName, bankAccount, bankUsername } = req.body;
            const mchNo = 'M' + Date.now();
            const mch = this.mchRepo.create({
                id: (0, uuid_1.v4)(),
                mchNo,
                mchName,
                mchShortName,
                mchType,
                agentId,
                contactName,
                contactPhone,
                contactEmail,
                province,
                city,
                district,
                address,
                bankName,
                bankAccount,
                bankUsername,
                status: 2, // Pending review
                createTime: new Date(),
                updateTime: new Date(),
            });
            await this.mchRepo.save(mch);
            res.json({ code: 0, message: '创建成功', data: mch, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async updateMch(req, res, next) {
        try {
            const { id } = req.params;
            const updateData = req.body;
            updateData.updateTime = new Date();
            await this.mchRepo.update(id, updateData);
            res.json({ code: 0, message: '更新成功', data: null, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async reviewMch(req, res, next) {
        try {
            const { id } = req.params;
            const { status, reviewRemark } = req.body;
            await this.mchRepo.update(id, {
                status,
                reviewRemark,
                reviewTime: new Date(),
                reviewUserId: req.user?.userId,
                updateTime: new Date(),
            });
            res.json({ code: 0, message: '审核成功', data: null, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    // ============== App Management ==============
    async getAppList(req, res, next) {
        try {
            const { page = 1, pageSize = 10, mchNo } = req.query;
            const skip = (Number(page) - 1) * Number(pageSize);
            const queryBuilder = this.appRepo.createQueryBuilder('app');
            if (mchNo)
                queryBuilder.andWhere('app.mchNo = :mchNo', { mchNo });
            const [list, total] = await queryBuilder.skip(skip).take(Number(pageSize)).orderBy('app.createTime', 'DESC').getManyAndCount();
            res.json({ code: 0, message: 'success', data: { list, total }, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async createApp(req, res, next) {
        try {
            const { mchNo, appName, notifyUrl, returnUrl } = req.body;
            const appId = 'APP' + Date.now();
            const appSecret = (0, uuid_1.v4)().replace(/-/g, '');
            const app = this.appRepo.create({
                id: (0, uuid_1.v4)(),
                appId,
                mchNo,
                appName,
                appSecret,
                notifyUrl,
                returnUrl,
                status: 1,
                createTime: new Date(),
                updateTime: new Date(),
            });
            await this.appRepo.save(app);
            res.json({ code: 0, message: '创建成功', data: app, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async updateApp(req, res, next) {
        try {
            const { id } = req.params;
            const updateData = req.body;
            updateData.updateTime = new Date();
            await this.appRepo.update(id, updateData);
            res.json({ code: 0, message: '更新成功', data: null, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    // ============== Store Management ==============
    async getStoreList(req, res, next) {
        try {
            const { page = 1, pageSize = 10, mchNo, storeName } = req.query;
            const skip = (Number(page) - 1) * Number(pageSize);
            const queryBuilder = this.storeRepo.createQueryBuilder('store');
            if (mchNo)
                queryBuilder.andWhere('store.mchNo = :mchNo', { mchNo });
            if (storeName)
                queryBuilder.andWhere('store.storeName LIKE :storeName', { storeName: `%${storeName}%` });
            const [list, total] = await queryBuilder.skip(skip).take(Number(pageSize)).orderBy('store.createTime', 'DESC').getManyAndCount();
            res.json({ code: 0, message: 'success', data: { list, total }, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async createStore(req, res, next) {
        try {
            const { mchNo, storeName, storeNo, contactName, contactPhone, province, city, district, address, latitude, longitude } = req.body;
            const storeId = 'S' + Date.now();
            const store = this.storeRepo.create({
                id: (0, uuid_1.v4)(),
                storeId,
                mchNo,
                storeName,
                storeNo,
                contactName,
                contactPhone,
                province,
                city,
                district,
                address,
                latitude,
                longitude,
                status: 1,
                createTime: new Date(),
                updateTime: new Date(),
            });
            await this.storeRepo.save(store);
            res.json({ code: 0, message: '创建成功', data: store, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async updateStore(req, res, next) {
        try {
            const { id } = req.params;
            const updateData = req.body;
            updateData.updateTime = new Date();
            await this.storeRepo.update(id, updateData);
            res.json({ code: 0, message: '更新成功', data: null, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    // ============== Rate Management ==============
    async getRateList(req, res, next) {
        try {
            const { mchNo } = req.query;
            const queryBuilder = this.rateRepo.createQueryBuilder('rate');
            if (mchNo)
                queryBuilder.andWhere('rate.mchNo = :mchNo', { mchNo });
            const list = await queryBuilder.orderBy('rate.createTime', 'DESC').getMany();
            res.json({ code: 0, message: 'success', data: list, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async createRate(req, res, next) {
        try {
            const { mchNo, payWay, rateType, rate, minFee, maxFee } = req.body;
            const rateRecord = this.rateRepo.create({
                id: (0, uuid_1.v4)(),
                mchNo,
                payWay,
                rateType,
                rate,
                minFee,
                maxFee,
                status: 1,
                createTime: new Date(),
                updateTime: new Date(),
            });
            await this.rateRepo.save(rateRecord);
            res.json({ code: 0, message: '创建成功', data: rateRecord, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async updateRate(req, res, next) {
        try {
            const { id } = req.params;
            const updateData = req.body;
            updateData.updateTime = new Date();
            await this.rateRepo.update(id, updateData);
            res.json({ code: 0, message: '更新成功', data: null, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.MchController = MchController;
exports.default = new MchController();
//# sourceMappingURL=controller.js.map
"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const controller_1 = __importDefault(require("./controller"));
const auth_middleware_1 = require("../../common/middleware/auth.middleware");
const router = (0, express_1.Router)();
router.use(auth_middleware_1.authGuard);
// User routes
router.get('/user/list', controller_1.default.getUserList.bind(controller_1.default));
router.get('/user/:id', controller_1.default.getUserById.bind(controller_1.default));
router.post('/user', controller_1.default.createUser.bind(controller_1.default));
router.put('/user/:id', controller_1.default.updateUser.bind(controller_1.default));
router.delete('/user/:id', controller_1.default.deleteUser.bind(controller_1.default));
router.put('/user/:id/password', controller_1.default.resetPassword.bind(controller_1.default));
// Role routes
router.get('/role/list', controller_1.default.getRoleList.bind(controller_1.default));
router.post('/role', controller_1.default.createRole.bind(controller_1.default));
router.put('/role/:id', controller_1.default.updateRole.bind(controller_1.default));
router.delete('/role/:id', controller_1.default.deleteRole.bind(controller_1.default));
router.get('/role/:id/menus', controller_1.default.getRoleMenus.bind(controller_1.default));
router.post('/role/:id/menus', controller_1.default.assignRoleMenus.bind(controller_1.default));
// Menu routes
router.get('/menu/list', controller_1.default.getMenuList.bind(controller_1.default));
router.post('/menu', controller_1.default.createMenu.bind(controller_1.default));
router.put('/menu/:id', controller_1.default.updateMenu.bind(controller_1.default));
router.delete('/menu/:id', controller_1.default.deleteMenu.bind(controller_1.default));
// Dept routes
router.get('/dept/list', controller_1.default.getDeptList.bind(controller_1.default));
router.post('/dept', controller_1.default.createDept.bind(controller_1.default));
router.put('/dept/:id', controller_1.default.updateDept.bind(controller_1.default));
router.delete('/dept/:id', controller_1.default.deleteDept.bind(controller_1.default));
// Dict routes
router.get('/dict/list', controller_1.default.getDictList.bind(controller_1.default));
router.get('/dict/data/:dictCode', controller_1.default.getDictData.bind(controller_1.default));
router.post('/dict', controller_1.default.createDict.bind(controller_1.default));
router.post('/dict/data', controller_1.default.createDictData.bind(controller_1.default));
// Config routes
router.get('/config/list', controller_1.default.getConfigList.bind(controller_1.default));
router.post('/config', controller_1.default.createConfig.bind(controller_1.default));
router.put('/config/:id', controller_1.default.updateConfigById.bind(controller_1.default));
router.delete('/config/:id', controller_1.default.deleteConfig.bind(controller_1.default));
// Log routes
router.get('/log/list', controller_1.default.getLogList.bind(controller_1.default));
// Notice routes
router.get('/notice/list', controller_1.default.getNoticeList.bind(controller_1.default));
router.post('/notice', controller_1.default.createNotice.bind(controller_1.default));
router.put('/notice/:id', controller_1.default.updateNotice.bind(controller_1.default));
router.delete('/notice/:id', controller_1.default.deleteNotice.bind(controller_1.default));
exports.default = router;
//# sourceMappingURL=routes.js.map
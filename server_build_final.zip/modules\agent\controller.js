"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentController = void 0;
const uuid_1 = require("uuid");
const data_source_1 = require("../../config/data-source");
const agent_entity_1 = require("../../database/entities/agent.entity");
class AgentController {
    constructor() {
        this.agentRepo = data_source_1.AppDataSource.getRepository(agent_entity_1.AgentInfo);
        this.profitRepo = data_source_1.AppDataSource.getRepository(agent_entity_1.AgentProfit);
        this.withdrawRepo = data_source_1.AppDataSource.getRepository(agent_entity_1.AgentWithdraw);
    }
    // ============== Agent Info ==============
    async getAgentList(req, res, next) {
        try {
            const { page = 1, pageSize = 10, agentNo, agentName, status } = req.query;
            const skip = (Number(page) - 1) * Number(pageSize);
            const queryBuilder = this.agentRepo.createQueryBuilder('agent');
            if (agentNo)
                queryBuilder.andWhere('agent.agentNo LIKE :agentNo', { agentNo: `%${agentNo}%` });
            if (agentName)
                queryBuilder.andWhere('agent.agentName LIKE :agentName', { agentName: `%${agentName}%` });
            if (status !== undefined)
                queryBuilder.andWhere('agent.status = :status', { status });
            const [list, total] = await queryBuilder
                .skip(skip)
                .take(Number(pageSize))
                .orderBy('agent.createTime', 'DESC')
                .getManyAndCount();
            res.json({ code: 0, message: 'success', data: { list, total }, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async getAgentById(req, res, next) {
        try {
            const { id } = req.params;
            const agent = await this.agentRepo.findOne({ where: { id } });
            if (!agent)
                return res.status(404).json({ code: 404, message: '代理商不存在', data: null, timestamp: new Date().toISOString() });
            res.json({ code: 0, message: 'success', data: agent, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async createAgent(req, res, next) {
        try {
            const { agentName, parentId, level, contactName, contactPhone, contactEmail, province, city, district, address, bankName, bankAccount, bankUsername } = req.body;
            const agentNo = 'A' + Date.now();
            const agent = this.agentRepo.create({
                id: (0, uuid_1.v4)(),
                agentNo,
                agentName,
                parentId,
                level: level || 1,
                contactName,
                contactPhone,
                contactEmail,
                province,
                city,
                district,
                address,
                bankName,
                bankAccount,
                bankUsername,
                status: 2, // Pending review
                createTime: new Date(),
                updateTime: new Date(),
            });
            await this.agentRepo.save(agent);
            res.json({ code: 0, message: '创建成功', data: agent, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async updateAgent(req, res, next) {
        try {
            const { id } = req.params;
            const updateData = req.body;
            updateData.updateTime = new Date();
            await this.agentRepo.update(id, updateData);
            res.json({ code: 0, message: '更新成功', data: null, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async reviewAgent(req, res, next) {
        try {
            const { id } = req.params;
            const { status, reviewRemark } = req.body;
            await this.agentRepo.update(id, {
                status,
                reviewRemark,
                reviewTime: new Date(),
                reviewUserId: req.user?.userId,
                updateTime: new Date(),
            });
            res.json({ code: 0, message: '审核成功', data: null, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    // ============== Profit Management ==============
    async getProfitList(req, res, next) {
        try {
            const { page = 1, pageSize = 10, agentNo, tradeType } = req.query;
            const skip = (Number(page) - 1) * Number(pageSize);
            const queryBuilder = this.profitRepo.createQueryBuilder('profit');
            if (agentNo)
                queryBuilder.andWhere('profit.agentNo = :agentNo', { agentNo });
            if (tradeType)
                queryBuilder.andWhere('profit.tradeType = :tradeType', { tradeType });
            const [list, total] = await queryBuilder.skip(skip).take(Number(pageSize)).orderBy('profit.createTime', 'DESC').getManyAndCount();
            res.json({ code: 0, message: 'success', data: { list, total }, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    // ============== Withdraw Management ==============
    async getWithdrawList(req, res, next) {
        try {
            const { page = 1, pageSize = 10, agentNo, status } = req.query;
            const skip = (Number(page) - 1) * Number(pageSize);
            const queryBuilder = this.withdrawRepo.createQueryBuilder('withdraw');
            if (agentNo)
                queryBuilder.andWhere('withdraw.agentNo = :agentNo', { agentNo });
            if (status !== undefined)
                queryBuilder.andWhere('withdraw.status = :status', { status });
            const [list, total] = await queryBuilder.skip(skip).take(Number(pageSize)).orderBy('withdraw.createTime', 'DESC').getManyAndCount();
            res.json({ code: 0, message: 'success', data: { list, total }, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async createWithdraw(req, res, next) {
        try {
            const { agentNo, amount, bankName, bankAccount, bankUsername } = req.body;
            const withdrawNo = 'W' + Date.now();
            const fee = amount * 0.006; // 0.6% fee
            const actualAmount = amount - fee;
            const withdraw = this.withdrawRepo.create({
                id: (0, uuid_1.v4)(),
                withdrawNo,
                agentNo,
                amount,
                fee,
                actualAmount,
                bankName,
                bankAccount,
                bankUsername,
                status: 0,
                createTime: new Date(),
                updateTime: new Date(),
            });
            await this.withdrawRepo.save(withdraw);
            // Freeze the amount
            const agent = await this.agentRepo.findOne({ where: { agentNo } });
            if (agent) {
                await this.agentRepo.update(agent.id, {
                    balance: agent.balance - amount,
                    frozenBalance: agent.frozenBalance + amount,
                    updateTime: new Date(),
                });
            }
            res.json({ code: 0, message: '申请成功', data: withdraw, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async reviewWithdraw(req, res, next) {
        try {
            const { id } = req.params;
            const { status, failReason } = req.body;
            const withdraw = await this.withdrawRepo.findOne({ where: { id } });
            if (!withdraw)
                return res.status(404).json({ code: 404, message: '提现记录不存在', data: null, timestamp: new Date().toISOString() });
            if (status === 2) { // Success
                await this.withdrawRepo.update(id, {
                    status: 2,
                    completeTime: new Date(),
                    updateTime: new Date(),
                });
                const agent = await this.agentRepo.findOne({ where: { agentNo: withdraw.agentNo } });
                if (agent) {
                    await this.agentRepo.update(agent.id, {
                        frozenBalance: agent.frozenBalance - withdraw.amount,
                        updateTime: new Date(),
                    });
                }
            }
            else if (status === 3) { // Failed
                await this.withdrawRepo.update(id, {
                    status: 3,
                    failReason,
                    updateTime: new Date(),
                });
                const agent = await this.agentRepo.findOne({ where: { agentNo: withdraw.agentNo } });
                if (agent) {
                    await this.agentRepo.update(agent.id, {
                        balance: agent.balance + withdraw.amount,
                        frozenBalance: agent.frozenBalance - withdraw.amount,
                        updateTime: new Date(),
                    });
                }
            }
            res.json({ code: 0, message: '审核成功', data: null, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.AgentController = AgentController;
exports.default = new AgentController();
//# sourceMappingURL=controller.js.map
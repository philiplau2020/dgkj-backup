"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const controller_1 = __importDefault(require("./controller"));
const auth_middleware_1 = require("../../common/middleware/auth.middleware");
const router = (0, express_1.Router)();
router.use(auth_middleware_1.authGuard);
// ========== IMPORTANT: Routes are matched in order! ==========
// 1. First: exact match routes (must be before :id routes)
router.get('/list', controller_1.default.getChannelList.bind(controller_1.default));
router.get('/channel/list', controller_1.default.getChannelList.bind(controller_1.default));
router.get('/channel-mch/list', controller_1.default.getChannelMchList.bind(controller_1.default));
router.post('/channel-mch', controller_1.default.createChannelMch.bind(controller_1.default));
router.get('/channel/channel/list', controller_1.default.getChannelList.bind(controller_1.default));
router.get('/pool/channel/list', controller_1.default.getPoolList.bind(controller_1.default));
router.get('/pool/channel/info', controller_1.default.getChannelById.bind(controller_1.default));
router.get('/pool/channel/stats', controller_1.default.getChannelStats.bind(controller_1.default));
router.post('/pool/channel/add', controller_1.default.createPool.bind(controller_1.default));
router.get('/pool/list', controller_1.default.getPoolList.bind(controller_1.default));
router.get('/strategy/list', controller_1.default.getStrategyList.bind(controller_1.default));
router.post('/strategy', controller_1.default.createStrategy.bind(controller_1.default));
// 2. Second: parameterized routes (:id routes) - AFTER exact matches
router.get('/channel/:id', controller_1.default.getChannelById.bind(controller_1.default));
router.put('/channel/:id', controller_1.default.updateChannel.bind(controller_1.default));
router.put('/strategy/:id', controller_1.default.updateStrategy.bind(controller_1.default));
// 3. Third: simple POST routes
router.post('/channel', controller_1.default.createChannel.bind(controller_1.default));
router.post('/mch', controller_1.default.createChannelMch.bind(controller_1.default));
router.post('/pool', controller_1.default.createPool.bind(controller_1.default));
// 4. Fourth: other routes
router.get('/channel/recommend', controller_1.default.getRecommendedChannel.bind(controller_1.default));
router.get('/channel/stats', controller_1.default.getChannelStats.bind(controller_1.default));
router.get('/recommend', controller_1.default.getRecommendedChannel.bind(controller_1.default));
exports.default = router;
//# sourceMappingURL=routes.js.map
"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const controller_1 = __importDefault(require("./controller"));
const auth_middleware_1 = require("../../common/middleware/auth.middleware");
const router = (0, express_1.Router)();
router.use(auth_middleware_1.authGuard);
// Pay Order routes
router.get('/list', controller_1.default.getOrderList.bind(controller_1.default));
router.get('/:id', controller_1.default.getOrderById.bind(controller_1.default));
router.post('/', controller_1.default.createOrder.bind(controller_1.default));
router.put('/:id/close', controller_1.default.closeOrder.bind(controller_1.default));
// Refund routes
router.get('/refund/list', controller_1.default.getRefundList.bind(controller_1.default));
router.post('/refund', controller_1.default.createRefund.bind(controller_1.default));
// Transfer routes
router.get('/transfer/list', controller_1.default.getTransferList.bind(controller_1.default));
router.post('/transfer', controller_1.default.createTransfer.bind(controller_1.default));
// Notify routes
router.get('/notify/list', controller_1.default.getNotifyList.bind(controller_1.default));
router.post('/notify/:id/resend', controller_1.default.resendNotify.bind(controller_1.default));
exports.default = router;
//# sourceMappingURL=routes.js.map
export declare class OpApiQuota {
    id: string;
    appId: string;
    developerId: string;
    quotaType: 'daily' | 'monthly' | 'total';
    apiCode: string;
    quotaLimit: number;
    quotaUsed: number;
    resetTime: Date;
    rateLimitWindow: 'second' | 'minute' | 'hour' | 'day' | 'month';
    rateLimit: number;
    rateLimitUsed: number;
    createTime: Date;
    updateTime: Date;
}
//# sourceMappingURL=quota.entity.d.ts.map
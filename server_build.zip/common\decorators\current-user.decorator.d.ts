import { Request } from 'express';
export declare function CurrentUser(req: Request): any;
export declare function getCurrentUser(req: Request): import("../middleware/auth.middleware").JwtPayload;
//# sourceMappingURL=current-user.decorator.d.ts.map
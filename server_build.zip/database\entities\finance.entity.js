"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AccountStatement = exports.AccountWithdraw = exports.AccountSettlement = exports.AccountRecord = exports.AccountInfo = exports.SettleStatus = exports.WithdrawStatus = exports.AccountType = void 0;
const typeorm_1 = require("typeorm");
var AccountType;
(function (AccountType) {
    AccountType[AccountType["MERCHANT"] = 1] = "MERCHANT";
    AccountType[AccountType["AGENT"] = 2] = "AGENT";
    AccountType[AccountType["PLATFORM"] = 3] = "PLATFORM";
})(AccountType || (exports.AccountType = AccountType = {}));
var WithdrawStatus;
(function (WithdrawStatus) {
    WithdrawStatus[WithdrawStatus["PENDING"] = 0] = "PENDING";
    WithdrawStatus[WithdrawStatus["PROCESSING"] = 1] = "PROCESSING";
    WithdrawStatus[WithdrawStatus["SUCCESS"] = 2] = "SUCCESS";
    WithdrawStatus[WithdrawStatus["FAILED"] = 3] = "FAILED";
})(WithdrawStatus || (exports.WithdrawStatus = WithdrawStatus = {}));
var SettleStatus;
(function (SettleStatus) {
    SettleStatus[SettleStatus["PENDING"] = 0] = "PENDING";
    SettleStatus[SettleStatus["PROCESSING"] = 1] = "PROCESSING";
    SettleStatus[SettleStatus["SUCCESS"] = 2] = "SUCCESS";
    SettleStatus[SettleStatus["FAILED"] = 3] = "FAILED";
})(SettleStatus || (exports.SettleStatus = SettleStatus = {}));
let AccountInfo = class AccountInfo {
};
exports.AccountInfo = AccountInfo;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], AccountInfo.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_no', length: 32, unique: true }),
    __metadata("design:type", String)
], AccountInfo.prototype, "accountNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'owner_no', length: 32 }),
    __metadata("design:type", String)
], AccountInfo.prototype, "ownerNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'owner_name', length: 128 }),
    __metadata("design:type", String)
], AccountInfo.prototype, "ownerName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], AccountInfo.prototype, "accountType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'balance', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], AccountInfo.prototype, "balance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'frozen_balance', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], AccountInfo.prototype, "frozenBalance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'available_balance', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], AccountInfo.prototype, "availableBalance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_income', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], AccountInfo.prototype, "totalIncome", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_expense', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], AccountInfo.prototype, "totalExpense", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], AccountInfo.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], AccountInfo.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], AccountInfo.prototype, "updateTime", void 0);
exports.AccountInfo = AccountInfo = __decorate([
    (0, typeorm_1.Entity)('account_info')
], AccountInfo);
let AccountRecord = class AccountRecord {
};
exports.AccountRecord = AccountRecord;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], AccountRecord.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'record_no', length: 32, unique: true }),
    __metadata("design:type", String)
], AccountRecord.prototype, "recordNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_no', length: 32 }),
    __metadata("design:type", String)
], AccountRecord.prototype, "accountNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'order_no', length: 32, nullable: true }),
    __metadata("design:type", String)
], AccountRecord.prototype, "orderNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'biz_no', length: 32, nullable: true }),
    __metadata("design:type", String)
], AccountRecord.prototype, "bizNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'biz_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], AccountRecord.prototype, "bizType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'biz_type_name', length: 64 }),
    __metadata("design:type", String)
], AccountRecord.prototype, "bizTypeName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], AccountRecord.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'balance_before', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], AccountRecord.prototype, "balanceBefore", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'balance_after', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], AccountRecord.prototype, "balanceAfter", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'change_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], AccountRecord.prototype, "changeType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], AccountRecord.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], AccountRecord.prototype, "createTime", void 0);
exports.AccountRecord = AccountRecord = __decorate([
    (0, typeorm_1.Entity)('account_record')
], AccountRecord);
let AccountSettlement = class AccountSettlement {
};
exports.AccountSettlement = AccountSettlement;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], AccountSettlement.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'settle_no', length: 32, unique: true }),
    __metadata("design:type", String)
], AccountSettlement.prototype, "settleNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_no', length: 32 }),
    __metadata("design:type", String)
], AccountSettlement.prototype, "accountNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'owner_no', length: 32 }),
    __metadata("design:type", String)
], AccountSettlement.prototype, "ownerNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'owner_name', length: 128 }),
    __metadata("design:type", String)
], AccountSettlement.prototype, "ownerName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_name', length: 64 }),
    __metadata("design:type", String)
], AccountSettlement.prototype, "bankName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_account', length: 32 }),
    __metadata("design:type", String)
], AccountSettlement.prototype, "bankAccount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_username', length: 64 }),
    __metadata("design:type", String)
], AccountSettlement.prototype, "bankUsername", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], AccountSettlement.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fee', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], AccountSettlement.prototype, "fee", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'actual_amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], AccountSettlement.prototype, "actualAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'settle_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], AccountSettlement.prototype, "settleType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'settle_cycle', length: 32 }),
    __metadata("design:type", String)
], AccountSettlement.prototype, "settleCycle", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: SettleStatus.PENDING }),
    __metadata("design:type", Number)
], AccountSettlement.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fail_reason', length: 255, nullable: true }),
    __metadata("design:type", String)
], AccountSettlement.prototype, "failReason", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'settle_time', nullable: true }),
    __metadata("design:type", Date)
], AccountSettlement.prototype, "settleTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'complete_time', nullable: true }),
    __metadata("design:type", Date)
], AccountSettlement.prototype, "completeTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], AccountSettlement.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], AccountSettlement.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], AccountSettlement.prototype, "updateTime", void 0);
exports.AccountSettlement = AccountSettlement = __decorate([
    (0, typeorm_1.Entity)('account_settlement')
], AccountSettlement);
let AccountWithdraw = class AccountWithdraw {
};
exports.AccountWithdraw = AccountWithdraw;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], AccountWithdraw.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'withdraw_no', length: 32, unique: true }),
    __metadata("design:type", String)
], AccountWithdraw.prototype, "withdrawNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_no', length: 32 }),
    __metadata("design:type", String)
], AccountWithdraw.prototype, "accountNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'owner_no', length: 32 }),
    __metadata("design:type", String)
], AccountWithdraw.prototype, "ownerNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'owner_name', length: 128 }),
    __metadata("design:type", String)
], AccountWithdraw.prototype, "ownerName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], AccountWithdraw.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fee', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], AccountWithdraw.prototype, "fee", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'actual_amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], AccountWithdraw.prototype, "actualAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_name', length: 64 }),
    __metadata("design:type", String)
], AccountWithdraw.prototype, "bankName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_account', length: 32 }),
    __metadata("design:type", String)
], AccountWithdraw.prototype, "bankAccount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_username', length: 64 }),
    __metadata("design:type", String)
], AccountWithdraw.prototype, "bankUsername", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: WithdrawStatus.PENDING }),
    __metadata("design:type", Number)
], AccountWithdraw.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fail_reason', length: 255, nullable: true }),
    __metadata("design:type", String)
], AccountWithdraw.prototype, "failReason", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'complete_time', nullable: true }),
    __metadata("design:type", Date)
], AccountWithdraw.prototype, "completeTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], AccountWithdraw.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], AccountWithdraw.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], AccountWithdraw.prototype, "updateTime", void 0);
exports.AccountWithdraw = AccountWithdraw = __decorate([
    (0, typeorm_1.Entity)('account_withdraw')
], AccountWithdraw);
let AccountStatement = class AccountStatement {
};
exports.AccountStatement = AccountStatement;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], AccountStatement.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'statement_no', length: 32, unique: true }),
    __metadata("design:type", String)
], AccountStatement.prototype, "statementNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_no', length: 32 }),
    __metadata("design:type", String)
], AccountStatement.prototype, "accountNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'statement_date', type: 'date' }),
    __metadata("design:type", Date)
], AccountStatement.prototype, "statementDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'begin_balance', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], AccountStatement.prototype, "beginBalance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_income', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], AccountStatement.prototype, "totalIncome", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_expense', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], AccountStatement.prototype, "totalExpense", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'end_balance', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], AccountStatement.prototype, "endBalance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'order_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], AccountStatement.prototype, "orderCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'success_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], AccountStatement.prototype, "successCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'refund_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], AccountStatement.prototype, "refundCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], AccountStatement.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], AccountStatement.prototype, "createTime", void 0);
exports.AccountStatement = AccountStatement = __decorate([
    (0, typeorm_1.Entity)('account_statement')
], AccountStatement);
//# sourceMappingURL=finance.entity.js.map
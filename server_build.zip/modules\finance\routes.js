"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const controller_1 = __importDefault(require("./controller"));
const auth_middleware_1 = require("../../common/middleware/auth.middleware");
const router = (0, express_1.Router)();
router.use(auth_middleware_1.authGuard);
// Account routes
router.get('/list', controller_1.default.getAccountList.bind(controller_1.default));
router.get('/:id', controller_1.default.getAccountById.bind(controller_1.default));
// Record routes
router.get('/record/list', controller_1.default.getRecordList.bind(controller_1.default));
// Settlement routes
router.get('/settlement/list', controller_1.default.getSettlementList.bind(controller_1.default));
router.post('/settlement', controller_1.default.createSettlement.bind(controller_1.default));
router.put('/settlement/:id/review', controller_1.default.reviewSettlement.bind(controller_1.default));
// Withdraw routes
router.get('/withdraw/list', controller_1.default.getWithdrawList.bind(controller_1.default));
router.post('/withdraw', controller_1.default.createWithdraw.bind(controller_1.default));
// Statement routes
router.get('/statement/list', controller_1.default.getStatementList.bind(controller_1.default));
exports.default = router;
//# sourceMappingURL=routes.js.map
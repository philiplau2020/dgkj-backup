"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.responseInterceptor = responseInterceptor;
function responseInterceptor(req, res, next) {
    const originalJson = res.json.bind(res);
    res.json = function (body) {
        if (body && typeof body === 'object' && 'code' in body) {
            return originalJson(body);
        }
        const response = {
            code: res.statusCode >= 400 ? res.statusCode : 0,
            message: res.statusCode >= 400 ? 'Error' : 'Success',
            data: body,
            timestamp: new Date().toISOString(),
        };
        return originalJson(response);
    };
    next();
}
//# sourceMappingURL=response.interceptor.js.map
"use strict";
/**
 * DGKJ 支付平台 - 银联支付通道完整实现
 *
 * 支持: 银联二维码、APP支付、网关支付、控件支付
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnionPayChannel = void 0;
const axios_1 = __importDefault(require("axios"));
const crypto = __importStar(require("crypto"));
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const interface_1 = require("./interface");
class UnionPayChannel {
    constructor() {
        this.channelCode = interface_1.ChannelCode.UNIONPAY;
        this.channelName = '银联支付';
        this.supportedPayWays = [
            interface_1.PayWay.UNION_QR,
            interface_1.PayWay.UNION_APP,
            interface_1.PayWay.UNION_WAP,
            interface_1.PayWay.UNION_BANK,
            interface_1.PayWay.UNION_JK,
        ];
        this.config = {
            code: '',
            name: '',
            appId: '',
            appSecret: '',
            mchId: '',
            apiKey: '',
        };
        this.certPath = '';
        this.privateKey = '';
        this.publicKey = '';
    }
    // 银联支付 API 地址
    getBaseUrl() {
        return this.config.sandbox
            ? 'https://gateway.95516.com/sandbox/api'
            : 'https://gateway.95516.com/api';
    }
    initialize(config) {
        this.config = {
            code: interface_1.ChannelCode.UNIONPAY,
            name: '银联支付',
            appId: config.appId,
            appSecret: config.appSecret,
            mchId: config.mchId,
            apiKey: config.apiKey,
            privateKey: config.privateKey,
            publicKey: config.publicKey,
            sandbox: config.sandbox,
            timeout: config.timeout || 30,
            extra: config.extra,
        };
        // 加载证书
        if (config.certPath) {
            this.loadCertificates(config.certPath);
        }
    }
    loadCertificates(certPath) {
        try {
            if (fs.existsSync(path.join(certPath, 'acp_test_sign.pfx'))) {
                // 测试环境证书
                this.certPath = path.join(certPath, 'acp_test_sign.pfx');
            }
            else if (fs.existsSync(path.join(certPath, 'acp_prod_sign.pfx'))) {
                // 生产环境证书
                this.certPath = path.join(certPath, 'acp_prod_sign.pfx');
            }
        }
        catch (error) {
            console.error('加载银联证书失败:', error);
        }
    }
    /**
     * 执行支付
     */
    async pay(request) {
        try {
            const params = await this.buildPayParams(request);
            const response = await this.request('/trade/pay', params);
            if (response.respCode === '00') {
                return this.buildPaySuccessResponse(request, response);
            }
            else {
                return this.buildPayFailResponse(response);
            }
        }
        catch (error) {
            return {
                success: false,
                errorCode: 'PAY_FAILED',
                errorMsg: error.message || '支付创建失败',
            };
        }
    }
    buildPaySuccessResponse(request, response) {
        let payUrl = '';
        let qrCode = '';
        let appParams;
        let h5Url = '';
        switch (request.payWay) {
            case interface_1.PayWay.UNION_QR:
                payUrl = response.qrCode || response.payData;
                qrCode = payUrl;
                break;
            case interface_1.PayWay.UNION_APP:
                appParams = this.buildAppPayParams(response);
                break;
            case interface_1.PayWay.UNION_WAP:
            case interface_1.PayWay.UNION_BANK:
                h5Url = response.payUrl || response.mwebUrl || response.payData;
                break;
            case interface_1.PayWay.UNION_JK:
                appParams = this.buildSdkPayParams(response);
                break;
        }
        return {
            success: true,
            orderNo: request.orderNo,
            channelOrderNo: response.tn || response.orderId || response.queryId,
            payUrl,
            qrCode,
            appParams,
            h5Url,
            expireTime: new Date(Date.now() + 2 * 60 * 60 * 1000),
        };
    }
    buildAppPayParams(response) {
        return {
            version: response.version || '5.1.0',
            tn: response.tn,
            certId: response.certId,
            signature: response.signature,
            merchantId: response.merchantId,
            orderId: response.orderId,
            txnTime: response.txnTime,
            txnAmt: response.txnAmt,
        };
    }
    buildSdkPayParams(response) {
        return {
            version: response.version || '5.1.0',
            tn: response.tn,
            certId: response.certId,
            signature: response.signature,
        };
    }
    buildPayFailResponse(response) {
        return {
            success: false,
            errorCode: response.respCode || 'UNKNOWN',
            errorMsg: response.respMsg || '支付创建失败',
        };
    }
    /**
     * 查询订单
     */
    async query(request) {
        try {
            const params = await this.buildQueryParams(request);
            const response = await this.request('/trade/query', params);
            if (response.respCode === '00') {
                return {
                    success: true,
                    status: this.mapQueryStatus(response.origRespCode),
                    channelOrderNo: response.queryId,
                    paidTime: response.payTime ? new Date(response.payTime) : undefined,
                    rawResponse: response,
                };
            }
            else {
                return {
                    success: false,
                    errorCode: response.respCode,
                    errorMsg: response.respMsg,
                    status: interface_1.PayStatus.PENDING,
                };
            }
        }
        catch (error) {
            return {
                success: false,
                errorCode: 'QUERY_FAILED',
                errorMsg: error.message,
                status: interface_1.PayStatus.PENDING,
            };
        }
    }
    mapQueryStatus(respCode) {
        switch (respCode) {
            case '00':
                return interface_1.PayStatus.SUCCESS;
            case '03':
            case '04':
            case '05':
                return interface_1.PayStatus.PENDING;
            case '34':
                return interface_1.PayStatus.REFUNDING;
            default:
                return interface_1.PayStatus.FAILED;
        }
    }
    /**
     * 申请退款
     */
    async refund(request) {
        try {
            const params = await this.buildRefundParams(request);
            const response = await this.request('/trade/refund', params);
            if (response.respCode === '00') {
                return {
                    success: true,
                    refundNo: request.refundNo,
                    channelRefundNo: response.refundId || response.queryId,
                    status: interface_1.RefundStatus.SUCCESS,
                    refundAmount: parseInt(response.refundAmt || response.txnAmt),
                    refundTime: new Date(),
                };
            }
            else {
                return {
                    success: false,
                    errorCode: response.respCode,
                    errorMsg: response.respMsg || '退款失败',
                    status: interface_1.RefundStatus.FAILED,
                };
            }
        }
        catch (error) {
            return {
                success: false,
                errorCode: 'REFUND_FAILED',
                errorMsg: error.message,
                status: interface_1.RefundStatus.FAILED,
            };
        }
    }
    /**
     * 转账 (银联云闪付不支持，代理到其他通道)
     */
    async transfer(request) {
        // 银联通道暂不支持直接转账，建议使用代付通道
        return {
            success: false,
            errorCode: 'UNSUPPORTED',
            errorMsg: '银联通道暂不支持转账功能，请使用代付通道',
            status: 'failed',
        };
    }
    /**
     * 验证回调签名
     */
    async verifyCallback(data, headers) {
        try {
            if (!data.signature && !data.sign) {
                return { success: false, errorMsg: '缺少签名' };
            }
            const signature = data.signature || data.sign;
            const signData = { ...data };
            delete signData.signature;
            delete signData.sign;
            const signStr = this.getSignString(signData);
            const isValid = this.verifySign(signStr, signature);
            if (!isValid) {
                return { success: false, errorMsg: '签名验证失败' };
            }
            if (data.respCode && data.respCode !== '00') {
                return { success: false, errorMsg: data.respMsg };
            }
            return { success: true };
        }
        catch (error) {
            return { success: false, errorMsg: error.message };
        }
    }
    /**
     * 解析回调数据
     */
    async parseCallback(data) {
        let status;
        let notifyType = 'pay';
        // 根据交易类型判断
        const txnType = data.txnType || data.bizType;
        if (txnType === '04' || data.origTxnType === '01') {
            // 退款
            notifyType = 'refund';
            const refundStatus = data.respCode === '00' ? interface_1.RefundStatus.SUCCESS : interface_1.RefundStatus.FAILED;
            status = refundStatus;
        }
        else {
            // 支付
            status = this.mapCallbackStatus(data.respCode);
        }
        return {
            channelCode: interface_1.ChannelCode.UNIONPAY,
            notifyType,
            orderNo: data.orderId || data.origOrderId,
            channelOrderNo: data.queryId,
            status,
            amount: parseInt(data.txnAmt || '0'),
            paidAmount: data.receiveAmt ? parseInt(data.receiveAmt) : undefined,
            paidTime: data.payTime ? new Date(data.payTime) : undefined,
            attach: data.attach,
            rawData: data,
        };
    }
    mapCallbackStatus(respCode) {
        switch (respCode) {
            case '00':
                return interface_1.PayStatus.SUCCESS;
            case '03':
            case '04':
            case '05':
                return interface_1.PayStatus.PENDING;
            default:
                return interface_1.PayStatus.FAILED;
        }
    }
    responseCallbackSuccess() {
        return JSON.stringify({ respCode: '00', respMsg: '成功' });
    }
    responseCallbackFail() {
        return JSON.stringify({ respCode: '01', respMsg: '失败' });
    }
    // ==================== 私有方法 ====================
    async buildPayParams(request) {
        const version = '5.1.0';
        const encoding = 'UTF-8';
        const bizType = this.getBizType(request.payWay);
        const txnType = '01'; // 消费
        const txnSubType = this.getTxnSubType(request.payWay);
        const channelType = '07'; // 互联网
        const currencyCode = '156';
        const params = {
            version,
            encoding,
            bizType,
            txnType,
            txnSubType,
            channelType,
            merId: this.config.mchId,
            orderId: request.orderNo,
            txnTime: this.formatTime(request.orderTime || new Date()),
            txnAmt: request.amount.toString(),
            currencyCode,
            subject: request.subject,
            signatureAlgorithm: '01', // RSA
        };
        // 根据支付方式添加特定参数
        this.addPayWayParams(params, request);
        // 签名
        params.signature = await this.sign(params);
        return params;
    }
    getBizType(payWay) {
        const bizTypeMap = {
            [interface_1.PayWay.UNION_QR]: '000301',
            [interface_1.PayWay.UNION_APP]: '000201',
            [interface_1.PayWay.UNION_WAP]: '000202',
            [interface_1.PayWay.UNION_BANK]: '000200',
            [interface_1.PayWay.UNION_JK]: '000301',
        };
        return bizTypeMap[payWay] || '000301';
    }
    getTxnSubType(payWay) {
        const txnSubTypeMap = {
            [interface_1.PayWay.UNION_QR]: '06',
            [interface_1.PayWay.UNION_APP]: '01',
            [interface_1.PayWay.UNION_WAP]: '02',
            [interface_1.PayWay.UNION_BANK]: '03',
            [interface_1.PayWay.UNION_JK]: '06',
        };
        return txnSubTypeMap[payWay] || '06';
    }
    addPayWayParams(params, request) {
        switch (request.payWay) {
            case interface_1.PayWay.UNION_WAP:
            case interface_1.PayWay.UNION_BANK:
                params.frontUrl = request.returnUrl || '';
                break;
            case interface_1.PayWay.UNION_APP:
                params.signNo = request.openId || ''; // 令牌
                break;
            default:
                params.backUrl = request.notifyUrl || '';
        }
        if (request.notifyUrl) {
            params.backUrl = request.notifyUrl;
        }
    }
    async buildQueryParams(request) {
        const params = {
            version: '5.1.0',
            encoding: 'UTF-8',
            bizType: '000301',
            txnType: '00',
            txnSubType: '06',
            channelType: '07',
            merId: this.config.mchId,
            orderId: request.orderNo,
            signatureAlgorithm: '01',
        };
        if (request.channelOrderNo) {
            params.queryId = request.channelOrderNo;
            params.orderId = '';
        }
        params.signature = await this.sign(params);
        return params;
    }
    async buildRefundParams(request) {
        const params = {
            version: '5.1.0',
            encoding: 'UTF-8',
            bizType: '000301',
            txnType: '04', // 退款
            txnSubType: '00',
            channelType: '07',
            merId: this.config.mchId,
            orderId: request.orderNo,
            txnTime: '',
            txnAmt: request.refundAmount.toString(),
            refundAmt: request.refundAmount.toString(),
            outRefundId: request.refundNo,
            origTxnType: '01',
            signatureAlgorithm: '01',
        };
        params.signature = await this.sign(params);
        return params;
    }
    async request(path, params) {
        const url = `${this.getBaseUrl()}${path}`;
        const config = {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
            },
            timeout: (this.config.timeout || 30) * 1000,
        };
        const response = await axios_1.default.post(url, this.buildFormData(params), config);
        return this.parseResponse(response.data);
    }
    buildFormData(params) {
        return Object.entries(params)
            .filter(([_, v]) => v !== undefined && v !== '')
            .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
            .join('&');
    }
    parseResponse(data) {
        if (typeof data === 'object') {
            return data;
        }
        if (typeof data === 'string' && data.includes('<')) {
            // XML 格式
            return this.parseXmlResponse(data);
        }
        try {
            return JSON.parse(data);
        }
        catch {
            return { respCode: 'UNKNOWN', respMsg: '响应解析失败' };
        }
    }
    parseXmlResponse(xml) {
        const result = {};
        const regex = /<(\w+)>([^<]*)/g;
        let match;
        while ((match = regex.exec(xml)) !== null) {
            const [, key, value] = match;
            result[key] = value;
        }
        return result;
    }
    getSignString(params) {
        const keys = Object.keys(params).sort();
        const pairs = [];
        for (const key of keys) {
            if (params[key] !== undefined && params[key] !== '' && key !== 'signature') {
                pairs.push(`${key}=${params[key]}`);
            }
        }
        return pairs.join('&');
    }
    async sign(params) {
        const signStr = this.getSignString(params);
        if (this.privateKey) {
            return this.signWithPrivateKey(signStr);
        }
        // 使用 MD5 签名 (仅用于测试)
        return crypto
            .createHash('sha256')
            .update(signStr + '&key=' + this.config.apiKey)
            .digest('hex')
            .toUpperCase();
    }
    signWithPrivateKey(data) {
        const sign = crypto.createSign('RSA-SHA256');
        sign.update(data);
        return sign.sign(this.privateKey, 'base64');
    }
    verifySign(data, signature) {
        if (!this.publicKey) {
            // 使用 API Key 验签
            const expectedSign = crypto
                .createHash('sha256')
                .update(data + '&key=' + this.config.apiKey)
                .digest('hex')
                .toUpperCase();
            return signature === expectedSign;
        }
        const verify = crypto.createVerify('RSA-SHA256');
        verify.update(data);
        return verify.verify(this.publicKey, signature, 'base64');
    }
    formatTime(date) {
        const pad = (n) => n.toString().padStart(2, '0');
        return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`;
    }
}
exports.UnionPayChannel = UnionPayChannel;
exports.default = new UnionPayChannel();
//# sourceMappingURL=unionpay-complete.js.map
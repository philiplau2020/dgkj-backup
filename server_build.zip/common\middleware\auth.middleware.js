"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authGuard = authGuard;
exports.roleGuard = roleGuard;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const global_exception_filter_1 = require("../filters/global-exception.filter");
function authGuard(req, res, next) {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader) {
            throw new global_exception_filter_1.UnauthorizedException('No authorization header');
        }
        const [type, token] = authHeader.split(' ');
        if (type !== 'Bearer' || !token) {
            throw new global_exception_filter_1.UnauthorizedException('Invalid authorization format');
        }
        const secret = process.env.JWT_SECRET || 'your-secret-key';
        const payload = jsonwebtoken_1.default.verify(token, secret);
        req.user = payload;
        next();
    }
    catch (error) {
        if (error instanceof jsonwebtoken_1.default.JsonWebTokenError) {
            next(new global_exception_filter_1.UnauthorizedException('Invalid token'));
        }
        else if (error instanceof jsonwebtoken_1.default.TokenExpiredError) {
            next(new global_exception_filter_1.UnauthorizedException('Token expired'));
        }
        else {
            next(error);
        }
    }
}
function roleGuard(...allowedRoles) {
    return (req, res, next) => {
        const user = req.user;
        if (!user) {
            return next(new global_exception_filter_1.UnauthorizedException('Not authenticated'));
        }
        if (allowedRoles.length && !allowedRoles.includes(user.role)) {
            return next(new global_exception_filter_1.ApiException(403, 'Insufficient permissions'));
        }
        next();
    };
}
//# sourceMappingURL=auth.middleware.js.map
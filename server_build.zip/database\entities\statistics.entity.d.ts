export declare enum StatisticsPeriod {
    DAILY = 1,
    WEEKLY = 2,
    MONTHLY = 3
}
export declare class StatTrade {
    id: string;
    statDate: Date;
    statType: StatisticsPeriod;
    mchNo: string;
    agentNo: string;
    channelCode: string;
    payType: string;
    totalCount: number;
    successCount: number;
    failCount: number;
    totalAmount: number;
    successAmount: number;
    failAmount: number;
    refundCount: number;
    refundAmount: number;
    feeAmount: number;
    profitAmount: number;
    createTime: Date;
}
export declare class StatMch {
    id: string;
    statDate: Date;
    mchNo: string;
    mchName: string;
    agentNo: string;
    totalCount: number;
    successCount: number;
    totalAmount: number;
    successAmount: number;
    feeAmount: number;
    refundCount: number;
    refundAmount: number;
    createTime: Date;
}
export declare class StatAgent {
    id: string;
    statDate: Date;
    agentNo: string;
    agentName: string;
    parentId: string;
    mchCount: number;
    totalTradeCount: number;
    successTradeCount: number;
    totalTradeAmount: number;
    successTradeAmount: number;
    profitAmount: number;
    withdrawAmount: number;
    balance: number;
    createTime: Date;
}
export declare class StatChannel {
    id: string;
    statDate: Date;
    channelCode: string;
    channelName: string;
    payType: string;
    totalCount: number;
    successCount: number;
    totalAmount: number;
    successAmount: number;
    feeAmount: number;
    successRate: number;
    createTime: Date;
}
export declare class StatFinance {
    id: string;
    statDate: Date;
    totalIncome: number;
    totalExpense: number;
    netIncome: number;
    totalBalance: number;
    settleAmount: number;
    withdrawAmount: number;
    profitAmount: number;
    createTime: Date;
}
//# sourceMappingURL=statistics.entity.d.ts.map
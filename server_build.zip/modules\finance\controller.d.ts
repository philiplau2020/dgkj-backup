import { Request, Response, NextFunction } from 'express';
export declare class FinanceController {
    private accountRepo;
    private recordRepo;
    private settlementRepo;
    private withdrawRepo;
    private statementRepo;
    getAccountList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getAccountById(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    getRecordList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getSettlementList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createSettlement(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    reviewSettlement(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    getWithdrawList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createWithdraw(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    getStatementList(req: Request, res: Response, next: NextFunction): Promise<void>;
}
declare const _default: FinanceController;
export default _default;
//# sourceMappingURL=controller.d.ts.map
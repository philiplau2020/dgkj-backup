"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OpWebhook = void 0;
/**
 * 开放平台Webhook实体
 */
const typeorm_1 = require("typeorm");
let OpWebhook = class OpWebhook {
};
exports.OpWebhook = OpWebhook;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], OpWebhook.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, comment: '应用ID' }),
    __metadata("design:type", String)
], OpWebhook.prototype, "appId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, comment: '开发者ID' }),
    __metadata("design:type", String)
], OpWebhook.prototype, "developerId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, comment: '商户号' }),
    __metadata("design:type", String)
], OpWebhook.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: ['payment', 'refund', 'transfer', 'account', 'alert'], comment: '事件类型' }),
    __metadata("design:type", String)
], OpWebhook.prototype, "eventType", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, comment: '回调地址' }),
    __metadata("design:type", String)
], OpWebhook.prototype, "callbackUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: ['active', 'disabled'], default: 'active', comment: '状态' }),
    __metadata("design:type", String)
], OpWebhook.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, nullable: true, comment: '签名密钥' }),
    __metadata("design:type", String)
], OpWebhook.prototype, "secretKey", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, comment: '累计推送次数' }),
    __metadata("design:type", Number)
], OpWebhook.prototype, "totalSent", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, comment: '成功次数' }),
    __metadata("design:type", Number)
], OpWebhook.prototype, "successCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, comment: '失败次数' }),
    __metadata("design:type", Number)
], OpWebhook.prototype, "failCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'datetime', nullable: true, comment: '最后推送时间' }),
    __metadata("design:type", Date)
], OpWebhook.prototype, "lastSentTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, comment: '最后响应码' }),
    __metadata("design:type", Number)
], OpWebhook.prototype, "lastResponseCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true, comment: '最后响应消息' }),
    __metadata("design:type", String)
], OpWebhook.prototype, "lastResponseMsg", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'datetime' }),
    __metadata("design:type", Date)
], OpWebhook.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ type: 'datetime' }),
    __metadata("design:type", Date)
], OpWebhook.prototype, "updateTime", void 0);
exports.OpWebhook = OpWebhook = __decorate([
    (0, typeorm_1.Entity)('op_webhook')
], OpWebhook);
//# sourceMappingURL=webhook.entity.js.map
import { Request, Response, NextFunction } from 'express';
export interface ApiResponse<T = any> {
    code: number;
    message: string;
    data: T;
    timestamp: string;
}
export declare class ApiException extends Error {
    code: number;
    message: string;
    data?: any;
    constructor(code?: number, message?: string, data?: any);
}
export declare class BadRequestException extends ApiException {
    constructor(message?: string);
}
export declare class UnauthorizedException extends ApiException {
    constructor(message?: string);
}
export declare class ForbiddenException extends ApiException {
    constructor(message?: string);
}
export declare class NotFoundException extends ApiException {
    constructor(message?: string);
}
export declare function errorHandler(err: Error | ApiException, req: Request, res: Response, next: NextFunction): void;
//# sourceMappingURL=global-exception.filter.d.ts.map
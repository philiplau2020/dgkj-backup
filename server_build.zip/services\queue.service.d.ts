/**
 * DGKJ 支付平台 - 消息队列服务
 *
 * 支持 RabbitMQ 和内存队列（降级方案）
 */
import { EventEmitter } from 'events';
interface Message<T = any> {
    id: string;
    type: string;
    data: T;
    timestamp: number;
    retryCount: number;
    maxRetries?: number;
}
interface QueueOptions {
    name: string;
    durable?: boolean;
    maxRetries?: number;
    retryDelay?: number;
}
interface ProducerOptions {
    persistent?: boolean;
    compress?: boolean;
}
declare class MemoryQueue<T = any> extends EventEmitter {
    private queue;
    private processing;
    private consumers;
    private intervalId;
    private options;
    constructor(options: QueueOptions);
    private startProcessing;
    private processQueue;
    private handleError;
    publish(message: Omit<Message<T>, 'id' | 'timestamp' | 'retryCount'>): Promise<void>;
    subscribe(handler: (msg: Message<T>) => Promise<void>): Promise<void>;
    ack(messageId: string): Promise<void>;
    nack(messageId: string): Promise<void>;
    purge(): Promise<number>;
    get length(): number;
    close(): void;
}
declare class RabbitMQQueue<T = any> extends EventEmitter {
    private channel;
    private connection;
    private options;
    private isConnected;
    constructor(options: QueueOptions);
    connect(url?: string): Promise<void>;
    publish(message: Omit<Message<T>, 'id' | 'timestamp' | 'retryCount'>): Promise<void>;
    subscribe(handler: (msg: Message<T>) => Promise<void>): Promise<void>;
    private handleError;
    purge(): Promise<number>;
    close(): Promise<void>;
    get connected(): boolean;
}
type QueueType = 'memory' | 'rabbitmq';
declare class MessageQueueService {
    private queues;
    private useRabbitMQ;
    /**
     * 初始化消息队列
     */
    initialize(type?: QueueType, rabbitmqUrl?: string): Promise<void>;
    /**
     * 获取或创建队列
     */
    getQueue<T = any>(name: string, options?: QueueOptions): Promise<MemoryQueue<T> | RabbitMQQueue<T>>;
    /**
     * 发送消息
     */
    publish<T = any>(queueName: string, type: string, data: T, options?: ProducerOptions): Promise<void>;
    /**
     * 订阅消息
     */
    subscribe<T = any>(queueName: string, handler: (msg: Message<T>) => Promise<void>): Promise<void>;
    /**
     * 关闭所有队列
     */
    close(): Promise<void>;
}
export declare const QueueNames: {
    PAY_NOTIFY: string;
    PAY_RESULT: string;
    REFUND_PROCESS: string;
    REFUND_NOTIFY: string;
    SMS_SEND: string;
    EMAIL_SEND: string;
    DINGTALK_NOTIFY: string;
    WECOM_NOTIFY: string;
    STAT_TRADE: string;
    STAT_USER: string;
    SETTLEMENT_PROCESS: string;
    LOG_RECORD: string;
};
export declare const messageQueueService: MessageQueueService;
export default messageQueueService;
//# sourceMappingURL=queue.service.d.ts.map
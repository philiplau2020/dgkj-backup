import { Express } from 'express';
export default function setupSwagger(app: Express): void;
//# sourceMappingURL=swagger.d.ts.map
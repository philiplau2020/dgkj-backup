"use strict";
/**
 * DGKJ 支付平台 - 设备管理服务
 *
 * 支持设备注册、激活、绑定、解绑、固件管理
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceService = void 0;
const uuid_1 = require("uuid");
const qrcode_1 = __importDefault(require("qrcode"));
const data_source_1 = require("../../config/data-source");
const device_entity_1 = require("../../database/entities/device.entity");
const op_code_1 = require("../../utils/op-code");
class DeviceService {
    constructor() {
        this.deviceRepo = data_source_1.AppDataSource.getRepository(device_entity_1.DeviceInfo);
    }
    /**
     * 注册设备
     */
    async registerDevice(params) {
        // 检查设备是否已注册
        const existing = await this.deviceRepo.findOne({ where: { deviceNo: params.deviceNo } });
        if (existing) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_DEVICE_EXISTED, null, '设备已注册');
        }
        // 生成设备密钥
        const deviceSecret = this.generateDeviceSecret();
        // 创建设备记录
        const device = this.deviceRepo.create({
            id: (0, uuid_1.v4)(),
            deviceNo: params.deviceNo,
            deviceName: `${params.deviceModel}_${params.deviceNo.slice(-6)}`,
            deviceType: params.deviceType,
            deviceModel: params.deviceModel,
            mchNo: params.mchNo,
            status: device_entity_1.DeviceStatus.ENABLED,
            createTime: new Date(),
            updateTime: new Date(),
        });
        await this.deviceRepo.save(device);
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
            deviceId: device.id,
            deviceNo: device.deviceNo,
            deviceSecret: deviceSecret,
        });
    }
    /**
     * 激活设备
     */
    async activateDevice(params) {
        const device = await this.deviceRepo.findOne({
            where: { deviceNo: params.deviceNo }
        });
        if (!device) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_DEVICE_NOT_EXIST, null, '设备不存在');
        }
        device.mchNo = params.mchNo;
        device.storeId = params.storeId;
        device.activateTime = new Date();
        device.lastHeartbeat = new Date();
        device.status = device_entity_1.DeviceStatus.ACTIVATED;
        device.updateTime = new Date();
        await this.deviceRepo.save(device);
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
            deviceId: device.id,
            deviceNo: device.deviceNo,
            status: 'active',
        });
    }
    /**
     * 设备心跳
     */
    async heartbeat(deviceNo, params) {
        const device = await this.deviceRepo.findOne({ where: { deviceNo } });
        if (!device) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_DEVICE_NOT_EXIST, null, '设备不存在');
        }
        device.lastHeartbeat = new Date();
        device.updateTime = new Date();
        await this.deviceRepo.save(device);
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
            deviceNo,
            serverTime: new Date().toISOString(),
            status: 'ok',
        });
    }
    /**
     * 获取设备列表
     */
    async getDeviceList(params) {
        const { page = 1, pageSize = 20, mchNo, status, deviceType, keyword } = params;
        const query = this.deviceRepo.createQueryBuilder('device')
            .where('1=1');
        if (mchNo) {
            query.andWhere('device.mchNo = :mchNo', { mchNo });
        }
        if (status !== undefined) {
            query.andWhere('device.status = :status', { status });
        }
        if (deviceType !== undefined) {
            query.andWhere('device.deviceType = :deviceType', { deviceType });
        }
        if (keyword) {
            query.andWhere('(device.deviceNo LIKE :keyword OR device.deviceName LIKE :keyword)', { keyword: `%${keyword}%` });
        }
        const [list, total] = await query
            .orderBy('device.createTime', 'DESC')
            .skip((page - 1) * pageSize)
            .take(pageSize)
            .getManyAndCount();
        return {
            list: list.map(d => this.formatDevice(d)),
            total,
            page,
            pageSize,
        };
    }
    /**
     * 获取设备详情
     */
    async getDeviceDetail(id) {
        const device = await this.deviceRepo.findOne({ where: { id } });
        if (!device) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_DEVICE_NOT_EXIST, null, '设备不存在');
        }
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, this.formatDevice(device, true));
    }
    /**
     * 更新设备信息
     */
    async updateDevice(id, params) {
        const device = await this.deviceRepo.findOne({ where: { id } });
        if (!device) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_DEVICE_NOT_EXIST, null, '设备不存在');
        }
        if (params.deviceName)
            device.deviceName = params.deviceName;
        if (params.storeId)
            device.storeId = params.storeId;
        if (params.remark)
            device.remark = params.remark;
        device.updateTime = new Date();
        await this.deviceRepo.save(device);
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, this.formatDevice(device));
    }
    /**
     * 绑定商户
     */
    async bindMerchant(id, mchNo) {
        const device = await this.deviceRepo.findOne({ where: { id } });
        if (!device) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_DEVICE_NOT_EXIST, null, '设备不存在');
        }
        device.mchNo = mchNo;
        device.updateTime = new Date();
        await this.deviceRepo.save(device);
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
            deviceId: device.id,
            deviceNo: device.deviceNo,
            mchNo: device.mchNo,
        });
    }
    /**
     * 解绑设备
     */
    async unbindDevice(id) {
        const device = await this.deviceRepo.findOne({ where: { id } });
        if (!device) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_DEVICE_NOT_EXIST, null, '设备不存在');
        }
        device.mchNo = '';
        device.storeId = '';
        device.updateTime = new Date();
        await this.deviceRepo.save(device);
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
            deviceId: device.id,
            deviceNo: device.deviceNo,
            status: 'unbound',
        });
    }
    /**
     * 禁用设备
     */
    async disableDevice(id, reason) {
        const device = await this.deviceRepo.findOne({ where: { id } });
        if (!device) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_DEVICE_NOT_EXIST, null, '设备不存在');
        }
        device.status = device_entity_1.DeviceStatus.DISABLED;
        device.remark = `[设备禁用] ${reason} - ${new Date().toISOString()}`;
        device.updateTime = new Date();
        await this.deviceRepo.save(device);
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
            deviceId: device.id,
            deviceNo: device.deviceNo,
            status: 'disabled',
        });
    }
    /**
     * 启用设备
     */
    async enableDevice(id) {
        const device = await this.deviceRepo.findOne({ where: { id } });
        if (!device) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_DEVICE_NOT_EXIST, null, '设备不存在');
        }
        device.status = device_entity_1.DeviceStatus.ENABLED;
        device.updateTime = new Date();
        await this.deviceRepo.save(device);
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
            deviceId: device.id,
            deviceNo: device.deviceNo,
            status: 'active',
        });
    }
    /**
     * 报损设备
     */
    async reportDamage(id, reason) {
        const device = await this.deviceRepo.findOne({ where: { id } });
        if (!device) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_DEVICE_NOT_EXIST, null, '设备不存在');
        }
        device.status = device_entity_1.DeviceStatus.LOST;
        device.remark = `[设备报损] ${reason} - ${new Date().toISOString()}`;
        device.updateTime = new Date();
        await this.deviceRepo.save(device);
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
            deviceId: device.id,
            deviceNo: device.deviceNo,
            status: 'damaged',
        });
    }
    /**
     * 生成设备二维码
     */
    async generateDeviceQR(id) {
        const device = await this.deviceRepo.findOne({ where: { id } });
        if (!device) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_DEVICE_NOT_EXIST, null, '设备不存在');
        }
        // 生成包含设备信息的二维码
        const qrData = JSON.stringify({
            type: 'device',
            no: device.deviceNo,
            appId: process.env.DGKJ_APP_ID,
        });
        const qrCodeUrl = await qrcode_1.default.toDataURL(qrData, {
            width: 300,
            margin: 2,
            color: { dark: '#000000', light: '#ffffff' },
        });
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
            deviceId: device.id,
            deviceNo: device.deviceNo,
            qrCode: qrCodeUrl,
            qrContent: qrData,
        });
    }
    /**
     * 获取设备交易统计
     */
    async getDeviceStats(id) {
        const device = await this.deviceRepo.findOne({ where: { id } });
        if (!device) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_DEVICE_NOT_EXIST, null, '设备不存在');
        }
        // 模拟统计数据
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
            deviceId: device.id,
            deviceNo: device.deviceNo,
            today: {
                orderCount: Math.floor(Math.random() * 100),
                orderAmount: Math.floor(Math.random() * 50000) * 100,
                successRate: 99.5,
            },
            month: {
                orderCount: Math.floor(Math.random() * 3000),
                orderAmount: Math.floor(Math.random() * 1500000) * 100,
                successRate: 99.2,
            },
        });
    }
    // ==================== 私有方法 ====================
    /**
     * 生成设备密钥
     */
    generateDeviceSecret() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let secret = '';
        for (let i = 0; i < 32; i++) {
            secret += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return secret;
    }
    /**
     * 格式化设备信息
     */
    formatDevice(device, includeSecret = false) {
        const statusMap = {
            [device_entity_1.DeviceStatus.DISABLED]: '已禁用',
            [device_entity_1.DeviceStatus.ENABLED]: '已启用',
            [device_entity_1.DeviceStatus.ACTIVATED]: '已激活',
            [device_entity_1.DeviceStatus.LOST]: '已报损',
        };
        const typeMap = {
            [device_entity_1.DeviceType.QR_CODE]: '二维码设备',
            [device_entity_1.DeviceType.SPEAKER]: '云喇叭',
            [device_entity_1.DeviceType.PRINTER]: '小票机',
            [device_entity_1.DeviceType.POS]: 'POS机',
        };
        return {
            id: device.id,
            deviceNo: device.deviceNo,
            deviceName: device.deviceName,
            deviceType: device.deviceType,
            deviceTypeName: typeMap[device.deviceType] || '未知',
            deviceModel: device.deviceModel,
            mchNo: device.mchNo,
            storeId: device.storeId,
            status: device.status,
            statusName: statusMap[device.status] || '未知',
            activateTime: device.activateTime,
            lastHeartbeat: device.lastHeartbeat,
            remark: device.remark,
            createTime: device.createTime,
            updateTime: device.updateTime,
        };
    }
}
exports.DeviceService = DeviceService;
exports.default = new DeviceService();
//# sourceMappingURL=device.service.js.map
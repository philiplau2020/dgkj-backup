"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.quotaService = exports.apiKeyService = exports.appService = exports.developerService = exports.QuotaService = exports.ApiKeyService = exports.AppService = exports.DeveloperService = void 0;
const data_source_1 = require("../../../config/data-source");
const entity_1 = require("../entity");
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const crypto_1 = __importDefault(require("crypto"));
const signature_1 = require("../../../utils/signature");
const op_code_1 = require("../../../utils/op-code");
/** 开发者等级配额 */
const LEVEL_QUOTAS = {
    trial: { daily: 100, monthly: 1000, rateLimit: 5, appLimit: 1 },
    basic: { daily: 10000, monthly: 100000, rateLimit: 20, appLimit: 3 },
    professional: { daily: 100000, monthly: 1000000, rateLimit: 100, appLimit: 10 },
    enterprise: { daily: 1000000, monthly: 10000000, rateLimit: 500, appLimit: 50 },
};
/**
 * 开发者服务
 */
class DeveloperService {
    constructor() {
        this.repo = data_source_1.AppDataSource.getRepository(entity_1.OpDeveloper);
    }
    /** 注册开发者 */
    async register(params) {
        // 检查重复
        const exist = await this.repo.findOne({
            where: [
                { username: params.username },
                { email: params.email },
            ],
        });
        if (exist) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, '用户名或邮箱已存在');
        }
        const developerId = 'DEV' + Date.now().toString(36).toUpperCase() + (0, signature_1.generateNonce)(4).toUpperCase();
        const hashedPassword = await bcryptjs_1.default.hash(params.password, 10);
        const developer = this.repo.create({
            ...params,
            developerId,
            password: hashedPassword,
            status: 'pending',
            level: 'trial',
        });
        await this.repo.save(developer);
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
            developerId,
            status: 'pending',
            message: '注册成功，请等待审核',
        });
    }
    /** 开发者登录 */
    async login(username, password, ip) {
        const developer = await this.repo.findOne({ where: { username } });
        if (!developer) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.AUTH_KEY_NOT_FOUND, null, '用户名或密码错误');
        }
        const valid = await bcryptjs_1.default.compare(password, developer.password);
        if (!valid) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.AUTH_KEY_NOT_FOUND, null, '用户名或密码错误');
        }
        // 更新登录信息
        developer.lastLoginTime = new Date();
        developer.lastLoginIp = ip;
        await this.repo.save(developer);
        // 生成访问令牌 (简化版，实际应使用 JWT)
        const token = this.generateToken(developer);
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
            developerId: developer.developerId,
            developerName: developer.developerName,
            email: (0, signature_1.maskEmail)(developer.email),
            mobile: (0, signature_1.maskPhone)(developer.mobile),
            company: developer.company,
            level: developer.level,
            status: developer.status,
            token,
        });
    }
    /** 获取开发者信息 */
    async getInfo(developerId) {
        const developer = await this.repo.findOne({ where: { developerId } });
        if (!developer)
            return null;
        return {
            developerId: developer.developerId,
            developerName: developer.developerName,
            email: (0, signature_1.maskEmail)(developer.email),
            mobile: (0, signature_1.maskPhone)(developer.mobile),
            company: developer.company,
            level: developer.level,
            status: developer.status,
            appCount: developer.appCount,
            totalCallCount: developer.totalCallCount,
            lastLoginTime: developer.lastLoginTime,
            lastLoginIp: developer.lastLoginIp,
            createTime: developer.createTime,
        };
    }
    /** 获取开发者列表 (后台管理) */
    async list(params) {
        const { page = 1, pageSize = 10, keyword, status, level } = params;
        const queryBuilder = this.repo.createQueryBuilder('dev');
        if (keyword) {
            queryBuilder.andWhere('(dev.developerName LIKE :keyword OR dev.username LIKE :keyword OR dev.company LIKE :keyword)', { keyword: `%${keyword}%` });
        }
        if (status)
            queryBuilder.andWhere('dev.status = :status', { status });
        if (level)
            queryBuilder.andWhere('dev.level = :level', { level });
        const [list, total] = await queryBuilder
            .skip((page - 1) * pageSize)
            .take(pageSize)
            .orderBy('dev.createTime', 'DESC')
            .getManyAndCount();
        return {
            list: list.map((d) => ({
                developerId: d.developerId,
                developerName: d.developerName,
                username: d.username,
                email: (0, signature_1.maskEmail)(d.email),
                mobile: (0, signature_1.maskPhone)(d.mobile),
                company: d.company,
                level: d.level,
                status: d.status,
                appCount: d.appCount,
                totalCallCount: d.totalCallCount,
                lastLoginTime: d.lastLoginTime,
                createTime: d.createTime,
            })),
            total,
        };
    }
    /** 审核开发者 */
    async review(developerId, status, reviewBy, remark) {
        await this.repo.update({ developerId }, {
            status,
            reviewTime: new Date(),
            reviewBy,
            reviewRemark: remark,
        });
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, null);
    }
    /** 更新开发者等级 */
    async updateLevel(developerId, level) {
        await this.repo.update({ developerId }, { level });
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, null);
    }
    generateToken(developer) {
        const payload = {
            developerId: developer.developerId,
            username: developer.username,
            level: developer.level,
        };
        const secret = process.env.JWT_SECRET || 'dgkj-open-platform-secret';
        return crypto_1.default.createHmac('sha256', secret).update(JSON.stringify(payload)).digest('hex');
    }
}
exports.DeveloperService = DeveloperService;
/**
 * 应用服务
 */
class AppService {
    constructor() {
        this.repo = data_source_1.AppDataSource.getRepository(entity_1.OpApp);
        this.devRepo = data_source_1.AppDataSource.getRepository(entity_1.OpDeveloper);
    }
    /** 创建应用 */
    async create(params) {
        const developer = await this.devRepo.findOne({ where: { developerId: params.developerId } });
        if (!developer) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.DEV_NOT_APPROVED, null, '开发者不存在');
        }
        if (developer.status !== 'active') {
            return (0, op_code_1.opResult)(op_code_1.OpCode.DEV_NOT_APPROVED, null, '开发者账号未激活');
        }
        // 检查应用数量限制
        const levelConfig = LEVEL_QUOTAS[developer.level] || LEVEL_QUOTAS.trial;
        const appCount = await this.repo.count({ where: { developerId: params.developerId } });
        if (appCount >= levelConfig.appLimit) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, `应用数量已达上限(${levelConfig.appLimit}个)，请升级套餐`);
        }
        const appId = (0, signature_1.generateAppId)();
        const appKey = (0, signature_1.generateAppKey)();
        const appSecret = (0, signature_1.generateAppSecret)();
        // 分配商户号
        const mchNo = (0, signature_1.generateMchNo)();
        // 加密存储 AppSecret
        const encryptKey = process.env.ENCRYPT_KEY || 'dgkj-open-platform-secret';
        const encryptedSecret = (0, signature_1.encryptSecret)(appSecret, encryptKey);
        // 默认授权全部API
        const defaultApis = ['pay', 'query', 'refund', 'transfer', 'account'];
        // 默认授权全部支付方式
        const defaultPayTypes = ['wx_jsapi', 'wx_native', 'wx_h5', 'alipay', 'alipay_qr', 'unionpay', 'bank'];
        const app = this.repo.create({
            ...params,
            appId,
            appKey,
            appSecret: encryptedSecret,
            mchNo,
            status: entity_1.AppStatus.PENDING,
            appType: params.appType,
            enabledApis: params.enabledPayTypes ? defaultApis : defaultApis,
            enabledPayTypes: params.enabledPayTypes || defaultPayTypes,
        });
        await this.repo.save(app);
        // 更新开发者应用计数
        await this.devRepo.increment({ developerId: params.developerId }, 'appCount', 1);
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
            appId,
            appKey,
            appSecret, // 仅在创建时返回一次，之后不再显示
            appName: params.appName,
            mchNo,
            status: 'pending',
            message: '应用创建成功，请等待审核。AppSecret仅显示一次，请妥善保管！',
        });
    }
    /** 获取应用详情 */
    async getApp(appId, developerId) {
        const app = await this.repo.findOne({ where: { appId, developerId } });
        if (!app)
            return null;
        const encryptKey = process.env.ENCRYPT_KEY || 'dgkj-open-platform-secret';
        let displaySecret = '******';
        try {
            if (app.appSecret.includes(':')) {
                displaySecret = (0, signature_1.maskSecret)((0, signature_1.decryptSecret)(app.appSecret, encryptKey), 4);
            }
            else {
                displaySecret = (0, signature_1.maskSecret)(app.appSecret, 4);
            }
        }
        catch (e) {
            // 忽略
        }
        return {
            appId: app.appId,
            appKey: app.appKey,
            appSecret: displaySecret,
            appName: app.appName,
            appType: app.appType,
            description: app.description,
            mchNo: app.mchNo,
            domain: app.domain,
            notifyUrl: app.notifyUrl,
            refundNotifyUrl: app.refundNotifyUrl,
            transferNotifyUrl: app.transferNotifyUrl,
            enabledPayTypes: app.enabledPayTypes,
            enabledApis: app.enabledApis,
            status: app.status,
            todayCallCount: app.todayCallCount,
            totalCallCount: app.totalCallCount,
            monthCallCount: app.monthCallCount,
            monthTradeAmount: app.monthTradeAmount,
            secretUpdateTime: app.secretUpdateTime,
            createTime: app.createTime,
        };
    }
    /** 获取应用列表 */
    async list(developerId, params) {
        const { page = 1, pageSize = 10, keyword, status } = params;
        const queryBuilder = this.repo.createQueryBuilder('app').where('app.developerId = :developerId', { developerId });
        if (keyword)
            queryBuilder.andWhere('app.appName LIKE :keyword', { keyword: `%${keyword}%` });
        if (status)
            queryBuilder.andWhere('app.status = :status', { status });
        const [list, total] = await queryBuilder
            .skip((page - 1) * pageSize)
            .take(pageSize)
            .orderBy('app.createTime', 'DESC')
            .getManyAndCount();
        return { list, total };
    }
    /** 更新应用 */
    async update(appId, developerId, data) {
        const app = await this.repo.findOne({ where: { appId, developerId } });
        if (!app)
            return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, '应用不存在');
        const allowedFields = ['appName', 'description', 'appScenario', 'domain', 'notifyUrl', 'refundNotifyUrl', 'transferNotifyUrl'];
        const updateData = {};
        for (const key of allowedFields) {
            if (data[key] !== undefined) {
                updateData[key] = data[key];
            }
        }
        await this.repo.update({ appId }, updateData);
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, null);
    }
    /** 重置 AppSecret */
    async resetSecret(appId, developerId) {
        const app = await this.repo.findOne({ where: { appId, developerId } });
        if (!app)
            return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, '应用不存在');
        const newSecret = (0, signature_1.generateAppSecret)();
        const encryptKey = process.env.ENCRYPT_KEY || 'dgkj-open-platform-secret';
        const encryptedSecret = (0, signature_1.encryptSecret)(newSecret, encryptKey);
        await this.repo.update({ appId }, {
            appSecret: encryptedSecret,
            secretUpdateTime: new Date(),
        });
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
            appSecret: newSecret,
            message: 'AppSecret已重置，请妥善保管！',
        });
    }
    /** 更新IP白名单 */
    async updateIpWhitelist(appId, developerId, ips) {
        await this.repo.update({ appId, developerId }, {
            ipWhitelist: JSON.stringify(ips),
            ipWhitelistCount: ips.length,
        });
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, null);
    }
    /** 审核应用 */
    async review(appId, status, reviewBy) {
        const appStatus = status === 'active' ? entity_1.AppStatus.ACTIVE : entity_1.AppStatus.SUSPENDED;
        await this.repo.update({ appId }, { status: appStatus });
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, null);
    }
    /** 获取应用配置信息 (供前端调试使用) */
    async getAppConfig(appId) {
        const app = await this.repo.findOne({ where: { appId } });
        if (!app)
            return null;
        return {
            appId: app.appKey,
            mchNo: app.mchNo,
            enabledApis: app.enabledApis,
            enabledPayTypes: app.enabledPayTypes,
        };
    }
}
exports.AppService = AppService;
/**
 * API Key 管理服务
 */
class ApiKeyService {
    constructor() {
        this.repo = data_source_1.AppDataSource.getRepository(entity_1.OpApiKey);
    }
    /** 创建 API Key */
    async createKey(params) {
        const keyId = (0, signature_1.generateKeyId)();
        const keyValue = 'AK' + (0, signature_1.generateNonce)(16).toUpperCase();
        const keySecret = (0, signature_1.generateNonce)(32);
        const encryptKey = process.env.ENCRYPT_KEY || 'dgkj-open-platform-secret';
        const encryptedSecret = (0, signature_1.encryptSecret)(keySecret, encryptKey);
        const expireTime = params.expireDays
            ? new Date(Date.now() + params.expireDays * 24 * 60 * 60 * 1000)
            : null;
        const key = this.repo.create({
            keyId,
            appId: params.appId,
            developerId: params.developerId,
            keyValue,
            keySecret: encryptedSecret,
            signType: params.signType || 'hmac_sha256',
            alias: params.alias,
            boundIp: params.boundIp,
            expireTime,
        });
        await this.repo.save(key);
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
            keyId,
            keyValue,
            keySecret, // 仅创建时返回一次
            signType: params.signType || 'hmac_sha256',
            expireTime,
            message: 'API Key创建成功，请妥善保管KeySecret！',
        });
    }
    /** 获取 Key 列表 */
    async listKeys(appId) {
        const keys = await this.repo.find({ where: { appId }, order: { createTime: 'DESC' } });
        const encryptKey = process.env.ENCRYPT_KEY || 'dgkj-open-platform-secret';
        return keys.map((k) => {
            let displaySecret = '******';
            try {
                if (k.keySecret.includes(':')) {
                    displaySecret = (0, signature_1.maskSecret)((0, signature_1.decryptSecret)(k.keySecret, encryptKey), 4);
                }
            }
            catch (e) {
                // 忽略
            }
            return {
                keyId: k.keyId,
                keyValue: k.keyValue,
                keySecret: displaySecret,
                signType: k.signType,
                alias: k.alias,
                boundIp: k.boundIp,
                status: k.status,
                expireTime: k.expireTime,
                usedCount: k.usedCount,
                lastUsedTime: k.lastUsedTime,
                lastUsedIp: k.lastUsedIp,
                createTime: k.createTime,
            };
        });
    }
    /** 禁用 Key */
    async disableKey(keyId, developerId) {
        await this.repo.update({ keyId, developerId }, { status: 'disabled' });
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, null);
    }
    /** 启用 Key */
    async enableKey(keyId, developerId) {
        await this.repo.update({ keyId, developerId }, { status: 'active' });
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, null);
    }
    /** 删除 Key */
    async deleteKey(keyId, developerId) {
        await this.repo.delete({ keyId, developerId });
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, null);
    }
}
exports.ApiKeyService = ApiKeyService;
/**
 * 配额服务
 */
class QuotaService {
    constructor() {
        this.repo = data_source_1.AppDataSource.getRepository(entity_1.OpApiQuota);
        this.appRepo = data_source_1.AppDataSource.getRepository(entity_1.OpApp);
    }
    /** 获取配额信息 */
    async getQuota(appId) {
        const quotas = await this.repo.find({ where: { appId } });
        const app = await this.appRepo.findOne({ where: { appId } });
        const developer = await data_source_1.AppDataSource.getRepository(entity_1.OpDeveloper).findOne({ where: { developerId: app?.developerId } });
        const levelConfig = LEVEL_QUOTAS[developer?.level] || LEVEL_QUOTAS.trial;
        return {
            daily: {
                used: quotas.find((q) => q.quotaType === 'daily')?.quotaUsed || 0,
                limit: levelConfig.daily,
            },
            monthly: {
                used: quotas.find((q) => q.quotaType === 'monthly')?.quotaUsed || 0,
                limit: levelConfig.monthly,
            },
            rateLimit: levelConfig.rateLimit,
            appLimit: levelConfig.appLimit,
        };
    }
}
exports.QuotaService = QuotaService;
exports.developerService = new DeveloperService();
exports.appService = new AppService();
exports.apiKeyService = new ApiKeyService();
exports.quotaService = new QuotaService();
//# sourceMappingURL=open-platform.service.js.map
export declare class OpApiKey {
    id: string;
    keyId: string;
    appId: string;
    developerId: string;
    keyValue: string;
    keySecret: string;
    signType: 'hmac_sha256' | 'rsa_2048' | 'sm2';
    status: 'active' | 'disabled' | 'expired';
    alias: string;
    boundIp: string;
    expireTime: Date;
    usedCount: number;
    lastUsedTime: Date;
    lastUsedIp: string;
    createTime: Date;
    updateTime: Date;
}
//# sourceMappingURL=api-key.entity.d.ts.map
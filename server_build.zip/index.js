"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const morgan_1 = __importDefault(require("morgan"));
const compression_1 = __importDefault(require("compression"));
const data_source_1 = require("./config/data-source");
const global_exception_filter_1 = require("./common/filters/global-exception.filter");
const response_interceptor_1 = require("./common/interceptors/response.interceptor");
const swagger_1 = __importDefault(require("./config/swagger"));
const routes_1 = __importDefault(require("./modules/auth/routes"));
const routes_2 = __importDefault(require("./modules/sys/routes"));
const routes_3 = __importDefault(require("./modules/mch/routes"));
const routes_4 = __importDefault(require("./modules/agent/routes"));
const routes_5 = __importDefault(require("./modules/trade/routes"));
const routes_6 = __importDefault(require("./modules/finance/routes"));
const routes_7 = __importDefault(require("./modules/channel/routes"));
const routes_8 = __importDefault(require("./modules/citic/routes"));
const routes_9 = __importDefault(require("./modules/statistics/routes"));
const routes_10 = __importDefault(require("./modules/device/routes"));
const routes_11 = __importDefault(require("./modules/check/routes"));
const routes_12 = __importDefault(require("./modules/profit/routes"));
const routes_13 = __importDefault(require("./modules/ops/routes"));
const routes_14 = __importDefault(require("./modules/monitor/routes"));
const callback_routes_1 = __importDefault(require("./modules/pay/callback.routes"));
const routes_15 = __importDefault(require("./modules/open/routes"));
const admin_1 = __importDefault(require("./modules/open/routes/admin"));
const notification_routes_1 = __importDefault(require("./modules/notification/notification.routes"));
const notification_service_1 = require("./modules/notification/notification.service");
const cache_service_1 = require("./services/cache.service");
const queue_service_1 = require("./services/queue.service");
const app = (0, express_1.default)();
const PORT = process.env.PORT || 3000;
// Middleware
app.use((0, helmet_1.default)());
app.use((0, cors_1.default)({
    origin: process.env.CORS_ORIGIN || 'http://localhost:5173',
    credentials: true,
}));
app.use((0, compression_1.default)());
app.use((0, morgan_1.default)('combined'));
app.use(express_1.default.json());
app.use(express_1.default.urlencoded({ extended: true }));
// Response interceptor
app.use(response_interceptor_1.responseInterceptor);
// Error handler (must be after responseInterceptor and all routes)
app.use(global_exception_filter_1.errorHandler);
// Swagger API Documentation
(0, swagger_1.default)(app);
// Health check (支持 K8s liveness/readiness probes)
app.get('/health', async (req, res) => {
    const health = {
        status: 'ok',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        memory: process.memoryUsage(),
    };
    // 检查数据库连接
    try {
        if (data_source_1.AppDataSource.isInitialized) {
            await data_source_1.AppDataSource.query('SELECT 1');
            health.database = 'connected';
        }
        else {
            health.database = 'disconnected';
        }
    }
    catch (error) {
        health.database = 'error';
        health.databaseError = error.message;
    }
    const isHealthy = health.database === 'connected';
    res.status(isHealthy ? 200 : 503).json(health);
});
// 详细健康检查 (K8s readiness probe)
app.get('/ready', async (req, res) => {
    try {
        if (data_source_1.AppDataSource.isInitialized) {
            await data_source_1.AppDataSource.query('SELECT 1');
        }
        res.json({ ready: true });
    }
    catch (error) {
        res.status(503).json({ ready: false, error: error.message });
    }
});
// API Routes - 统一使用 /basic-api 前缀
app.use('/basic-api/auth', routes_1.default);
app.use('/basic-api/sys', routes_2.default);
app.use('/basic-api/merchant', routes_3.default); // 商户管理
app.use('/basic-api/mch', routes_3.default); // 商户管理 (别名)
app.use('/basic-api/agent', routes_4.default); // 代理管理
app.use('/basic-api/order', routes_5.default); // 交易订单
app.use('/basic-api/refund', routes_5.default); // 退款 (复用 tradeRoutes)
app.use('/basic-api/account', routes_6.default); // 账户管理
app.use('/basic-api/finance', routes_6.default); // 财务管理
app.use('/basic-api/channel', routes_7.default); // 通道管理
app.use('/basic-api/pool', routes_7.default); // 通道池 (复用 channelRoutes)
app.use('/basic-api/citic', routes_8.default); // 中信银行E管家管理
app.use('/basic-api/stat', routes_9.default); // 统计管理
app.use('/basic-api/device', routes_10.default); // 设备管理
app.use('/basic-api/check', routes_11.default); // 对账管理
app.use('/basic-api/profit', routes_12.default); // 分润管理
app.use('/basic-api/ops', routes_13.default); // 运维监控
app.use('/basic-api/monitor', routes_14.default); // 系统监控
app.use('/basic-api/pay', callback_routes_1.default); // 支付回调
// 开放平台 API (/api/v1/*) - 商户接入
app.use('/api/v1', routes_15.default);
// 开放平台管理 API (/basic-api/open/*) - 后台管理
app.use('/basic-api/open', admin_1.default);
// 通知配置 API (/basic-api/sys/notification/*) - 通知服务配置
app.use('/basic-api/sys/notification', notification_routes_1.default);
// Start server
data_source_1.AppDataSource.initialize()
    .then(async () => {
    console.log('Database connection established');
    // 初始化通知服务
    await (0, notification_service_1.initializeNotificationConfig)();
    // 初始化缓存服务
    const useRedis = process.env.USE_REDIS === 'true';
    await cache_service_1.cacheService.initialize({ type: useRedis ? 'redis' : 'memory' });
    // 初始化消息队列服务
    const useRabbitMQ = process.env.USE_RABBITMQ === 'true';
    await queue_service_1.messageQueueService.initialize(useRabbitMQ ? 'rabbitmq' : 'memory');
    app.listen(PORT, () => {
        console.log(`Server is running on http://localhost:${PORT}`);
        console.log(`API Docs available at http://localhost:${PORT}/api-docs`);
        console.log(`Health check available at http://localhost:${PORT}/health`);
    });
})
    .catch((error) => {
    console.error('Database connection failed:', error);
    process.exit(1);
});
exports.default = app;
//# sourceMappingURL=index.js.map
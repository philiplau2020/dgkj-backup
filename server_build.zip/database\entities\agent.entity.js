"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentWithdraw = exports.AgentProfit = exports.AgentInfo = exports.AgentStatus = void 0;
const typeorm_1 = require("typeorm");
var AgentStatus;
(function (AgentStatus) {
    AgentStatus[AgentStatus["DISABLED"] = 0] = "DISABLED";
    AgentStatus[AgentStatus["ENABLED"] = 1] = "ENABLED";
    AgentStatus[AgentStatus["PENDING_REVIEW"] = 2] = "PENDING_REVIEW";
    AgentStatus[AgentStatus["REJECTED"] = 3] = "REJECTED";
})(AgentStatus || (exports.AgentStatus = AgentStatus = {}));
let AgentInfo = class AgentInfo {
};
exports.AgentInfo = AgentInfo;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], AgentInfo.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'agent_no', length: 32, unique: true }),
    __metadata("design:type", String)
], AgentInfo.prototype, "agentNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'agent_name', length: 128 }),
    __metadata("design:type", String)
], AgentInfo.prototype, "agentName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'parent_id', length: 64, nullable: true }),
    __metadata("design:type", String)
], AgentInfo.prototype, "parentId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'level', type: 'int', default: 1 }),
    __metadata("design:type", Number)
], AgentInfo.prototype, "level", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'contact_name', length: 64 }),
    __metadata("design:type", String)
], AgentInfo.prototype, "contactName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'contact_phone', length: 32 }),
    __metadata("design:type", String)
], AgentInfo.prototype, "contactPhone", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'contact_email', length: 128, nullable: true }),
    __metadata("design:type", String)
], AgentInfo.prototype, "contactEmail", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'province', length: 32, nullable: true }),
    __metadata("design:type", String)
], AgentInfo.prototype, "province", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'city', length: 32, nullable: true }),
    __metadata("design:type", String)
], AgentInfo.prototype, "city", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'district', length: 32, nullable: true }),
    __metadata("design:type", String)
], AgentInfo.prototype, "district", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'address', length: 255, nullable: true }),
    __metadata("design:type", String)
], AgentInfo.prototype, "address", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'id_card_front', length: 255, nullable: true }),
    __metadata("design:type", String)
], AgentInfo.prototype, "idCardFront", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'id_card_back', length: 255, nullable: true }),
    __metadata("design:type", String)
], AgentInfo.prototype, "idCardBack", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_name', length: 64, nullable: true }),
    __metadata("design:type", String)
], AgentInfo.prototype, "bankName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_account', length: 32, nullable: true }),
    __metadata("design:type", String)
], AgentInfo.prototype, "bankAccount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_username', length: 64, nullable: true }),
    __metadata("design:type", String)
], AgentInfo.prototype, "bankUsername", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'balance', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], AgentInfo.prototype, "balance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'frozen_balance', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], AgentInfo.prototype, "frozenBalance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'profit_balance', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], AgentInfo.prototype, "profitBalance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: AgentStatus.PENDING_REVIEW }),
    __metadata("design:type", Number)
], AgentInfo.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'review_remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], AgentInfo.prototype, "reviewRemark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'review_time', nullable: true }),
    __metadata("design:type", Date)
], AgentInfo.prototype, "reviewTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'review_user_id', length: 64, nullable: true }),
    __metadata("design:type", String)
], AgentInfo.prototype, "reviewUserId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], AgentInfo.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], AgentInfo.prototype, "updateTime", void 0);
exports.AgentInfo = AgentInfo = __decorate([
    (0, typeorm_1.Entity)('agent_info')
], AgentInfo);
let AgentProfit = class AgentProfit {
};
exports.AgentProfit = AgentProfit;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], AgentProfit.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'agent_no', length: 32 }),
    __metadata("design:type", String)
], AgentProfit.prototype, "agentNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'order_no', length: 64, nullable: true }),
    __metadata("design:type", String)
], AgentProfit.prototype, "orderNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_no', length: 32, nullable: true }),
    __metadata("design:type", String)
], AgentProfit.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'trade_type', length: 32 }),
    __metadata("design:type", String)
], AgentProfit.prototype, "tradeType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'trade_amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], AgentProfit.prototype, "tradeAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'profit_amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], AgentProfit.prototype, "profitAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'profit_rate', type: 'decimal', precision: 6, scale: 4 }),
    __metadata("design:type", Number)
], AgentProfit.prototype, "profitRate", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'profit_type', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], AgentProfit.prototype, "profitType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], AgentProfit.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'settle_time', nullable: true }),
    __metadata("design:type", Date)
], AgentProfit.prototype, "settleTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], AgentProfit.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], AgentProfit.prototype, "createTime", void 0);
exports.AgentProfit = AgentProfit = __decorate([
    (0, typeorm_1.Entity)('agent_profit')
], AgentProfit);
let AgentWithdraw = class AgentWithdraw {
};
exports.AgentWithdraw = AgentWithdraw;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], AgentWithdraw.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'withdraw_no', length: 32, unique: true }),
    __metadata("design:type", String)
], AgentWithdraw.prototype, "withdrawNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'agent_no', length: 32 }),
    __metadata("design:type", String)
], AgentWithdraw.prototype, "agentNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], AgentWithdraw.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fee', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], AgentWithdraw.prototype, "fee", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'actual_amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], AgentWithdraw.prototype, "actualAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_name', length: 64 }),
    __metadata("design:type", String)
], AgentWithdraw.prototype, "bankName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_account', length: 32 }),
    __metadata("design:type", String)
], AgentWithdraw.prototype, "bankAccount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_username', length: 64 }),
    __metadata("design:type", String)
], AgentWithdraw.prototype, "bankUsername", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 0 }),
    __metadata("design:type", Number)
], AgentWithdraw.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fail_reason', length: 255, nullable: true }),
    __metadata("design:type", String)
], AgentWithdraw.prototype, "failReason", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'complete_time', nullable: true }),
    __metadata("design:type", Date)
], AgentWithdraw.prototype, "completeTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], AgentWithdraw.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], AgentWithdraw.prototype, "updateTime", void 0);
exports.AgentWithdraw = AgentWithdraw = __decorate([
    (0, typeorm_1.Entity)('agent_withdraw')
], AgentWithdraw);
//# sourceMappingURL=agent.entity.js.map
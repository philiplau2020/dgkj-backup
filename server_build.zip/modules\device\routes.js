"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const device_service_1 = __importDefault(require("./device.service"));
const auth_middleware_1 = require("../../common/middleware/auth.middleware");
const router = (0, express_1.Router)();
router.use(auth_middleware_1.authGuard);
// ==================== 设备管理 ====================
/**
 * GET /basic-api/device/list
 * 获取设备列表
 */
router.get('/list', async (req, res) => {
    try {
        const { page = 1, pageSize = 20, mchNo, status, deviceType, keyword } = req.query;
        const result = await device_service_1.default.getDeviceList({
            page: parseInt(page),
            pageSize: parseInt(pageSize),
            mchNo: mchNo,
            status: status ? parseInt(status) : undefined,
            deviceType: deviceType ? parseInt(deviceType) : undefined,
            keyword: keyword,
        });
        res.json({ code: 0, message: 'ok', data: result });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
/**
 * GET /basic-api/device/detail
 * 获取设备详情
 */
router.get('/detail', async (req, res) => {
    try {
        const { id } = req.query;
        const result = await device_service_1.default.getDeviceDetail(id);
        res.json({ code: result.code, message: result.message, data: result.data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
/**
 * POST /basic-api/device/register
 * 注册设备
 */
router.post('/register', async (req, res) => {
    try {
        const result = await device_service_1.default.registerDevice(req.body);
        res.json({ code: result.code, message: result.message, data: result.data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
/**
 * POST /basic-api/device/activate
 * 激活设备
 */
router.post('/activate', async (req, res) => {
    try {
        const result = await device_service_1.default.activateDevice(req.body);
        res.json({ code: result.code, message: result.message, data: result.data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
/**
 * POST /basic-api/device/heartbeat
 * 设备心跳
 */
router.post('/heartbeat', async (req, res) => {
    try {
        const { deviceNo, firmwareVersion, batteryLevel, deviceIp } = req.body;
        const result = await device_service_1.default.heartbeat(deviceNo, {
            firmwareVersion,
            batteryLevel,
            deviceIp,
        });
        res.json({ code: result.code, message: result.message, data: result.data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
/**
 * PUT /basic-api/device/update
 * 更新设备信息
 */
router.put('/update', async (req, res) => {
    try {
        const { id, deviceName, storeId, remark } = req.body;
        const result = await device_service_1.default.updateDevice(id, { deviceName, storeId, remark });
        res.json({ code: result.code, message: result.message, data: result.data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
/**
 * PUT /basic-api/device/bind
 * 绑定商户
 */
router.put('/bind', async (req, res) => {
    try {
        const { id, mchNo } = req.body;
        const result = await device_service_1.default.bindMerchant(id, mchNo);
        res.json({ code: result.code, message: result.message, data: result.data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
/**
 * PUT /basic-api/device/unbind
 * 解绑设备
 */
router.put('/unbind', async (req, res) => {
    try {
        const { id } = req.body;
        const result = await device_service_1.default.unbindDevice(id);
        res.json({ code: result.code, message: result.message, data: result.data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
/**
 * PUT /basic-api/device/disable
 * 禁用设备
 */
router.put('/disable', async (req, res) => {
    try {
        const { id, reason } = req.body;
        const result = await device_service_1.default.disableDevice(id, reason);
        res.json({ code: result.code, message: result.message, data: result.data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
/**
 * PUT /basic-api/device/enable
 * 启用设备
 */
router.put('/enable', async (req, res) => {
    try {
        const { id } = req.body;
        const result = await device_service_1.default.enableDevice(id);
        res.json({ code: result.code, message: result.message, data: result.data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
/**
 * PUT /basic-api/device/damage
 * 设备报损
 */
router.put('/damage', async (req, res) => {
    try {
        const { id, reason } = req.body;
        const result = await device_service_1.default.reportDamage(id, reason);
        res.json({ code: result.code, message: result.message, data: result.data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
/**
 * GET /basic-api/device/qr
 * 生成设备二维码
 */
router.get('/qr', async (req, res) => {
    try {
        const { id } = req.query;
        const result = await device_service_1.default.generateDeviceQR(id);
        res.json({ code: result.code, message: result.message, data: result.data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
/**
 * GET /basic-api/device/stats
 * 获取设备交易统计
 */
router.get('/stats', async (req, res) => {
    try {
        const { id } = req.query;
        const result = await device_service_1.default.getDeviceStats(id);
        res.json({ code: result.code, message: result.message, data: result.data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
// ==================== 兼容旧路由 ====================
/**
 * GET /basic-api/device/:id
 * 获取设备详情 (兼容旧路由)
 */
router.get('/:id', async (req, res) => {
    try {
        const result = await device_service_1.default.getDeviceDetail(req.params.id);
        res.json({ code: result.code, message: result.message, data: result.data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
/**
 * PUT /basic-api/device/:id/bind
 * 绑定设备 (兼容旧路由)
 */
router.put('/:id/bind', async (req, res) => {
    try {
        const result = await device_service_1.default.bindMerchant(req.params.id, req.body.mchNo);
        res.json({ code: result.code, message: result.message, data: result.data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
exports.default = router;
//# sourceMappingURL=routes.js.map
export declare enum MchStatus {
    DISABLED = 0,
    ENABLED = 1,
    PENDING_REVIEW = 2,
    REJECTED = 3
}
export declare enum MchType {
    PERSONAL = 1,
    ENTERPRISE = 2
}
export declare class MchInfo {
    id: string;
    mchNo: string;
    mchName: string;
    mchShortName: string;
    mchType: MchType;
    agentId: string;
    contactName: string;
    contactPhone: string;
    contactEmail: string;
    province: string;
    city: string;
    district: string;
    address: string;
    businessLicense: string;
    idCardFront: string;
    idCardBack: string;
    bankName: string;
    bankAccount: string;
    bankUsername: string;
    status: MchStatus;
    reviewRemark: string;
    reviewTime: Date;
    reviewUserId: string;
    balance: number;
    frozenBalance: number;
    settleBalance: number;
    createTime: Date;
    updateTime: Date;
}
export declare class MchApp {
    id: string;
    appId: string;
    mchNo: string;
    appName: string;
    appSecret: string;
    notifyUrl: string;
    returnUrl: string;
    status: number;
    remark: string;
    createTime: Date;
    updateTime: Date;
}
export declare class MchStore {
    id: string;
    storeId: string;
    mchNo: string;
    storeName: string;
    storeNo: string;
    contactName: string;
    contactPhone: string;
    province: string;
    city: string;
    district: string;
    address: string;
    latitude: number;
    longitude: number;
    deviceCount: number;
    status: number;
    createTime: Date;
    updateTime: Date;
}
export declare class MchRate {
    id: string;
    mchNo: string;
    payWay: string;
    rateType: number;
    rate: number;
    minFee: number;
    maxFee: number;
    status: number;
    createTime: Date;
    updateTime: Date;
}
//# sourceMappingURL=mch.entity.d.ts.map
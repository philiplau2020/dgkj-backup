export declare enum AppStatus {
    PENDING = "pending",
    ACTIVE = "active",
    SUSPENDED = "suspended",
    DELETED = "deleted"
}
export declare enum AppType {
    WEB = "web",
    MOBILE = "mobile",
    MINIAPP = "miniapp",
    API = "api"
}
export declare class OpApp {
    id: string;
    appId: string;
    appKey: string;
    appSecret: string;
    developerId: string;
    mchNo: string;
    appName: string;
    appType: AppType;
    description: string;
    appScenario: string;
    appIcon: string;
    domain: string;
    notifyUrl: string;
    refundNotifyUrl: string;
    transferNotifyUrl: string;
    enabledPayTypes: string[];
    enabledApis: string[];
    status: AppStatus;
    todayCallCount: number;
    totalCallCount: number;
    monthCallCount: number;
    monthTradeAmount: number;
    ipWhitelistCount: number;
    ipWhitelist: string;
    secretUpdateTime: Date;
    createTime: Date;
    updateTime: Date;
}
//# sourceMappingURL=app.entity.d.ts.map
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OpApiKey = void 0;
/**
 * API密钥实体
 */
const typeorm_1 = require("typeorm");
let OpApiKey = class OpApiKey {
};
exports.OpApiKey = OpApiKey;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], OpApiKey.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, unique: true, comment: 'Key ID' }),
    __metadata("design:type", String)
], OpApiKey.prototype, "keyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, comment: '应用ID' }),
    __metadata("design:type", String)
], OpApiKey.prototype, "appId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, comment: '开发者ID' }),
    __metadata("design:type", String)
], OpApiKey.prototype, "developerId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 128, comment: 'Key值(公钥/明文标识)' }),
    __metadata("design:type", String)
], OpApiKey.prototype, "keyValue", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 512, comment: '密钥(加密存储,用于验签)' }),
    __metadata("design:type", String)
], OpApiKey.prototype, "keySecret", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: ['hmac_sha256', 'rsa_2048', 'sm2'], default: 'hmac_sha256', comment: '签名算法' }),
    __metadata("design:type", String)
], OpApiKey.prototype, "signType", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: ['active', 'disabled', 'expired'], default: 'active', comment: '状态' }),
    __metadata("design:type", String)
], OpApiKey.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 128, nullable: true, comment: 'Key别名' }),
    __metadata("design:type", String)
], OpApiKey.prototype, "alias", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, nullable: true, comment: '授权IP' }),
    __metadata("design:type", String)
], OpApiKey.prototype, "boundIp", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'datetime', nullable: true, comment: '过期时间' }),
    __metadata("design:type", Date)
], OpApiKey.prototype, "expireTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, comment: '累计使用次数' }),
    __metadata("design:type", Number)
], OpApiKey.prototype, "usedCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'datetime', nullable: true, comment: '最后使用时间' }),
    __metadata("design:type", Date)
], OpApiKey.prototype, "lastUsedTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'datetime', nullable: true, comment: '最后使用IP' }),
    __metadata("design:type", String)
], OpApiKey.prototype, "lastUsedIp", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'datetime' }),
    __metadata("design:type", Date)
], OpApiKey.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ type: 'datetime' }),
    __metadata("design:type", Date)
], OpApiKey.prototype, "updateTime", void 0);
exports.OpApiKey = OpApiKey = __decorate([
    (0, typeorm_1.Entity)('op_api_key')
], OpApiKey);
//# sourceMappingURL=api-key.entity.js.map
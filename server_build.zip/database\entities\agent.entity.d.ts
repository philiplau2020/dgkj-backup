export declare enum AgentStatus {
    DISABLED = 0,
    ENABLED = 1,
    PENDING_REVIEW = 2,
    REJECTED = 3
}
export declare class AgentInfo {
    id: string;
    agentNo: string;
    agentName: string;
    parentId: string;
    level: number;
    contactName: string;
    contactPhone: string;
    contactEmail: string;
    province: string;
    city: string;
    district: string;
    address: string;
    idCardFront: string;
    idCardBack: string;
    bankName: string;
    bankAccount: string;
    bankUsername: string;
    balance: number;
    frozenBalance: number;
    profitBalance: number;
    status: AgentStatus;
    reviewRemark: string;
    reviewTime: Date;
    reviewUserId: string;
    createTime: Date;
    updateTime: Date;
}
export declare class AgentProfit {
    id: string;
    agentNo: string;
    orderNo: string;
    mchNo: string;
    tradeType: string;
    tradeAmount: number;
    profitAmount: number;
    profitRate: number;
    profitType: number;
    status: number;
    settleTime: Date;
    remark: string;
    createTime: Date;
}
export declare class AgentWithdraw {
    id: string;
    withdrawNo: string;
    agentNo: string;
    amount: number;
    fee: number;
    actualAmount: number;
    bankName: string;
    bankAccount: string;
    bankUsername: string;
    status: number;
    failReason: string;
    completeTime: Date;
    createTime: Date;
    updateTime: Date;
}
//# sourceMappingURL=agent.entity.d.ts.map
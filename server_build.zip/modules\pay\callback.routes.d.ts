/**
 * DGKJ 支付平台 - 支付回调路由
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=callback.routes.d.ts.map
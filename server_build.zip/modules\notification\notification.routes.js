"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * DGKJ 支付平台 - 通知配置管理路由
 */
const express_1 = require("express");
const express_validator_1 = require("express-validator");
const uuid_1 = require("uuid");
const data_source_1 = require("../../config/data-source");
const sys_entity_1 = require("../../database/entities/sys.entity");
const notificationService = __importStar(require("./notification.service"));
const router = (0, express_1.Router)();
// ==================== 辅助函数 ====================
function validate(req, res, next) {
    const errors = (0, express_validator_1.validationResult)(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ code: 400, message: errors.array()[0].msg, data: null });
    }
    next();
}
// ==================== 邮件配置 ====================
// 获取邮件配置
router.get('/config/email', async (req, res, next) => {
    try {
        const configRepo = data_source_1.AppDataSource.getRepository(sys_entity_1.SysConfig);
        const config = await configRepo.findOne({ where: { configKey: 'email_config' } });
        let emailConfig = {
            host: 'smtp.example.com',
            port: 465,
            secure: true,
            user: '',
            pass: '',
            from: 'noreply@dgkj.com',
            fromName: 'DGKJ支付平台',
            enabled: false,
        };
        if (config && config.configValue) {
            const savedConfig = JSON.parse(config.configValue);
            emailConfig = { ...emailConfig, ...savedConfig, pass: savedConfig.pass ? '******' : '' };
        }
        res.json({ code: 0, message: 'success', data: emailConfig });
    }
    catch (error) {
        next(error);
    }
});
// 保存邮件配置
router.post('/config/email', [
    (0, express_validator_1.body)('host').notEmpty().withMessage('SMTP服务器不能为空'),
    (0, express_validator_1.body)('port').isInt({ min: 1, max: 65535 }).withMessage('端口号格式不正确'),
    (0, express_validator_1.body)('user').notEmpty().withMessage('用户名不能为空'),
    (0, express_validator_1.body)('pass').notEmpty().withMessage('密码不能为空'),
], validate, async (req, res, next) => {
    try {
        const { host, port, secure, user, pass, from, fromName, enabled } = req.body;
        const configRepo = data_source_1.AppDataSource.getRepository(sys_entity_1.SysConfig);
        let config = await configRepo.findOne({ where: { configKey: 'email_config' } });
        const configValue = JSON.stringify({ host, port, secure, user, pass, from, fromName });
        if (config) {
            await configRepo.update(config.id, { configValue, updateTime: new Date() });
        }
        else {
            config = configRepo.create({
                id: (0, uuid_1.v4)(),
                configName: '邮件配置',
                configKey: 'email_config',
                configValue,
                configType: 'json',
                groupName: '通知',
                remark: '系统邮件发送配置',
                status: 1,
                createTime: new Date(),
                updateTime: new Date(),
            });
            await configRepo.save(config);
        }
        // 重新初始化邮件服务
        await notificationService.initializeNotificationConfig();
        res.json({ code: 0, message: '保存成功', data: null });
    }
    catch (error) {
        next(error);
    }
});
// 测试邮件发送
router.post('/config/email/test', async (req, res, next) => {
    try {
        const { to } = req.body;
        if (!to) {
            return res.status(400).json({ code: 400, message: '收件人不能为空', data: null });
        }
        const result = await notificationService.testEmail(to);
        res.json({ code: result.success ? 0 : 500, message: result.success ? '发送成功' : result.errorMsg, data: result });
    }
    catch (error) {
        next(error);
    }
});
// ==================== 短信配置 ====================
// 获取短信配置
router.get('/config/sms', async (req, res, next) => {
    try {
        const configRepo = data_source_1.AppDataSource.getRepository(sys_entity_1.SysConfig);
        const config = await configRepo.findOne({ where: { configKey: 'sms_config' } });
        let smsConfig = {
            provider: 'mock',
            accessKeyId: '',
            accessKeySecret: '',
            signName: 'DGKJ支付',
            templateCode: '',
            enabled: false,
        };
        if (config && config.configValue) {
            const savedConfig = JSON.parse(config.configValue);
            smsConfig = { ...smsConfig, ...savedConfig, accessKeySecret: savedConfig.accessKeySecret ? '******' : '' };
        }
        res.json({ code: 0, message: 'success', data: smsConfig });
    }
    catch (error) {
        next(error);
    }
});
// 保存短信配置
router.post('/config/sms', [
    (0, express_validator_1.body)('provider').isIn(['aliyun', 'tencent', 'mock']).withMessage('服务商不正确'),
    (0, express_validator_1.body)('signName').notEmpty().withMessage('签名不能为空'),
], validate, async (req, res, next) => {
    try {
        const { provider, accessKeyId, accessKeySecret, signName, templateCode, enabled } = req.body;
        const configRepo = data_source_1.AppDataSource.getRepository(sys_entity_1.SysConfig);
        let config = await configRepo.findOne({ where: { configKey: 'sms_config' } });
        const configValue = JSON.stringify({ provider, accessKeyId, accessKeySecret, signName, templateCode });
        if (config) {
            await configRepo.update(config.id, { configValue, updateTime: new Date() });
        }
        else {
            config = configRepo.create({
                id: (0, uuid_1.v4)(),
                configName: '短信配置',
                configKey: 'sms_config',
                configValue,
                configType: 'json',
                groupName: '通知',
                remark: '短信发送配置',
                status: 1,
                createTime: new Date(),
                updateTime: new Date(),
            });
            await configRepo.save(config);
        }
        await notificationService.initializeNotificationConfig();
        res.json({ code: 0, message: '保存成功', data: null });
    }
    catch (error) {
        next(error);
    }
});
// 测试短信发送
router.post('/config/sms/test', async (req, res, next) => {
    try {
        const { phone } = req.body;
        if (!phone) {
            return res.status(400).json({ code: 400, message: '手机号不能为空', data: null });
        }
        const result = await notificationService.testSms(phone);
        res.json({ code: result.success ? 0 : 500, message: result.success ? '发送成功' : result.errorMsg, data: result });
    }
    catch (error) {
        next(error);
    }
});
// ==================== 钉钉配置 ====================
// 获取钉钉配置
router.get('/config/dingtalk', async (req, res, next) => {
    try {
        const configRepo = data_source_1.AppDataSource.getRepository(sys_entity_1.SysConfig);
        const config = await configRepo.findOne({ where: { configKey: 'dingtalk_config' } });
        let dingtalkConfig = {
            enabled: false,
            webhook: '',
            secret: '',
        };
        if (config && config.configValue) {
            const savedConfig = JSON.parse(config.configValue);
            dingtalkConfig = { ...dingtalkConfig, ...savedConfig, secret: savedConfig.secret ? '******' : '' };
        }
        res.json({ code: 0, message: 'success', data: dingtalkConfig });
    }
    catch (error) {
        next(error);
    }
});
// 保存钉钉配置
router.post('/config/dingtalk', [(0, express_validator_1.body)('webhook').notEmpty().withMessage('Webhook地址不能为空')], validate, async (req, res, next) => {
    try {
        const { enabled, webhook, secret } = req.body;
        const configRepo = data_source_1.AppDataSource.getRepository(sys_entity_1.SysConfig);
        let config = await configRepo.findOne({ where: { configKey: 'dingtalk_config' } });
        const configValue = JSON.stringify({ enabled, webhook, secret });
        if (config) {
            await configRepo.update(config.id, { configValue, updateTime: new Date() });
        }
        else {
            config = configRepo.create({
                id: (0, uuid_1.v4)(),
                configName: '钉钉配置',
                configKey: 'dingtalk_config',
                configValue,
                configType: 'json',
                groupName: '通知',
                remark: '钉钉群机器人配置',
                status: 1,
                createTime: new Date(),
                updateTime: new Date(),
            });
            await configRepo.save(config);
        }
        await notificationService.initializeNotificationConfig();
        res.json({ code: 0, message: '保存成功', data: null });
    }
    catch (error) {
        next(error);
    }
});
// 测试钉钉发送
router.post('/config/dingtalk/test', async (req, res, next) => {
    try {
        const result = await notificationService.testDingTalk();
        res.json({ code: result.success ? 0 : 500, message: result.success ? '发送成功' : result.errorMsg, data: result });
    }
    catch (error) {
        next(error);
    }
});
// ==================== 企业微信配置 ====================
// 获取企业微信配置
router.get('/config/wecom', async (req, res, next) => {
    try {
        const configRepo = data_source_1.AppDataSource.getRepository(sys_entity_1.SysConfig);
        const config = await configRepo.findOne({ where: { configKey: 'wecom_config' } });
        let wecomConfig = {
            enabled: false,
            corpId: '',
            corpSecret: '',
            agentId: '',
            webhookUrl: '',
        };
        if (config && config.configValue) {
            const savedConfig = JSON.parse(config.configValue);
            wecomConfig = { ...wecomConfig, ...savedConfig, corpSecret: savedConfig.corpSecret ? '******' : '' };
        }
        res.json({ code: 0, message: 'success', data: wecomConfig });
    }
    catch (error) {
        next(error);
    }
});
// 保存企业微信配置
router.post('/config/wecom', [
    (0, express_validator_1.body)('corpId').notEmpty().withMessage('企业ID不能为空'),
    (0, express_validator_1.body)('corpSecret').notEmpty().withMessage('应用Secret不能为空'),
    (0, express_validator_1.body)('agentId').notEmpty().withMessage('应用AgentId不能为空'),
], validate, async (req, res, next) => {
    try {
        const { enabled, corpId, corpSecret, agentId, webhookUrl } = req.body;
        const configRepo = data_source_1.AppDataSource.getRepository(sys_entity_1.SysConfig);
        let config = await configRepo.findOne({ where: { configKey: 'wecom_config' } });
        const configValue = JSON.stringify({ enabled, corpId, corpSecret, agentId, webhookUrl });
        if (config) {
            await configRepo.update(config.id, { configValue, updateTime: new Date() });
        }
        else {
            config = configRepo.create({
                id: (0, uuid_1.v4)(),
                configName: '企业微信配置',
                configKey: 'wecom_config',
                configValue,
                configType: 'json',
                groupName: '通知',
                remark: '企业微信应用配置',
                status: 1,
                createTime: new Date(),
                updateTime: new Date(),
            });
            await configRepo.save(config);
        }
        await notificationService.initializeNotificationConfig();
        res.json({ code: 0, message: '保存成功', data: null });
    }
    catch (error) {
        next(error);
    }
});
// 测试企业微信发送
router.post('/config/wecom/test', async (req, res, next) => {
    try {
        const result = await notificationService.testWeCom();
        res.json({ code: result.success ? 0 : 500, message: result.success ? '发送成功' : result.errorMsg, data: result });
    }
    catch (error) {
        next(error);
    }
});
// ==================== 发送告警通知 ====================
// 发送告警通知
router.post('/alert', async (req, res, next) => {
    try {
        const { level, title, content, channels, targets } = req.body;
        if (!title || !content) {
            return res.status(400).json({ code: 400, message: '标题和内容不能为空', data: null });
        }
        const result = await notificationService.sendAlertNotification({
            level: level || 'info',
            title,
            content,
            timestamp: new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' }),
            channels: channels || ['email'],
            targets,
        });
        const allSuccess = Object.values(result).every((r) => r?.success);
        res.json({ code: allSuccess ? 0 : 500, message: allSuccess ? '发送成功' : '部分发送失败', data: result });
    }
    catch (error) {
        next(error);
    }
});
exports.default = router;
//# sourceMappingURL=notification.routes.js.map
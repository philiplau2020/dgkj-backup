"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const os_1 = __importDefault(require("os"));
const router = (0, express_1.Router)();
// 模拟数据
const mockServers = [
    {
        id: 'srv-001',
        hostname: 'dgkj-server',
        ip: '120.78.7.180',
        port: 22,
        os: 'Ubuntu 22.04',
        cpuUsage: 15.5,
        cpuCores: 2,
        memTotal: 2048,
        memUsed: 1024,
        memUsage: 50,
        diskTotal: 51200,
        diskUsed: 20480,
        diskUsage: 40,
        uptime: os_1.default.uptime(),
        status: 'online',
        role: 'Primary',
        lastHeartbeat: new Date().toISOString()
    }
];
const mockServices = [
    {
        id: 'svc-001',
        name: 'dgkj-server',
        displayName: 'DGKJ 后端服务',
        version: '1.0.0',
        host: '127.0.0.1',
        port: 3000,
        status: 'running',
        pid: 58606,
        startTime: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
        uptime: 2 * 60 * 60,
        healthCheckUrl: '/health',
        healthStatus: 'healthy',
        responseTime: 25,
        requests: 15420,
        errors: 2,
        cpuUsage: 8.5,
        memUsage: 120
    },
    {
        id: 'svc-002',
        name: 'nginx',
        displayName: 'Nginx Web 服务',
        version: '1.18.0',
        host: '127.0.0.1',
        port: 80,
        status: 'running',
        pid: 1,
        startTime: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
        uptime: 24 * 60 * 60,
        healthCheckUrl: '',
        healthStatus: 'healthy',
        responseTime: 5,
        requests: 45678,
        errors: 0,
        cpuUsage: 1.2,
        memUsage: 45
    },
    {
        id: 'svc-003',
        name: 'mysql',
        displayName: 'MySQL 数据库',
        version: '8.0.36',
        host: '127.0.0.1',
        port: 3306,
        status: 'running',
        pid: 1234,
        startTime: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
        uptime: 24 * 60 * 60,
        healthCheckUrl: '',
        healthStatus: 'healthy',
        responseTime: 10,
        requests: 8956,
        errors: 0,
        cpuUsage: 5.8,
        memUsage: 512
    }
];
const mockAlerts = [
    {
        id: 'alert-001',
        level: 'info',
        title: '服务正常运行',
        content: '所有监控指标正常，系统运行稳定',
        source: 'system',
        host: '120.78.7.180',
        metric: 'system.health',
        value: 100,
        threshold: 90,
        unit: '%',
        status: 'active',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        duration: 0,
        count: 1
    }
];
// 综合概览
router.get('/overview', (req, res) => {
    const totalMem = os_1.default.totalmem();
    const freeMem = os_1.default.freemem();
    const usedMem = totalMem - freeMem;
    const overview = {
        serverCount: 1,
        serverOnline: 1,
        serviceCount: mockServices.length,
        serviceRunning: mockServices.filter(s => s.status === 'running').length,
        alertCount: mockAlerts.filter(a => a.status === 'active').length,
        cpuUsage: parseFloat((Math.random() * 30 + 10).toFixed(1)),
        memUsage: parseFloat(((usedMem / totalMem) * 100).toFixed(1)),
        diskUsage: 40,
        networkIn: Math.floor(Math.random() * 10000),
        networkOut: Math.floor(Math.random() * 8000),
        uptime: os_1.default.uptime(),
        timestamp: new Date().toISOString()
    };
    res.json(overview);
});
// 服务器列表
router.get('/server/list', (req, res) => {
    const { page = 1, pageSize = 10 } = req.query;
    const start = (Number(page) - 1) * Number(pageSize);
    const list = mockServers.slice(start, start + Number(pageSize));
    res.json({ list, total: mockServers.length });
});
// 服务器详情
router.get('/server/detail/:id', (req, res) => {
    const server = mockServers.find(s => s.id === req.params.id) || mockServers[0];
    res.json(server);
});
// 服务列表
router.get('/service/list', (req, res) => {
    const { page = 1, pageSize = 10 } = req.query;
    const start = (Number(page) - 1) * Number(pageSize);
    const list = mockServices.slice(start, start + Number(pageSize));
    res.json({ list, total: mockServices.length });
});
// 服务详情
router.get('/service/detail/:id', (req, res) => {
    const service = mockServices.find(s => s.id === req.params.id) || mockServices[0];
    res.json(service);
});
// 服务健康检查
router.get('/service/health', (req, res) => {
    const health = {
        status: 'healthy',
        services: mockServices.map(s => ({
            name: s.name,
            status: s.healthStatus,
            responseTime: s.responseTime + Math.floor(Math.random() * 10)
        })),
        timestamp: new Date().toISOString()
    };
    res.json(health);
});
// 应用指标
router.get('/app/metrics', (req, res) => {
    const metrics = [{
            id: 'app-001',
            name: 'dgkj-api',
            group: 'api',
            requests: 15420,
            errors: 2,
            avgResponseTime: 45,
            p99ResponseTime: 120,
            qps: 2.1,
            concurrency: 15,
            cpuUsage: 8.5,
            memUsage: 35,
            jvmHeapUsed: 256,
            jvmHeapMax: 512,
            jvmHeapUsage: 50,
            jvmOldGenUsage: 40,
            jvmYoungGenUsage: 60,
            threadCount: 45,
            threadPeak: 52,
            dbActive: 10,
            dbIdle: 20,
            gcCount: 125,
            gcTime: 500
        }];
    res.json(metrics);
});
// 应用列表
router.get('/app/list', (req, res) => {
    res.json({ list: mockServices, total: mockServices.length });
});
// 网络列表
router.get('/network/list', (req, res) => {
    const interfaces = os_1.default.networkInterfaces();
    const list = Object.entries(interfaces).map(([name, addrs]) => {
        const addr = addrs?.find(a => !a.internal && a.family === 'IPv4');
        return {
            id: `net-${name}`,
            interfaceName: name,
            ip: addr?.address || '127.0.0.1',
            mac: addr?.mac || '00:00:00:00:00:00',
            status: 'up',
            speed: '1Gbps',
            rxBytes: Math.floor(Math.random() * 1000000000),
            txBytes: Math.floor(Math.random() * 500000000),
            rxPackets: Math.floor(Math.random() * 1000000),
            txPackets: Math.floor(Math.random() * 800000),
            rxErrors: 0,
            txErrors: 0,
            bandwidthIn: Math.floor(Math.random() * 100),
            bandwidthOut: Math.floor(Math.random() * 80)
        };
    });
    res.json({ list, total: list.length });
});
// 网络端口
router.get('/network/port/:serverId', (req, res) => {
    const ports = [
        { id: 'p-1', serverId: 'srv-001', port: 22, protocol: 'TCP', state: 'LISTEN', processName: 'sshd', pid: 1234, connections: 1, bindAddress: '0.0.0.0' },
        { id: 'p-2', serverId: 'srv-001', port: 80, protocol: 'TCP', state: 'LISTEN', processName: 'nginx', pid: 5678, connections: 12, bindAddress: '0.0.0.0' },
        { id: 'p-3', serverId: 'srv-001', port: 443, protocol: 'TCP', state: 'LISTEN', processName: 'nginx', pid: 5678, connections: 8, bindAddress: '0.0.0.0' },
        { id: 'p-4', serverId: 'srv-001', port: 3000, protocol: 'TCP', state: 'LISTEN', processName: 'node', pid: 58606, connections: 3, bindAddress: '127.0.0.1' },
        { id: 'p-5', serverId: 'srv-001', port: 3306, protocol: 'TCP', state: 'LISTEN', processName: 'mysqld', pid: 1234, connections: 5, bindAddress: '127.0.0.1' }
    ];
    res.json(ports);
});
// 业务概览
router.get('/business/overview', (req, res) => {
    const overview = {
        orderCount: 12580,
        orderAmount: 2568900,
        successRate: 99.5,
        avgResponseTime: 120,
        activeUsers: 156,
        activeConnections: 45,
        queueLength: 0,
        cacheHitRate: 95.8
    };
    res.json(overview);
});
// 业务趋势
router.get('/business/trend', (req, res) => {
    const days = Number(req.query.days) || 7;
    const trend = [];
    for (let i = days - 1; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        trend.push({
            date: date.toISOString().split('T')[0],
            orderCount: Math.floor(Math.random() * 2000 + 1000),
            orderAmount: Math.floor(Math.random() * 500000 + 100000),
            successRate: 98 + Math.random() * 2,
            avgResponseTime: Math.floor(Math.random() * 50 + 80)
        });
    }
    res.json(trend);
});
// 业务 KPI
router.get('/business/kpi', (req, res) => {
    const kpi = {
        totalOrders: 12580,
        totalAmount: 2568900,
        todayOrders: 856,
        todayAmount: 158900,
        yesterdayOrders: 920,
        yesterdayAmount: 176500,
        weekGrowth: 5.2,
        monthGrowth: 12.8,
        avgOrderAmount: 204.2,
        conversionRate: 68.5
    };
    res.json(kpi);
});
// 日志列表
router.get('/log/list', (req, res) => {
    const { page = 1, pageSize = 20, level, serviceName } = req.query;
    const logs = [
        { id: 'log-001', timestamp: new Date().toISOString(), level: 'INFO', source: 'app', serviceName: 'dgkj-server', host: '120.78.7.180', message: '服务启动成功', traceId: 'trace-001', spanId: 'span-001' },
        { id: 'log-002', timestamp: new Date(Date.now() - 60000).toISOString(), level: 'INFO', source: 'app', serviceName: 'dgkj-server', host: '120.78.7.180', message: '数据库连接成功', traceId: 'trace-002', spanId: 'span-002' },
        { id: 'log-003', timestamp: new Date(Date.now() - 120000).toISOString(), level: 'WARN', source: 'app', serviceName: 'dgkj-server', host: '120.78.7.180', message: '请求响应时间较长', traceId: 'trace-003', spanId: 'span-003' },
        { id: 'log-004', timestamp: new Date(Date.now() - 180000).toISOString(), level: 'ERROR', source: 'app', serviceName: 'dgkj-server', host: '120.78.7.180', message: '第三方支付接口调用失败', traceId: 'trace-004', spanId: 'span-004' },
        { id: 'log-005', timestamp: new Date(Date.now() - 240000).toISOString(), level: 'INFO', source: 'nginx', serviceName: 'nginx', host: '120.78.7.180', message: '新的连接建立', traceId: '', spanId: '' }
    ];
    let filtered = logs;
    if (level)
        filtered = filtered.filter(l => l.level === String(level).toUpperCase());
    if (serviceName)
        filtered = filtered.filter(l => l.serviceName === String(serviceName));
    const start = (Number(page) - 1) * Number(pageSize);
    res.json({ list: filtered.slice(start, start + Number(pageSize)), total: filtered.length });
});
// 日志详情
router.get('/log/detail/:id', (req, res) => {
    const log = {
        id: req.params.id,
        timestamp: new Date().toISOString(),
        level: 'INFO',
        source: 'app',
        serviceName: 'dgkj-server',
        host: '120.78.7.180',
        message: '详细的日志内容...',
        traceId: 'trace-001',
        spanId: 'span-001',
        exception: null,
        stackTrace: null
    };
    res.json(log);
});
// 日志统计
router.get('/log/statistics', (req, res) => {
    const stats = {
        totalCount: 158420,
        todayCount: 856,
        errorCount: 12,
        warnCount: 45,
        infoCount: 799,
        levels: { DEBUG: 0, INFO: 799, WARN: 45, ERROR: 12, FATAL: 0 },
        services: { 'dgkj-server': 856, 'nginx': 0, 'mysql': 0 }
    };
    res.json(stats);
});
// 告警列表
router.get('/alert/list', (req, res) => {
    const { page = 1, pageSize = 10, level, status } = req.query;
    let filtered = mockAlerts;
    if (level)
        filtered = filtered.filter(a => a.level === level);
    if (status)
        filtered = filtered.filter(a => a.status === status);
    const start = (Number(page) - 1) * Number(pageSize);
    res.json({ list: filtered.slice(start, start + Number(pageSize)), total: filtered.length });
});
// 告警详情
router.get('/alert/detail/:id', (req, res) => {
    const alert = mockAlerts.find(a => a.id === req.params.id) || mockAlerts[0];
    res.json(alert);
});
// 处理告警
router.post('/alert/handle/:id', (req, res) => {
    const { action, note } = req.body;
    res.json({ id: req.params.id, action, note, handledAt: new Date().toISOString() });
});
// 告警规则
router.get('/alert/rule', (req, res) => {
    const rules = [
        { id: 'rule-001', name: 'CPU 使用率告警', metric: 'system.cpu.usage', threshold: 80, level: 'warning', enabled: true },
        { id: 'rule-002', name: '内存使用率告警', metric: 'system.mem.usage', threshold: 85, level: 'warning', enabled: true },
        { id: 'rule-003', name: '磁盘使用率告警', metric: 'system.disk.usage', threshold: 90, level: 'error', enabled: true },
        { id: 'rule-004', name: '服务响应时间告警', metric: 'service.response.time', threshold: 500, level: 'warning', enabled: true }
    ];
    res.json({ list: rules, total: rules.length });
});
exports.default = router;
//# sourceMappingURL=routes.js.map
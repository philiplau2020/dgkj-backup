/**
 * DGKJ 支付平台 - 对账自动化服务
 *
 * 自动对账、差错处理
 */
export declare class CheckService {
    private batchRepo;
    private channelBillRepo;
    private diffRepo;
    private orderRepo;
    private refundRepo;
    /**
     * 创建对账批次
     */
    createBatch(params: {
        checkDate: string;
        channelCode?: string;
    }): Promise<any>;
    /**
     * 执行对账
     */
    executeCheck(batchNo: string): Promise<any>;
    /**
     * 下载通道对账单
     */
    private downloadChannelBill;
    /**
     * 获取通道对账单 (模拟)
     */
    private fetchChannelBill;
    /**
     * 比对账单
     */
    private compareBills;
    /**
     * 获取对账批次列表
     */
    getBatchList(params: {
        page?: number;
        pageSize?: number;
        checkDate?: string;
        channelCode?: string;
        status?: number;
    }): Promise<any>;
    /**
     * 获取对账差异列表
     */
    getDiffList(params: {
        page?: number;
        pageSize?: number;
        batchNo?: string;
        diffType?: number;
        startTime?: string;
        endTime?: string;
    }): Promise<any>;
    /**
     * 处理差异
     */
    handleDiff(params: {
        id: string;
        handleType: number;
        handleRemark?: string;
    }): Promise<any>;
    /**
     * 获取通道账单列表
     */
    getChannelBillList(params: {
        page?: number;
        pageSize?: number;
        batchNo?: string;
        channelCode?: string;
    }): Promise<any>;
    /**
     * 自动对账任务 (每日定时执行)
     */
    autoDailyCheck(): Promise<any>;
    /**
     * 获取对账汇总
     */
    getCheckSummary(params: {
        startDate: string;
        endDate: string;
    }): Promise<any>;
    private getChannelName;
    private getDiffTypeName;
}
declare const _default: CheckService;
export default _default;
//# sourceMappingURL=check.service.d.ts.map
/**
 * DGKJ 支付平台 - 微信支付通道实现
 *
 * 支持: Native扫码支付、JSAPI支付、APP支付、H5支付、小程序支付
 */
import { IPaymentChannel, ChannelConfig, UnifiedPayRequest, UnifiedPayResponse, UnifiedQueryRequest, UnifiedQueryResponse, UnifiedRefundRequest, UnifiedRefundResponse, UnifiedTransferRequest, UnifiedTransferResponse, UnifiedCallbackData, PayWay, ChannelCode } from './interface';
export declare class WechatPayChannel implements IPaymentChannel {
    readonly channelCode = ChannelCode.WECHAT;
    readonly channelName = "\u5FAE\u4FE1\u652F\u4ED8";
    readonly supportedPayWays: PayWay[];
    private config;
    private getBaseUrl;
    initialize(config: ChannelConfig): void;
    /**
     * 执行支付
     */
    pay(request: UnifiedPayRequest): Promise<UnifiedPayResponse>;
    /**
     * Native扫码支付
     */
    private nativePay;
    /**
     * JSAPI支付
     */
    private jsapiPay;
    /**
     * APP支付
     */
    private appPay;
    /**
     * H5支付
     */
    private h5Pay;
    /**
     * 查询订单
     */
    query(request: UnifiedQueryRequest): Promise<UnifiedQueryResponse>;
    /**
     * 申请退款
     */
    refund(request: UnifiedRefundRequest): Promise<UnifiedRefundResponse>;
    /**
     * 转账 (企业付款到零钱)
     */
    transfer(request: UnifiedTransferRequest): Promise<UnifiedTransferResponse>;
    /**
     * 验证回调签名
     */
    verifyCallback(data: any, headers: any): Promise<{
        success: boolean;
        errorMsg?: string;
    }>;
    /**
     * 解析回调数据
     */
    parseCallback(data: any): Promise<UnifiedCallbackData>;
    /**
     * 响应回调成功
     */
    responseCallbackSuccess(): string;
    /**
     * 响应回调失败
     */
    responseCallbackFail(): string;
    /**
     * 构建统一下单参数
     */
    private buildUnifiedOrderParams;
    /**
     * 签名
     */
    private sign;
    /**
     * 发送带证书的请求
     */
    private requestWithCert;
    /**
     * 构建 XML
     */
    private buildXml;
    /**
     * 解析 XML
     */
    private parseXml;
    /**
     * 生成随机字符串
     */
    private generateNonce;
    /**
     * 生成二维码
     */
    private generateQRCode;
}
declare const _default: WechatPayChannel;
export default _default;
//# sourceMappingURL=wechat.d.ts.map
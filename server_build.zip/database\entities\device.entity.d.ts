export declare enum DeviceStatus {
    DISABLED = 0,
    ENABLED = 1,
    ACTIVATED = 2,
    LOST = 3
}
export declare enum DeviceType {
    QR_CODE = 1,
    SPEAKER = 2,
    PRINTER = 3,
    POS = 4
}
export declare class DeviceInfo {
    id: string;
    deviceNo: string;
    deviceType: DeviceType;
    deviceName: string;
    deviceModel: string;
    mchNo: string;
    storeId: string;
    sn: string;
    iccid: string;
    imei: string;
    status: DeviceStatus;
    activateTime: Date;
    lastHeartbeat: Date;
    remark: string;
    createTime: Date;
    updateTime: Date;
}
export declare class DeviceActivationCode {
    id: string;
    code: string;
    deviceType: DeviceType;
    batchNo: string;
    status: number;
    usedTime: Date;
    usedMchNo: string;
    expireTime: Date;
    createTime: Date;
}
export declare class DeviceBinding {
    id: string;
    deviceNo: string;
    mchNo: string;
    storeId: string;
    bindingType: number;
    status: number;
    createTime: Date;
    updateTime: Date;
}
//# sourceMappingURL=device.entity.d.ts.map
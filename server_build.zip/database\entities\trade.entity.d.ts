export declare enum OrderStatus {
    PENDING = 0,
    SUCCESS = 1,
    FAILED = 2,
    CLOSED = 3,
    REFUNDING = 4,
    REFUNDED = 5
}
export declare enum TradeType {
    PAY = 1,
    REFUND = 2,
    TRANSFER = 3,
    WITHDRAW = 4
}
export declare enum PayType {
    WX_NATIVE = "WX_NATIVE",
    WX_APP = "WX_APP",
    WX_JSAPI = "WX_JSAPI",
    WX_H5 = "WX_H5",
    ALI_QR = "ALI_QR",
    ALI_APP = "ALI_APP",
    ALI_WAP = "ALI_WAP",
    ALI_JSAPI = "ALI_JSAPI",
    UNION_QR = "UNION_QR",
    UNION_JK = "UNION_JK",
    YSF_QR = "YSF_QR",
    CASH = "CASH"
}
export declare class PayOrder {
    id: string;
    orderNo: string;
    mchNo: string;
    mchName: string;
    appId: string;
    channelCode: string;
    payType: PayType;
    tradeType: TradeType;
    amount: number;
    couponAmount: number;
    actualAmount: number;
    fee: number;
    profitAmount: number;
    subject: string;
    body: string;
    channelOrderNo: string;
    payUrl: string;
    payTime: Date;
    expireTime: Date;
    status: OrderStatus;
    notifyStatus: number;
    notifyTime: Date;
    notifyUrl: string;
    clientIp: string;
    attach: string;
    remark: string;
    createTime: Date;
    updateTime: Date;
}
export declare class RefundOrder {
    id: string;
    refundNo: string;
    orderNo: string;
    mchNo: string;
    appId: string;
    channelCode: string;
    payType: string;
    amount: number;
    refundAmount: number;
    refundReason: string;
    channelRefundNo: string;
    refundTime: Date;
    status: number;
    remark: string;
    createTime: Date;
    updateTime: Date;
}
export declare class TransferOrder {
    id: string;
    transferNo: string;
    mchNo: string;
    appId: string;
    outNo: string;
    amount: number;
    fee: number;
    actualAmount: number;
    payType: string;
    accountType: number;
    accountName: string;
    accountNo: string;
    bankName: string;
    bankCode: string;
    status: number;
    channelTransferNo: string;
    completeTime: Date;
    remark: string;
    createTime: Date;
    updateTime: Date;
}
export declare class TradeNotify {
    id: string;
    notifyId: string;
    orderNo: string;
    mchNo: string;
    appId: string;
    notifyUrl: string;
    notifyType: number;
    status: number;
    notifyCount: number;
    lastNotifyTime: Date;
    nextNotifyTime: Date;
    responseResult: string;
    createTime: Date;
    updateTime: Date;
}
//# sourceMappingURL=trade.entity.d.ts.map
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CiticAccountRecord = exports.CiticCheck = exports.CiticSettlement = exports.CiticTransfer = exports.CiticProfitShare = exports.CiticCollection = exports.CiticCard = exports.CiticAccount = exports.CiticCheckStatus = exports.CiticSettlementStatus = exports.CiticTransferStatus = exports.CiticProfitShareStatus = exports.CiticCollectionStatus = exports.CiticCardStatus = exports.CiticCardType = exports.CiticAccountType = exports.CiticAccountStatus = void 0;
const typeorm_1 = require("typeorm");
// ========== 枚举定义 ==========
/** 账户状态 */
var CiticAccountStatus;
(function (CiticAccountStatus) {
    CiticAccountStatus[CiticAccountStatus["DISABLED"] = 0] = "DISABLED";
    CiticAccountStatus[CiticAccountStatus["ENABLED"] = 1] = "ENABLED";
})(CiticAccountStatus || (exports.CiticAccountStatus = CiticAccountStatus = {}));
/** 账户类型 */
var CiticAccountType;
(function (CiticAccountType) {
    CiticAccountType[CiticAccountType["PERSONAL"] = 1] = "PERSONAL";
    CiticAccountType[CiticAccountType["ENTERPRISE"] = 2] = "ENTERPRISE";
})(CiticAccountType || (exports.CiticAccountType = CiticAccountType = {}));
/** 银行卡类型 */
var CiticCardType;
(function (CiticCardType) {
    CiticCardType[CiticCardType["PUBLIC"] = 1] = "PUBLIC";
    CiticCardType[CiticCardType["PRIVATE"] = 2] = "PRIVATE";
})(CiticCardType || (exports.CiticCardType = CiticCardType = {}));
/** 银行卡状态 */
var CiticCardStatus;
(function (CiticCardStatus) {
    CiticCardStatus[CiticCardStatus["UNBIND"] = 0] = "UNBIND";
    CiticCardStatus[CiticCardStatus["BIND"] = 1] = "BIND";
    CiticCardStatus[CiticCardStatus["FROZEN"] = 2] = "FROZEN";
})(CiticCardStatus || (exports.CiticCardStatus = CiticCardStatus = {}));
/** 归集状态 */
var CiticCollectionStatus;
(function (CiticCollectionStatus) {
    CiticCollectionStatus[CiticCollectionStatus["PENDING"] = 0] = "PENDING";
    CiticCollectionStatus[CiticCollectionStatus["SUCCESS"] = 1] = "SUCCESS";
    CiticCollectionStatus[CiticCollectionStatus["FAILED"] = 2] = "FAILED";
    CiticCollectionStatus[CiticCollectionStatus["PROCESSING"] = 3] = "PROCESSING";
})(CiticCollectionStatus || (exports.CiticCollectionStatus = CiticCollectionStatus = {}));
/** 分账状态 */
var CiticProfitShareStatus;
(function (CiticProfitShareStatus) {
    CiticProfitShareStatus[CiticProfitShareStatus["PENDING"] = 0] = "PENDING";
    CiticProfitShareStatus[CiticProfitShareStatus["SUCCESS"] = 1] = "SUCCESS";
    CiticProfitShareStatus[CiticProfitShareStatus["FAILED"] = 2] = "FAILED";
    CiticProfitShareStatus[CiticProfitShareStatus["PROCESSING"] = 3] = "PROCESSING";
})(CiticProfitShareStatus || (exports.CiticProfitShareStatus = CiticProfitShareStatus = {}));
/** 代付状态 */
var CiticTransferStatus;
(function (CiticTransferStatus) {
    CiticTransferStatus[CiticTransferStatus["PENDING"] = 0] = "PENDING";
    CiticTransferStatus[CiticTransferStatus["SUCCESS"] = 1] = "SUCCESS";
    CiticTransferStatus[CiticTransferStatus["FAILED"] = 2] = "FAILED";
    CiticTransferStatus[CiticTransferStatus["PROCESSING"] = 3] = "PROCESSING";
})(CiticTransferStatus || (exports.CiticTransferStatus = CiticTransferStatus = {}));
/** 结算状态 */
var CiticSettlementStatus;
(function (CiticSettlementStatus) {
    CiticSettlementStatus[CiticSettlementStatus["PENDING"] = 0] = "PENDING";
    CiticSettlementStatus[CiticSettlementStatus["PROCESSING"] = 1] = "PROCESSING";
    CiticSettlementStatus[CiticSettlementStatus["SUCCESS"] = 2] = "SUCCESS";
    CiticSettlementStatus[CiticSettlementStatus["FAILED"] = 3] = "FAILED";
})(CiticSettlementStatus || (exports.CiticSettlementStatus = CiticSettlementStatus = {}));
/** 对账状态 */
var CiticCheckStatus;
(function (CiticCheckStatus) {
    CiticCheckStatus[CiticCheckStatus["PENDING"] = 0] = "PENDING";
    CiticCheckStatus[CiticCheckStatus["DIFF"] = 1] = "DIFF";
    CiticCheckStatus[CiticCheckStatus["BALANCED"] = 2] = "BALANCED";
})(CiticCheckStatus || (exports.CiticCheckStatus = CiticCheckStatus = {}));
// ========== 实体定义 ==========
/**
 * 中信银行E管家账户实体
 * 对应中信银行用户账户信息
 */
let CiticAccount = class CiticAccount {
};
exports.CiticAccount = CiticAccount;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], CiticAccount.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'biz_user_id', length: 64, unique: true }),
    __metadata("design:type", String)
], CiticAccount.prototype, "bizUserId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_no', length: 32, unique: true }),
    __metadata("design:type", String)
], CiticAccount.prototype, "accountNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_name', length: 128 }),
    __metadata("design:type", String)
], CiticAccount.prototype, "accountName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], CiticAccount.prototype, "accountType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_attr', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], CiticAccount.prototype, "accountAttr", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'balance', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CiticAccount.prototype, "balance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'available_balance', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CiticAccount.prototype, "availableBalance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'frozen_balance', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CiticAccount.prototype, "frozenBalance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'pending_balance', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CiticAccount.prototype, "pendingBalance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: CiticAccountStatus.ENABLED }),
    __metadata("design:type", Number)
], CiticAccount.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'audit_status', type: 'tinyint', default: 0 }),
    __metadata("design:type", Number)
], CiticAccount.prototype, "auditStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel', length: 32, nullable: true }),
    __metadata("design:type", String)
], CiticAccount.prototype, "channel", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_no', length: 32, nullable: true }),
    __metadata("design:type", String)
], CiticAccount.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'agent_no', length: 32, nullable: true }),
    __metadata("design:type", String)
], CiticAccount.prototype, "agentNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 500, nullable: true }),
    __metadata("design:type", String)
], CiticAccount.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], CiticAccount.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], CiticAccount.prototype, "updateTime", void 0);
exports.CiticAccount = CiticAccount = __decorate([
    (0, typeorm_1.Entity)('citic_account')
], CiticAccount);
/**
 * 中信银行银行卡实体
 * 对应中信银行用户绑定的银行卡信息
 */
let CiticCard = class CiticCard {
};
exports.CiticCard = CiticCard;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], CiticCard.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'biz_user_id', length: 64 }),
    __metadata("design:type", String)
], CiticCard.prototype, "bizUserId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_no', length: 32 }),
    __metadata("design:type", String)
], CiticCard.prototype, "accountNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'card_no', length: 32, unique: true }),
    __metadata("design:type", String)
], CiticCard.prototype, "cardNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'card_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], CiticCard.prototype, "cardType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_name', length: 64 }),
    __metadata("design:type", String)
], CiticCard.prototype, "bankName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_code', length: 32 }),
    __metadata("design:type", String)
], CiticCard.prototype, "bankCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'branch_name', length: 128, nullable: true }),
    __metadata("design:type", String)
], CiticCard.prototype, "branchName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'branch_code', length: 32, nullable: true }),
    __metadata("design:type", String)
], CiticCard.prototype, "branchCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'card_holder', length: 64 }),
    __metadata("design:type", String)
], CiticCard.prototype, "cardHolder", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'cert_no', length: 32, nullable: true }),
    __metadata("design:type", String)
], CiticCard.prototype, "certNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'phone', length: 32, nullable: true }),
    __metadata("design:type", String)
], CiticCard.prototype, "phone", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'cvv2', length: 8, nullable: true }),
    __metadata("design:type", String)
], CiticCard.prototype, "cvv2", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'expire_date', length: 8, nullable: true }),
    __metadata("design:type", String)
], CiticCard.prototype, "expireDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: CiticCardStatus.BIND }),
    __metadata("design:type", Number)
], CiticCard.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bind_time', nullable: true }),
    __metadata("design:type", Date)
], CiticCard.prototype, "bindTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'unbind_time', nullable: true }),
    __metadata("design:type", Date)
], CiticCard.prototype, "unbindTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'unbind_reason', length: 255, nullable: true }),
    __metadata("design:type", String)
], CiticCard.prototype, "unbindReason", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 500, nullable: true }),
    __metadata("design:type", String)
], CiticCard.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], CiticCard.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], CiticCard.prototype, "updateTime", void 0);
exports.CiticCard = CiticCard = __decorate([
    (0, typeorm_1.Entity)('citic_card')
], CiticCard);
/**
 * 资金归集关系实体
 * 定义账户间的资金归集关系
 */
let CiticCollection = class CiticCollection {
};
exports.CiticCollection = CiticCollection;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], CiticCollection.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'collection_no', length: 64, unique: true }),
    __metadata("design:type", String)
], CiticCollection.prototype, "collectionNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'from_account_no', length: 32 }),
    __metadata("design:type", String)
], CiticCollection.prototype, "fromAccountNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'from_account_name', length: 128, nullable: true }),
    __metadata("design:type", String)
], CiticCollection.prototype, "fromAccountName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'to_account_no', length: 32 }),
    __metadata("design:type", String)
], CiticCollection.prototype, "toAccountNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'to_account_name', length: 128, nullable: true }),
    __metadata("design:type", String)
], CiticCollection.prototype, "toAccountName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'collection_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], CiticCollection.prototype, "collectionType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'collection_amount', type: 'decimal', precision: 18, scale: 2, nullable: true }),
    __metadata("design:type", Number)
], CiticCollection.prototype, "collectionAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'reserved_amount', type: 'decimal', precision: 18, scale: 2, nullable: true }),
    __metadata("design:type", Number)
], CiticCollection.prototype, "reservedAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: CiticCollectionStatus.PENDING }),
    __metadata("design:type", Number)
], CiticCollection.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'relation_status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], CiticCollection.prototype, "relationStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'collection_amount_real', type: 'decimal', precision: 18, scale: 2, nullable: true }),
    __metadata("design:type", Number)
], CiticCollection.prototype, "collectionAmountReal", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'complete_time', nullable: true }),
    __metadata("design:type", Date)
], CiticCollection.prototype, "completeTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fail_reason', length: 255, nullable: true }),
    __metadata("design:type", String)
], CiticCollection.prototype, "failReason", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 500, nullable: true }),
    __metadata("design:type", String)
], CiticCollection.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], CiticCollection.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], CiticCollection.prototype, "updateTime", void 0);
exports.CiticCollection = CiticCollection = __decorate([
    (0, typeorm_1.Entity)('citic_collection')
], CiticCollection);
/**
 * 余额分账关系实体
 * 定义分账各方及分账比例
 */
let CiticProfitShare = class CiticProfitShare {
};
exports.CiticProfitShare = CiticProfitShare;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], CiticProfitShare.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'share_no', length: 64, unique: true }),
    __metadata("design:type", String)
], CiticProfitShare.prototype, "shareNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'order_no', length: 64, nullable: true }),
    __metadata("design:type", String)
], CiticProfitShare.prototype, "orderNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_no', length: 32 }),
    __metadata("design:type", String)
], CiticProfitShare.prototype, "accountNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_name', length: 128, nullable: true }),
    __metadata("design:type", String)
], CiticProfitShare.prototype, "accountName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'receiver_account_no', length: 32 }),
    __metadata("design:type", String)
], CiticProfitShare.prototype, "receiverAccountNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'receiver_name', length: 128, nullable: true }),
    __metadata("design:type", String)
], CiticProfitShare.prototype, "receiverName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'share_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], CiticProfitShare.prototype, "shareType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'share_rate', type: 'decimal', precision: 10, scale: 4, nullable: true }),
    __metadata("design:type", Number)
], CiticProfitShare.prototype, "shareRate", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'share_amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], CiticProfitShare.prototype, "shareAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'order_amount', type: 'decimal', precision: 18, scale: 2, nullable: true }),
    __metadata("design:type", Number)
], CiticProfitShare.prototype, "orderAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: CiticProfitShareStatus.PENDING }),
    __metadata("design:type", Number)
], CiticProfitShare.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'share_time', nullable: true }),
    __metadata("design:type", Date)
], CiticProfitShare.prototype, "shareTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fail_reason', length: 255, nullable: true }),
    __metadata("design:type", String)
], CiticProfitShare.prototype, "failReason", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 500, nullable: true }),
    __metadata("design:type", String)
], CiticProfitShare.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], CiticProfitShare.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], CiticProfitShare.prototype, "updateTime", void 0);
exports.CiticProfitShare = CiticProfitShare = __decorate([
    (0, typeorm_1.Entity)('citic_profit_share')
], CiticProfitShare);
/**
 * 代付打款实体
 * 对应中信银行代付业务
 */
let CiticTransfer = class CiticTransfer {
};
exports.CiticTransfer = CiticTransfer;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], CiticTransfer.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'transfer_no', length: 64, unique: true }),
    __metadata("design:type", String)
], CiticTransfer.prototype, "transferNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'citic_order_no', length: 64, nullable: true }),
    __metadata("design:type", String)
], CiticTransfer.prototype, "citicOrderNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_no', length: 32 }),
    __metadata("design:type", String)
], CiticTransfer.prototype, "accountNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_name', length: 128, nullable: true }),
    __metadata("design:type", String)
], CiticTransfer.prototype, "accountName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'receiver_card_no', length: 32 }),
    __metadata("design:type", String)
], CiticTransfer.prototype, "receiverCardNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'receiver_bank_name', length: 64 }),
    __metadata("design:type", String)
], CiticTransfer.prototype, "receiverBankName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'receiver_bank_code', length: 32, nullable: true }),
    __metadata("design:type", String)
], CiticTransfer.prototype, "receiverBankCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'receiver_branch_name', length: 128, nullable: true }),
    __metadata("design:type", String)
], CiticTransfer.prototype, "receiverBranchName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'receiver_branch_code', length: 32, nullable: true }),
    __metadata("design:type", String)
], CiticTransfer.prototype, "receiverBranchCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'receiver_name', length: 64 }),
    __metadata("design:type", String)
], CiticTransfer.prototype, "receiverName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'receiver_phone', length: 32, nullable: true }),
    __metadata("design:type", String)
], CiticTransfer.prototype, "receiverPhone", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], CiticTransfer.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fee', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CiticTransfer.prototype, "fee", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'actual_amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], CiticTransfer.prototype, "actualAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'transfer_type', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], CiticTransfer.prototype, "transferType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: CiticTransferStatus.PENDING }),
    __metadata("design:type", Number)
], CiticTransfer.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'success_time', nullable: true }),
    __metadata("design:type", Date)
], CiticTransfer.prototype, "successTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fail_reason', length: 255, nullable: true }),
    __metadata("design:type", String)
], CiticTransfer.prototype, "failReason", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'notify_time', nullable: true }),
    __metadata("design:type", Date)
], CiticTransfer.prototype, "notifyTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 500, nullable: true }),
    __metadata("design:type", String)
], CiticTransfer.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], CiticTransfer.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], CiticTransfer.prototype, "updateTime", void 0);
exports.CiticTransfer = CiticTransfer = __decorate([
    (0, typeorm_1.Entity)('citic_transfer')
], CiticTransfer);
/**
 * 中信银行结算实体
 */
let CiticSettlement = class CiticSettlement {
};
exports.CiticSettlement = CiticSettlement;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], CiticSettlement.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'settle_no', length: 64, unique: true }),
    __metadata("design:type", String)
], CiticSettlement.prototype, "settleNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'citic_order_no', length: 64, nullable: true }),
    __metadata("design:type", String)
], CiticSettlement.prototype, "citicOrderNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_no', length: 32 }),
    __metadata("design:type", String)
], CiticSettlement.prototype, "accountNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_name', length: 128, nullable: true }),
    __metadata("design:type", String)
], CiticSettlement.prototype, "accountName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'settle_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], CiticSettlement.prototype, "settleType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], CiticSettlement.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fee', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CiticSettlement.prototype, "fee", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'actual_amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], CiticSettlement.prototype, "actualAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'target_card_no', length: 32 }),
    __metadata("design:type", String)
], CiticSettlement.prototype, "targetCardNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'target_bank_name', length: 64 }),
    __metadata("design:type", String)
], CiticSettlement.prototype, "targetBankName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'target_bank_code', length: 32, nullable: true }),
    __metadata("design:type", String)
], CiticSettlement.prototype, "targetBankCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'target_branch_name', length: 128, nullable: true }),
    __metadata("design:type", String)
], CiticSettlement.prototype, "targetBranchName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'target_branch_code', length: 32, nullable: true }),
    __metadata("design:type", String)
], CiticSettlement.prototype, "targetBranchCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: CiticSettlementStatus.PENDING }),
    __metadata("design:type", Number)
], CiticSettlement.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'settle_time', nullable: true }),
    __metadata("design:type", Date)
], CiticSettlement.prototype, "settleTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'complete_time', nullable: true }),
    __metadata("design:type", Date)
], CiticSettlement.prototype, "completeTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fail_reason', length: 255, nullable: true }),
    __metadata("design:type", String)
], CiticSettlement.prototype, "failReason", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 500, nullable: true }),
    __metadata("design:type", String)
], CiticSettlement.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], CiticSettlement.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], CiticSettlement.prototype, "updateTime", void 0);
exports.CiticSettlement = CiticSettlement = __decorate([
    (0, typeorm_1.Entity)('citic_settlement')
], CiticSettlement);
/**
 * 中信银行对账实体
 */
let CiticCheck = class CiticCheck {
};
exports.CiticCheck = CiticCheck;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], CiticCheck.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'check_no', length: 64, unique: true }),
    __metadata("design:type", String)
], CiticCheck.prototype, "checkNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'check_date', type: 'date' }),
    __metadata("design:type", Date)
], CiticCheck.prototype, "checkDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'check_type', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], CiticCheck.prototype, "checkType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_code', length: 32, nullable: true }),
    __metadata("design:type", String)
], CiticCheck.prototype, "channelCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_name', length: 64, nullable: true }),
    __metadata("design:type", String)
], CiticCheck.prototype, "channelName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], CiticCheck.prototype, "totalCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CiticCheck.prototype, "totalAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'success_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], CiticCheck.prototype, "successCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'success_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CiticCheck.prototype, "successAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fail_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], CiticCheck.prototype, "failCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fail_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CiticCheck.prototype, "failAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'diff_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], CiticCheck.prototype, "diffCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'diff_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CiticCheck.prototype, "diffAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: CiticCheckStatus.PENDING }),
    __metadata("design:type", Number)
], CiticCheck.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'file_path', length: 255, nullable: true }),
    __metadata("design:type", String)
], CiticCheck.prototype, "filePath", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'file_url', length: 500, nullable: true }),
    __metadata("design:type", String)
], CiticCheck.prototype, "fileUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 500, nullable: true }),
    __metadata("design:type", String)
], CiticCheck.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], CiticCheck.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], CiticCheck.prototype, "updateTime", void 0);
exports.CiticCheck = CiticCheck = __decorate([
    (0, typeorm_1.Entity)('citic_check')
], CiticCheck);
/**
 * 中信银行账户流水实体
 * 记录账户的所有资金变动
 */
let CiticAccountRecord = class CiticAccountRecord {
};
exports.CiticAccountRecord = CiticAccountRecord;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], CiticAccountRecord.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'record_no', length: 64, unique: true }),
    __metadata("design:type", String)
], CiticAccountRecord.prototype, "recordNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_no', length: 32 }),
    __metadata("design:type", String)
], CiticAccountRecord.prototype, "accountNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_name', length: 128, nullable: true }),
    __metadata("design:type", String)
], CiticAccountRecord.prototype, "accountName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'biz_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], CiticAccountRecord.prototype, "bizType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'biz_type_name', length: 32, nullable: true }),
    __metadata("design:type", String)
], CiticAccountRecord.prototype, "bizTypeName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], CiticAccountRecord.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'balance_before', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], CiticAccountRecord.prototype, "balanceBefore", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'balance_after', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], CiticAccountRecord.prototype, "balanceAfter", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'order_no', length: 64, nullable: true }),
    __metadata("design:type", String)
], CiticAccountRecord.prototype, "orderNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'opposite_account_no', length: 32, nullable: true }),
    __metadata("design:type", String)
], CiticAccountRecord.prototype, "oppositeAccountNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'opposite_account_name', length: 128, nullable: true }),
    __metadata("design:type", String)
], CiticAccountRecord.prototype, "oppositeAccountName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 500, nullable: true }),
    __metadata("design:type", String)
], CiticAccountRecord.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], CiticAccountRecord.prototype, "createTime", void 0);
exports.CiticAccountRecord = CiticAccountRecord = __decorate([
    (0, typeorm_1.Entity)('citic_account_record')
], CiticAccountRecord);
//# sourceMappingURL=citic.entity.js.map
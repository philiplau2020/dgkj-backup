"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OpDeveloper = void 0;
/**
 * 开放平台开发者实体
 */
const typeorm_1 = require("typeorm");
let OpDeveloper = class OpDeveloper {
};
exports.OpDeveloper = OpDeveloper;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], OpDeveloper.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, unique: true, comment: '开发者ID' }),
    __metadata("design:type", String)
], OpDeveloper.prototype, "developerId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, comment: '开发者名称/公司名' }),
    __metadata("design:type", String)
], OpDeveloper.prototype, "developerName", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, unique: true, comment: '登录账号' }),
    __metadata("design:type", String)
], OpDeveloper.prototype, "username", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, comment: '密码(bcrypt)' }),
    __metadata("design:type", String)
], OpDeveloper.prototype, "password", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, unique: true, comment: '邮箱' }),
    __metadata("design:type", String)
], OpDeveloper.prototype, "email", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 20, comment: '手机号' }),
    __metadata("design:type", String)
], OpDeveloper.prototype, "mobile", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, comment: '公司名称' }),
    __metadata("design:type", String)
], OpDeveloper.prototype, "company", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 18, comment: '统一社会信用代码' }),
    __metadata("design:type", String)
], OpDeveloper.prototype, "businessLicense", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true, comment: '营业执照图片URL' }),
    __metadata("design:type", String)
], OpDeveloper.prototype, "businessLicenseUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true, comment: '联系人姓名' }),
    __metadata("design:type", String)
], OpDeveloper.prototype, "contactPerson", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 20, nullable: true, comment: '联系人电话' }),
    __metadata("design:type", String)
], OpDeveloper.prototype, "contactPhone", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true, comment: '开发者简介' }),
    __metadata("design:type", String)
], OpDeveloper.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 500, nullable: true, comment: '官网地址' }),
    __metadata("design:type", String)
], OpDeveloper.prototype, "website", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: ['pending', 'active', 'suspended', 'rejected'], default: 'pending', comment: '状态' }),
    __metadata("design:type", String)
], OpDeveloper.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: ['trial', 'basic', 'professional', 'enterprise'], default: 'trial', comment: '开发者等级' }),
    __metadata("design:type", String)
], OpDeveloper.prototype, "level", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, comment: '已创建应用数' }),
    __metadata("design:type", Number)
], OpDeveloper.prototype, "appCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, comment: '累计API调用次数' }),
    __metadata("design:type", Number)
], OpDeveloper.prototype, "totalCallCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'datetime', nullable: true, comment: '最后登录时间' }),
    __metadata("design:type", Date)
], OpDeveloper.prototype, "lastLoginTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, nullable: true, comment: '最后登录IP' }),
    __metadata("design:type", String)
], OpDeveloper.prototype, "lastLoginIp", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'datetime', nullable: true, comment: '审核时间' }),
    __metadata("design:type", Date)
], OpDeveloper.prototype, "reviewTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, nullable: true, comment: '审核人' }),
    __metadata("design:type", String)
], OpDeveloper.prototype, "reviewBy", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true, comment: '审核备注' }),
    __metadata("design:type", String)
], OpDeveloper.prototype, "reviewRemark", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'datetime' }),
    __metadata("design:type", Date)
], OpDeveloper.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ type: 'datetime' }),
    __metadata("design:type", Date)
], OpDeveloper.prototype, "updateTime", void 0);
exports.OpDeveloper = OpDeveloper = __decorate([
    (0, typeorm_1.Entity)('op_developer')
], OpDeveloper);
//# sourceMappingURL=developer.entity.js.map
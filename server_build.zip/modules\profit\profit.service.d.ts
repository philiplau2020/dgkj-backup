/**
 * DGKJ 支付平台 - 分润计算服务
 *
 * 自动计算并执行交易分润
 */
export declare class ProfitService {
    private groupRepo;
    private receiverRepo;
    private recordRepo;
    private rollbackRepo;
    private orderRepo;
    private rateRepo;
    private agentRepo;
    private agentProfitRepo;
    private accountRepo;
    /**
     * 计算订单分润
     */
    calculateProfit(orderNo: string): Promise<any>;
    /**
     * 执行分润 (实际转账)
     */
    executeProfit(orderNo: string): Promise<any>;
    /**
     * 默认分润 (无配置时)
     */
    private defaultProfit;
    /**
     * 回滚分润
     */
    rollbackProfit(profitNo: string, reason: string): Promise<any>;
    /**
     * 获取分润记录列表
     */
    getProfitRecords(params: {
        page?: number;
        pageSize?: number;
        mchNo?: string;
        orderNo?: string;
        status?: number;
        startTime?: string;
        endTime?: string;
    }): Promise<any>;
    /**
     * 获取回滚记录列表
     */
    getRollbackRecords(params: {
        page?: number;
        pageSize?: number;
        mchNo?: string;
        orderNo?: string;
        status?: number;
    }): Promise<any>;
    /**
     * 创建分润分组
     */
    createAccountGroup(params: {
        groupName: string;
        mchNo: string;
        receivers: Array<{
            receiverName: string;
            receiverType: number;
            receiverAccount: string;
            profitRatio?: number;
            fixedAmount?: number;
            priority?: number;
        }>;
    }): Promise<any>;
    /**
     * 获取分润分组详情
     */
    getAccountGroup(mchNo: string): Promise<any>;
}
declare const _default: ProfitService;
export default _default;
//# sourceMappingURL=profit.service.d.ts.map
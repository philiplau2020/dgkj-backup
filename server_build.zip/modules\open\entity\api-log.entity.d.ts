export declare class OpApiLog {
    id: string;
    appId: string;
    developerId: string;
    mchNo: string;
    keyId: string;
    method: string;
    apiPath: string;
    bizNo: string;
    orderNo: string;
    result: 'success' | 'fail' | 'error' | 'pending';
    httpCode: number;
    code: string;
    message: string;
    responseTime: number;
    requestSize: number;
    responseSize: number;
    clientIp: string;
    userAgent: string;
    requestParams: string;
    responseContent: string;
    sign: string;
    securityLevel: 'low' | 'medium' | 'high';
    createTime: Date;
}
//# sourceMappingURL=api-log.entity.d.ts.map
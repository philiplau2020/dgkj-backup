export declare abstract class BaseEntity {
    id: string;
    createTime: Date;
    updateTime: Date;
    createBy: string;
    updateBy: string;
    remark: string;
}
export declare abstract class StatusEntity extends BaseEntity {
    status: number;
}
//# sourceMappingURL=base.entity.d.ts.map
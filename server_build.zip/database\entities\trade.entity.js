"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TradeNotify = exports.TransferOrder = exports.RefundOrder = exports.PayOrder = exports.PayType = exports.TradeType = exports.OrderStatus = void 0;
const typeorm_1 = require("typeorm");
var OrderStatus;
(function (OrderStatus) {
    OrderStatus[OrderStatus["PENDING"] = 0] = "PENDING";
    OrderStatus[OrderStatus["SUCCESS"] = 1] = "SUCCESS";
    OrderStatus[OrderStatus["FAILED"] = 2] = "FAILED";
    OrderStatus[OrderStatus["CLOSED"] = 3] = "CLOSED";
    OrderStatus[OrderStatus["REFUNDING"] = 4] = "REFUNDING";
    OrderStatus[OrderStatus["REFUNDED"] = 5] = "REFUNDED";
})(OrderStatus || (exports.OrderStatus = OrderStatus = {}));
var TradeType;
(function (TradeType) {
    TradeType[TradeType["PAY"] = 1] = "PAY";
    TradeType[TradeType["REFUND"] = 2] = "REFUND";
    TradeType[TradeType["TRANSFER"] = 3] = "TRANSFER";
    TradeType[TradeType["WITHDRAW"] = 4] = "WITHDRAW";
})(TradeType || (exports.TradeType = TradeType = {}));
var PayType;
(function (PayType) {
    PayType["WX_NATIVE"] = "WX_NATIVE";
    PayType["WX_APP"] = "WX_APP";
    PayType["WX_JSAPI"] = "WX_JSAPI";
    PayType["WX_H5"] = "WX_H5";
    PayType["ALI_QR"] = "ALI_QR";
    PayType["ALI_APP"] = "ALI_APP";
    PayType["ALI_WAP"] = "ALI_WAP";
    PayType["ALI_JSAPI"] = "ALI_JSAPI";
    PayType["UNION_QR"] = "UNION_QR";
    PayType["UNION_JK"] = "UNION_JK";
    PayType["YSF_QR"] = "YSF_QR";
    PayType["CASH"] = "CASH";
})(PayType || (exports.PayType = PayType = {}));
let PayOrder = class PayOrder {
};
exports.PayOrder = PayOrder;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], PayOrder.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'order_no', length: 32, unique: true }),
    __metadata("design:type", String)
], PayOrder.prototype, "orderNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_no', length: 32 }),
    __metadata("design:type", String)
], PayOrder.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_name', length: 128, nullable: true }),
    __metadata("design:type", String)
], PayOrder.prototype, "mchName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'app_id', length: 32 }),
    __metadata("design:type", String)
], PayOrder.prototype, "appId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_code', length: 32, nullable: true }),
    __metadata("design:type", String)
], PayOrder.prototype, "channelCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'pay_type', length: 32 }),
    __metadata("design:type", String)
], PayOrder.prototype, "payType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'trade_type', type: 'tinyint', default: TradeType.PAY }),
    __metadata("design:type", Number)
], PayOrder.prototype, "tradeType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], PayOrder.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'coupon_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], PayOrder.prototype, "couponAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'actual_amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], PayOrder.prototype, "actualAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fee', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], PayOrder.prototype, "fee", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'profit_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], PayOrder.prototype, "profitAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'subject', length: 128, nullable: true }),
    __metadata("design:type", String)
], PayOrder.prototype, "subject", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'body', length: 255, nullable: true }),
    __metadata("design:type", String)
], PayOrder.prototype, "body", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_order_no', length: 64, nullable: true }),
    __metadata("design:type", String)
], PayOrder.prototype, "channelOrderNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'pay_url', type: 'text', nullable: true }),
    __metadata("design:type", String)
], PayOrder.prototype, "payUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'pay_time', nullable: true }),
    __metadata("design:type", Date)
], PayOrder.prototype, "payTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'expire_time', nullable: true }),
    __metadata("design:type", Date)
], PayOrder.prototype, "expireTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: OrderStatus.PENDING }),
    __metadata("design:type", Number)
], PayOrder.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'notify_status', type: 'tinyint', default: 0 }),
    __metadata("design:type", Number)
], PayOrder.prototype, "notifyStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'notify_time', nullable: true }),
    __metadata("design:type", Date)
], PayOrder.prototype, "notifyTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'notify_url', length: 255, nullable: true }),
    __metadata("design:type", String)
], PayOrder.prototype, "notifyUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'client_ip', length: 64, nullable: true }),
    __metadata("design:type", String)
], PayOrder.prototype, "clientIp", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'attach', type: 'text', nullable: true }),
    __metadata("design:type", String)
], PayOrder.prototype, "attach", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], PayOrder.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], PayOrder.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], PayOrder.prototype, "updateTime", void 0);
exports.PayOrder = PayOrder = __decorate([
    (0, typeorm_1.Entity)('pay_order')
], PayOrder);
let RefundOrder = class RefundOrder {
};
exports.RefundOrder = RefundOrder;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], RefundOrder.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'refund_no', length: 32, unique: true }),
    __metadata("design:type", String)
], RefundOrder.prototype, "refundNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'order_no', length: 32 }),
    __metadata("design:type", String)
], RefundOrder.prototype, "orderNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_no', length: 32 }),
    __metadata("design:type", String)
], RefundOrder.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'app_id', length: 32 }),
    __metadata("design:type", String)
], RefundOrder.prototype, "appId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_code', length: 32, nullable: true }),
    __metadata("design:type", String)
], RefundOrder.prototype, "channelCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'pay_type', length: 32 }),
    __metadata("design:type", String)
], RefundOrder.prototype, "payType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], RefundOrder.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'refund_amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], RefundOrder.prototype, "refundAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'refund_reason', length: 255, nullable: true }),
    __metadata("design:type", String)
], RefundOrder.prototype, "refundReason", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_refund_no', length: 64, nullable: true }),
    __metadata("design:type", String)
], RefundOrder.prototype, "channelRefundNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'refund_time', nullable: true }),
    __metadata("design:type", Date)
], RefundOrder.prototype, "refundTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 0 }),
    __metadata("design:type", Number)
], RefundOrder.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], RefundOrder.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], RefundOrder.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], RefundOrder.prototype, "updateTime", void 0);
exports.RefundOrder = RefundOrder = __decorate([
    (0, typeorm_1.Entity)('refund_order')
], RefundOrder);
let TransferOrder = class TransferOrder {
};
exports.TransferOrder = TransferOrder;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], TransferOrder.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'transfer_no', length: 32, unique: true }),
    __metadata("design:type", String)
], TransferOrder.prototype, "transferNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_no', length: 32 }),
    __metadata("design:type", String)
], TransferOrder.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'app_id', length: 32 }),
    __metadata("design:type", String)
], TransferOrder.prototype, "appId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'out_no', length: 64, nullable: true }),
    __metadata("design:type", String)
], TransferOrder.prototype, "outNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], TransferOrder.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fee', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], TransferOrder.prototype, "fee", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'actual_amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], TransferOrder.prototype, "actualAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'pay_type', length: 32 }),
    __metadata("design:type", String)
], TransferOrder.prototype, "payType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_type', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], TransferOrder.prototype, "accountType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_name', length: 64 }),
    __metadata("design:type", String)
], TransferOrder.prototype, "accountName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'account_no', length: 32 }),
    __metadata("design:type", String)
], TransferOrder.prototype, "accountNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_name', length: 64, nullable: true }),
    __metadata("design:type", String)
], TransferOrder.prototype, "bankName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_code', length: 32, nullable: true }),
    __metadata("design:type", String)
], TransferOrder.prototype, "bankCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 0 }),
    __metadata("design:type", Number)
], TransferOrder.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_transfer_no', length: 64, nullable: true }),
    __metadata("design:type", String)
], TransferOrder.prototype, "channelTransferNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'complete_time', nullable: true }),
    __metadata("design:type", Date)
], TransferOrder.prototype, "completeTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], TransferOrder.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], TransferOrder.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], TransferOrder.prototype, "updateTime", void 0);
exports.TransferOrder = TransferOrder = __decorate([
    (0, typeorm_1.Entity)('transfer_order')
], TransferOrder);
let TradeNotify = class TradeNotify {
};
exports.TradeNotify = TradeNotify;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], TradeNotify.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'notify_id', length: 64 }),
    __metadata("design:type", String)
], TradeNotify.prototype, "notifyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'order_no', length: 32 }),
    __metadata("design:type", String)
], TradeNotify.prototype, "orderNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_no', length: 32 }),
    __metadata("design:type", String)
], TradeNotify.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'app_id', length: 32 }),
    __metadata("design:type", String)
], TradeNotify.prototype, "appId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'notify_url', length: 255 }),
    __metadata("design:type", String)
], TradeNotify.prototype, "notifyUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'notify_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], TradeNotify.prototype, "notifyType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 0 }),
    __metadata("design:type", Number)
], TradeNotify.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'notify_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], TradeNotify.prototype, "notifyCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'last_notify_time', nullable: true }),
    __metadata("design:type", Date)
], TradeNotify.prototype, "lastNotifyTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'next_notify_time', nullable: true }),
    __metadata("design:type", Date)
], TradeNotify.prototype, "nextNotifyTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'response_result', type: 'text', nullable: true }),
    __metadata("design:type", String)
], TradeNotify.prototype, "responseResult", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], TradeNotify.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], TradeNotify.prototype, "updateTime", void 0);
exports.TradeNotify = TradeNotify = __decorate([
    (0, typeorm_1.Entity)('trade_notify')
], TradeNotify);
//# sourceMappingURL=trade.entity.js.map
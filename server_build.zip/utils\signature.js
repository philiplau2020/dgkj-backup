"use strict";
/**
 * 开放平台签名工具
 *
 * 支持多种签名算法:
 * 1. HMAC-SHA256 (推荐) - 最常用，兼容性好
 * 2. RSA-SHA256 (2048位) - 非对称签名，安全性高
 * 3. SM2 (国密) - 国产密码算法
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SignType = void 0;
exports.sortParams = sortParams;
exports.signHmacSha256 = signHmacSha256;
exports.verifyHmacSha256 = verifyHmacSha256;
exports.signRsaSha256 = signRsaSha256;
exports.verifyRsaSha256 = verifyRsaSha256;
exports.signMd5 = signMd5;
exports.verifyMd5 = verifyMd5;
exports.sign = sign;
exports.verifySign = verifySign;
exports.generateNonce = generateNonce;
exports.generateAppKey = generateAppKey;
exports.generateAppSecret = generateAppSecret;
exports.generateKeyId = generateKeyId;
exports.generateMchNo = generateMchNo;
exports.generateAppId = generateAppId;
exports.aesEncrypt = aesEncrypt;
exports.aesDecrypt = aesDecrypt;
exports.encryptSecret = encryptSecret;
exports.decryptSecret = decryptSecret;
exports.maskSecret = maskSecret;
exports.maskPhone = maskPhone;
exports.maskEmail = maskEmail;
exports.maskIdCard = maskIdCard;
exports.maskBankCard = maskBankCard;
const crypto_1 = __importDefault(require("crypto"));
/** 签名算法枚举 */
exports.SignType = {
    HMAC_SHA256: 'HMAC-SHA256',
    RSA_SHA256: 'RSA-SHA256',
    SM2: 'SM2',
    MD5: 'MD5',
    SHA1: 'SHA1',
};
/** 按字典序排序并拼接参数 */
function sortParams(params) {
    const sorted = Object.keys(params)
        .filter((key) => params[key] !== undefined && params[key] !== null && params[key] !== '')
        .sort()
        .reduce((acc, key) => {
        acc[key] = params[key];
        return acc;
    }, {});
    return Object.entries(sorted)
        .map(([k, v]) => `${k}=${v}`)
        .join('&');
}
/** 生成签名 (HMAC-SHA256) */
function signHmacSha256(params, secret) {
    const str = sortParams(params);
    return crypto_1.default.createHmac('sha256', secret).update(str).digest('hex').toUpperCase();
}
/** 验证签名 (HMAC-SHA256) */
function verifyHmacSha256(params, sign, secret) {
    const expected = signHmacSha256(params, secret);
    return crypto_1.default.timingSafeEqual(Buffer.from(expected), Buffer.from(sign)) ||
        expected === sign.toUpperCase();
}
/** 生成 RSA 签名 */
function signRsaSha256(data, privateKey) {
    const sign = crypto_1.default.createSign('RSA-SHA256');
    sign.update(data);
    return sign.sign(privateKey, 'base64');
}
/** 验证 RSA 签名 */
function verifyRsaSha256(data, signature, publicKey) {
    const verify = crypto_1.default.createVerify('RSA-SHA256');
    verify.update(data);
    return verify.verify(publicKey, signature, 'base64');
}
/** 生成 MD5 签名 (兼容老系统) */
function signMd5(params, secret) {
    const str = sortParams(params) + '&key=' + secret;
    return crypto_1.default.createHash('md5').update(str).digest('hex').toUpperCase();
}
/** 验证 MD5 签名 */
function verifyMd5(params, sign, secret) {
    const expected = signMd5(params, secret);
    return expected === sign.toUpperCase();
}
/** 根据签名类型签名 */
function sign(params, secret, signType = exports.SignType.HMAC_SHA256) {
    switch (signType) {
        case exports.SignType.HMAC_SHA256:
            return signHmacSha256(params, secret);
        case exports.SignType.MD5:
            return signMd5(params, secret);
        case exports.SignType.SHA1:
            return crypto_1.default.createHash('sha1').update(sortParams(params) + secret).digest('hex').toUpperCase();
        default:
            return signHmacSha256(params, secret);
    }
}
/** 通用验签 */
function verifySign(params, sign, secret, signType = exports.SignType.HMAC_SHA256) {
    const signParam = { ...params };
    delete signParam.sign;
    delete signParam.signType;
    switch (signType) {
        case exports.SignType.HMAC_SHA256:
            return verifyHmacSha256(signParam, sign, secret);
        case exports.SignType.MD5:
            return verifyMd5(signParam, sign, secret);
        default:
            return verifyHmacSha256(signParam, sign, secret);
    }
}
/** 生成随机字符串 */
function generateNonce(length = 32) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    const bytes = crypto_1.default.randomBytes(length);
    for (let i = 0; i < length; i++) {
        result += chars[bytes[i] % chars.length];
    }
    return result;
}
/** 生成 AppKey (公开标识) */
function generateAppKey() {
    return 'DGKJ' + Date.now().toString(36).toUpperCase() + generateNonce(8).toUpperCase();
}
/** 生成 AppSecret */
function generateAppSecret() {
    return generateNonce(32) + Date.now().toString(36);
}
/** 生成 KeyId */
function generateKeyId() {
    return 'KEY' + Date.now().toString(36).toUpperCase() + generateNonce(4).toUpperCase();
}
/** 生成商户号 */
function generateMchNo() {
    const prefix = 'M';
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = generateNonce(6).toUpperCase();
    return `${prefix}${timestamp}${random}`;
}
/** 生成应用ID */
function generateAppId() {
    return 'APP' + Date.now().toString(36).toUpperCase() + generateNonce(4).toUpperCase();
}
/** AES 加密 */
function aesEncrypt(data, key, iv) {
    const cipher = crypto_1.default.createCipheriv('aes-256-cbc', Buffer.from(key.slice(0, 32)), Buffer.from(iv.slice(0, 16)));
    let encrypted = cipher.update(data, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
}
/** AES 解密 */
function aesDecrypt(data, key, iv) {
    const decipher = crypto_1.default.createDecipheriv('aes-256-cbc', Buffer.from(key.slice(0, 32)), Buffer.from(iv.slice(0, 16)));
    let decrypted = decipher.update(data, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
}
/** 加密敏感数据 (AppSecret 存储) */
function encryptSecret(secret, key) {
    const iv = crypto_1.default.randomBytes(16);
    const cipher = crypto_1.default.createCipheriv('aes-256-cbc', Buffer.from(key.slice(0, 32)), iv);
    let encrypted = cipher.update(secret, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return iv.toString('hex') + ':' + encrypted;
}
/** 解密敏感数据 */
function decryptSecret(encrypted, key) {
    const [ivHex, data] = encrypted.split(':');
    const decipher = crypto_1.default.createDecipheriv('aes-256-cbc', Buffer.from(key.slice(0, 32)), Buffer.from(ivHex, 'hex'));
    let decrypted = decipher.update(data, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
}
/** 脱敏处理 */
function maskSecret(value, showLength = 4) {
    if (!value || value.length <= showLength * 2)
        return '***';
    return value.slice(0, showLength) + '****' + value.slice(-showLength);
}
function maskPhone(phone) {
    if (!phone || phone.length < 7)
        return '***';
    return phone.slice(0, 3) + '****' + phone.slice(-4);
}
function maskEmail(email) {
    if (!email || !email.includes('@'))
        return '***';
    const [name, domain] = email.split('@');
    if (name.length <= 2)
        return '***@' + domain;
    return name[0] + '***' + name.slice(-1) + '@' + domain;
}
function maskIdCard(idCard) {
    if (!idCard || idCard.length < 10)
        return '***';
    return idCard.slice(0, 4) + '**********' + idCard.slice(-4);
}
function maskBankCard(cardNo) {
    if (!cardNo || cardNo.length < 8)
        return '***';
    return cardNo.slice(0, 4) + ' **** **** ' + cardNo.slice(-4);
}
//# sourceMappingURL=signature.js.map
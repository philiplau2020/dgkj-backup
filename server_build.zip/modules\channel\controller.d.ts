import { Request, Response, NextFunction } from 'express';
export declare class ChannelController {
    private channelRepo;
    private channelMchRepo;
    private channelRouteRepo;
    private strategyRepo;
    private poolChannelRepo;
    private poolConfigRepo;
    getChannelList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getChannelById(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    createChannel(req: Request, res: Response, next: NextFunction): Promise<void>;
    updateChannel(req: Request, res: Response, next: NextFunction): Promise<void>;
    getChannelMchList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createChannelMch(req: Request, res: Response, next: NextFunction): Promise<void>;
    updateChannelMch(req: Request, res: Response, next: NextFunction): Promise<void>;
    deleteChannelMch(req: Request, res: Response, next: NextFunction): Promise<void>;
    getRouteList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createRoute(req: Request, res: Response, next: NextFunction): Promise<void>;
    updateRoute(req: Request, res: Response, next: NextFunction): Promise<void>;
    getChannelRouteList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createChannelRoute(req: Request, res: Response, next: NextFunction): Promise<void>;
    updateChannelRoute(req: Request, res: Response, next: NextFunction): Promise<void>;
    getPoolList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createPool(req: Request, res: Response, next: NextFunction): Promise<void>;
    getStrategyList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createStrategy(req: Request, res: Response, next: NextFunction): Promise<void>;
    updateStrategy(req: Request, res: Response, next: NextFunction): Promise<void>;
    getRecommendedChannel(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    getChannelStats(req: Request, res: Response, next: NextFunction): Promise<void>;
}
declare const _default: ChannelController;
export default _default;
//# sourceMappingURL=controller.d.ts.map
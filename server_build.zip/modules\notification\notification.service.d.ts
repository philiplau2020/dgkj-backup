/**
 * DGKJ 支付平台 - 统一通知服务
 *
 * 支持: 邮件、短信、钉钉、企业微信
 */
interface NotificationResult {
    success: boolean;
    messageId?: string;
    errorCode?: string;
    errorMsg?: string;
}
/**
 * 初始化所有通知配置
 */
export declare function initializeNotificationConfig(): Promise<void>;
/**
 * 发送邮件
 */
export declare function sendEmail(options: {
    to: string | string[];
    subject: string;
    html: string;
    text?: string;
    attachments?: any[];
}): Promise<NotificationResult>;
/**
 * 发送验证码邮件
 */
export declare function sendVerificationEmail(to: string, code: string, expireMinutes?: number): Promise<NotificationResult>;
/**
 * 发送密码重置邮件
 */
export declare function sendResetPasswordEmail(to: string, resetLink: string, expireHours?: number): Promise<NotificationResult>;
/**
 * 发送商户审核通知
 */
export declare function sendMerchantAuditEmail(to: string, merchantName: string, status: 'approved' | 'rejected', reason?: string): Promise<NotificationResult>;
/**
 * 发送交易通知
 */
export declare function sendTradeNotificationEmail(to: string, data: {
    orderNo: string;
    amount: number;
    status: string;
    paidTime?: string;
    payWay: string;
}): Promise<NotificationResult>;
/**
 * 发送结算到账通知
 */
export declare function sendSettlementEmail(to: string, data: {
    settleNo: string;
    amount: number;
    fee: number;
    actualAmount: number;
    arriveTime?: string;
}): Promise<NotificationResult>;
/**
 * 发送短信验证码
 */
export declare function sendVerificationCode(phone: string, code: string, expireMinutes?: number): Promise<NotificationResult>;
/**
 * 发送短信通知
 */
export declare function sendSmsNotification(phone: string, template: string, params: Record<string, string>): Promise<NotificationResult>;
/**
 * 发送钉钉消息
 */
export declare function sendDingTalkMessage(options: {
    msgtype: 'text' | 'markdown' | 'link' | 'actionCard';
    content: {
        text?: string;
        title?: string;
        messageUrl?: string;
        picUrl?: string;
        btns?: Array<{
            title: string;
            actionURL: string;
        }>;
        btnOrientation?: string;
    };
    atMobiles?: string[];
}): Promise<NotificationResult>;
/**
 * 发送钉钉文本消息
 */
export declare function sendDingTalkText(text: string, atMobiles?: string[]): Promise<NotificationResult>;
/**
 * 发送钉钉 Markdown 消息
 */
export declare function sendDingTalkMarkdown(title: string, text: string): Promise<NotificationResult>;
/**
 * 发送钉钉告警通知
 */
export declare function sendDingTalkAlert(data: {
    level: 'info' | 'warning' | 'error' | 'critical';
    title: string;
    content: string;
    timestamp: string;
}): Promise<NotificationResult>;
/**
 * 发送企业微信消息
 */
export declare function sendWeComMessage(options: {
    msgtype: 'text' | 'markdown' | 'image' | 'news' | 'template_card';
    content: any;
    toUser?: string;
    toParty?: string;
    toTag?: string;
}): Promise<NotificationResult>;
/**
 * 发送企业微信文本消息
 */
export declare function sendWeComText(text: string, toUser?: string): Promise<NotificationResult>;
/**
 * 发送企业微信 Markdown 消息
 */
export declare function sendWeComMarkdown(content: string, toUser?: string): Promise<NotificationResult>;
/**
 * 发送企业微信告警通知
 */
export declare function sendWeComAlert(data: {
    level: 'info' | 'warning' | 'error' | 'critical';
    title: string;
    content: string;
    timestamp: string;
}): Promise<NotificationResult>;
/**
 * 发送告警通知 (同时发送到所有配置的渠道)
 */
export declare function sendAlertNotification(data: {
    level: 'info' | 'warning' | 'error' | 'critical';
    title: string;
    content: string;
    timestamp: string;
    channels?: ('email' | 'sms' | 'dingtalk' | 'wecom')[];
    targets?: {
        emails?: string[];
        phones?: string[];
        dingtalkAtMobiles?: string[];
    };
}): Promise<{
    email?: NotificationResult;
    sms?: NotificationResult;
    dingtalk?: NotificationResult;
    wecom?: NotificationResult;
}>;
/**
 * 测试邮件服务
 */
export declare function testEmail(to: string): Promise<NotificationResult>;
/**
 * 测试短信服务
 */
export declare function testSms(phone: string): Promise<NotificationResult>;
/**
 * 测试钉钉服务
 */
export declare function testDingTalk(): Promise<NotificationResult>;
/**
 * 测试企业微信服务
 */
export declare function testWeCom(): Promise<NotificationResult>;
declare const _default: {
    initializeNotificationConfig: typeof initializeNotificationConfig;
    sendEmail: typeof sendEmail;
    sendVerificationEmail: typeof sendVerificationEmail;
    sendResetPasswordEmail: typeof sendResetPasswordEmail;
    sendMerchantAuditEmail: typeof sendMerchantAuditEmail;
    sendTradeNotificationEmail: typeof sendTradeNotificationEmail;
    sendSettlementEmail: typeof sendSettlementEmail;
    testEmail: typeof testEmail;
    sendVerificationCode: typeof sendVerificationCode;
    sendSmsNotification: typeof sendSmsNotification;
    testSms: typeof testSms;
    sendDingTalkMessage: typeof sendDingTalkMessage;
    sendDingTalkText: typeof sendDingTalkText;
    sendDingTalkMarkdown: typeof sendDingTalkMarkdown;
    sendDingTalkAlert: typeof sendDingTalkAlert;
    testDingTalk: typeof testDingTalk;
    sendWeComMessage: typeof sendWeComMessage;
    sendWeComText: typeof sendWeComText;
    sendWeComMarkdown: typeof sendWeComMarkdown;
    sendWeComAlert: typeof sendWeComAlert;
    testWeCom: typeof testWeCom;
    sendAlertNotification: typeof sendAlertNotification;
};
export default _default;
//# sourceMappingURL=notification.service.d.ts.map
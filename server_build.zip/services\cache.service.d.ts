/**
 * DGKJ 支付平台 - Redis 缓存服务
 *
 * 提供统一的缓存接口，支持本地缓存和 Redis 缓存
 */
interface CacheConfig {
    type: 'memory' | 'redis';
    redis?: {
        host: string;
        port: number;
        password?: string;
        db?: number;
        keyPrefix?: string;
    };
    memory?: {
        maxSize?: number;
        ttl?: number;
    };
}
interface CacheOptions {
    ttl?: number;
    prefix?: string;
}
declare class CacheService {
    private memoryCache;
    private redisCache;
    private useRedis;
    constructor();
    /**
     * 初始化缓存服务
     */
    initialize(config?: CacheConfig): Promise<void>;
    /**
     * 获取缓存
     */
    get<T>(key: string): Promise<T | null>;
    /**
     * 设置缓存
     */
    set(key: string, value: any, options?: CacheOptions): Promise<void>;
    /**
     * 删除缓存
     */
    del(key: string): Promise<void>;
    /**
     * 删除匹配模式的缓存
     */
    delPattern(pattern: string): Promise<void>;
    /**
     * 清空所有缓存
     */
    clear(): Promise<void>;
    /**
     * 检查缓存是否存在
     */
    exists(key: string): Promise<boolean>;
    /**
     * 获取缓存剩余 TTL
     */
    ttl(key: string): Promise<number>;
    /**
     * 获取或设置缓存（如果不存在则设置）
     */
    getOrSet<T>(key: string, factory: () => Promise<T>, options?: CacheOptions): Promise<T>;
    /**
     * 批量获取缓存
     */
    mget<T>(keys: string[]): Promise<(T | null)[]>;
    /**
     * 批量设置缓存
     */
    mset(items: Array<{
        key: string;
        value: any;
        options?: CacheOptions;
    }>): Promise<void>;
}
export declare class TokenCache {
    private cache;
    constructor(cache: CacheService);
    getToken(key: string): Promise<string | null>;
    setToken(key: string, token: string, ttl?: number): Promise<void>;
    delToken(key: string): Promise<void>;
}
export declare class RateLimitCache {
    private cache;
    constructor(cache: CacheService);
    checkLimit(key: string, maxRequests: number, windowSeconds: number): Promise<{
        allowed: boolean;
        remaining: number;
        resetTime: number;
    }>;
}
export declare class SessionCache {
    private cache;
    constructor(cache: CacheService);
    getSession<T>(sessionId: string): Promise<T | null>;
    setSession(sessionId: string, data: any, ttl?: number): Promise<void>;
    delSession(sessionId: string): Promise<void>;
    refreshSession(sessionId: string, ttl?: number): Promise<void>;
}
export declare const cacheService: CacheService;
export declare const tokenCache: TokenCache;
export declare const rateLimitCache: RateLimitCache;
export declare const sessionCache: SessionCache;
export default cacheService;
//# sourceMappingURL=cache.service.d.ts.map
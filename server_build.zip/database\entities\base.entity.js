"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusEntity = exports.BaseEntity = void 0;
const typeorm_1 = require("typeorm");
class BaseEntity {
}
exports.BaseEntity = BaseEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], BaseEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'create_time' }),
    __metadata("design:type", Date)
], BaseEntity.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'update_time' }),
    __metadata("design:type", Date)
], BaseEntity.prototype, "updateTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_by', nullable: true }),
    __metadata("design:type", String)
], BaseEntity.prototype, "createBy", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_by', nullable: true }),
    __metadata("design:type", String)
], BaseEntity.prototype, "updateBy", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', nullable: true }),
    __metadata("design:type", String)
], BaseEntity.prototype, "remark", void 0);
class StatusEntity extends BaseEntity {
}
exports.StatusEntity = StatusEntity;
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], StatusEntity.prototype, "status", void 0);
//# sourceMappingURL=base.entity.js.map
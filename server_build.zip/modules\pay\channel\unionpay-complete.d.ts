/**
 * DGKJ 支付平台 - 银联支付通道完整实现
 *
 * 支持: 银联二维码、APP支付、网关支付、控件支付
 */
import { IPaymentChannel, ChannelConfig, UnifiedPayRequest, UnifiedPayResponse, UnifiedQueryRequest, UnifiedQueryResponse, UnifiedRefundRequest, UnifiedRefundResponse, UnifiedTransferRequest, UnifiedTransferResponse, UnifiedCallbackData, PayWay, ChannelCode } from './interface';
export declare class UnionPayChannel implements IPaymentChannel {
    readonly channelCode = ChannelCode.UNIONPAY;
    readonly channelName = "\u94F6\u8054\u652F\u4ED8";
    readonly supportedPayWays: PayWay[];
    private config;
    private certPath;
    private privateKey;
    private publicKey;
    private getBaseUrl;
    initialize(config: ChannelConfig): void;
    private loadCertificates;
    /**
     * 执行支付
     */
    pay(request: UnifiedPayRequest): Promise<UnifiedPayResponse>;
    private buildPaySuccessResponse;
    private buildAppPayParams;
    private buildSdkPayParams;
    private buildPayFailResponse;
    /**
     * 查询订单
     */
    query(request: UnifiedQueryRequest): Promise<UnifiedQueryResponse>;
    private mapQueryStatus;
    /**
     * 申请退款
     */
    refund(request: UnifiedRefundRequest): Promise<UnifiedRefundResponse>;
    /**
     * 转账 (银联云闪付不支持，代理到其他通道)
     */
    transfer(request: UnifiedTransferRequest): Promise<UnifiedTransferResponse>;
    /**
     * 验证回调签名
     */
    verifyCallback(data: any, headers: any): Promise<{
        success: boolean;
        errorMsg?: string;
    }>;
    /**
     * 解析回调数据
     */
    parseCallback(data: any): Promise<UnifiedCallbackData>;
    private mapCallbackStatus;
    responseCallbackSuccess(): string;
    responseCallbackFail(): string;
    private buildPayParams;
    private getBizType;
    private getTxnSubType;
    private addPayWayParams;
    private buildQueryParams;
    private buildRefundParams;
    private request;
    private buildFormData;
    private parseResponse;
    private parseXmlResponse;
    private getSignString;
    private sign;
    private signWithPrivateKey;
    private verifySign;
    private formatTime;
}
declare const _default: UnionPayChannel;
export default _default;
//# sourceMappingURL=unionpay-complete.d.ts.map
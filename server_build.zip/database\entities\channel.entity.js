"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PoolConfig = exports.PoolChannel = exports.PoolStrategy = exports.ChannelRoute = exports.ChannelMch = exports.ChannelInfo = exports.ChannelStatus = void 0;
const typeorm_1 = require("typeorm");
var ChannelStatus;
(function (ChannelStatus) {
    ChannelStatus[ChannelStatus["DISABLED"] = 0] = "DISABLED";
    ChannelStatus[ChannelStatus["ENABLED"] = 1] = "ENABLED";
})(ChannelStatus || (exports.ChannelStatus = ChannelStatus = {}));
let ChannelInfo = class ChannelInfo {
};
exports.ChannelInfo = ChannelInfo;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], ChannelInfo.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_code', length: 32, unique: true }),
    __metadata("design:type", String)
], ChannelInfo.prototype, "channelCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_name', length: 128 }),
    __metadata("design:type", String)
], ChannelInfo.prototype, "channelName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_short_name', length: 64, nullable: true }),
    __metadata("design:type", String)
], ChannelInfo.prototype, "channelShortName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_type', length: 32 }),
    __metadata("design:type", String)
], ChannelInfo.prototype, "channelType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'provider', length: 64, nullable: true }),
    __metadata("design:type", String)
], ChannelInfo.prototype, "provider", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'app_id', length: 128, nullable: true }),
    __metadata("design:type", String)
], ChannelInfo.prototype, "appId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'app_secret', length: 255, nullable: true }),
    __metadata("design:type", String)
], ChannelInfo.prototype, "appSecret", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_id', length: 64, nullable: true }),
    __metadata("design:type", String)
], ChannelInfo.prototype, "mchId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'api_key', length: 255, nullable: true }),
    __metadata("design:type", String)
], ChannelInfo.prototype, "apiKey", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'public_key', type: 'text', nullable: true }),
    __metadata("design:type", String)
], ChannelInfo.prototype, "publicKey", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'private_key', type: 'text', nullable: true }),
    __metadata("design:type", String)
], ChannelInfo.prototype, "privateKey", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'pay_url', length: 255, nullable: true }),
    __metadata("design:type", String)
], ChannelInfo.prototype, "payUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'notify_url', length: 255, nullable: true }),
    __metadata("design:type", String)
], ChannelInfo.prototype, "notifyUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'query_url', length: 255, nullable: true }),
    __metadata("design:type", String)
], ChannelInfo.prototype, "queryUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'settle_url', length: 255, nullable: true }),
    __metadata("design:type", String)
], ChannelInfo.prototype, "settleUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'logo', length: 255, nullable: true }),
    __metadata("design:type", String)
], ChannelInfo.prototype, "logo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'config', type: 'json', nullable: true }),
    __metadata("design:type", Object)
], ChannelInfo.prototype, "config", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: ChannelStatus.ENABLED }),
    __metadata("design:type", Number)
], ChannelInfo.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], ChannelInfo.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], ChannelInfo.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], ChannelInfo.prototype, "updateTime", void 0);
exports.ChannelInfo = ChannelInfo = __decorate([
    (0, typeorm_1.Entity)('channel_info')
], ChannelInfo);
let ChannelMch = class ChannelMch {
};
exports.ChannelMch = ChannelMch;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], ChannelMch.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_code', length: 32 }),
    __metadata("design:type", String)
], ChannelMch.prototype, "channelCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_mch_id', length: 64 }),
    __metadata("design:type", String)
], ChannelMch.prototype, "channelMchId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_no', length: 32 }),
    __metadata("design:type", String)
], ChannelMch.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_name', length: 128 }),
    __metadata("design:type", String)
], ChannelMch.prototype, "mchName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'app_id', length: 128, nullable: true }),
    __metadata("design:type", String)
], ChannelMch.prototype, "appId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'app_secret', length: 255, nullable: true }),
    __metadata("design:type", String)
], ChannelMch.prototype, "appSecret", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], ChannelMch.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], ChannelMch.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], ChannelMch.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], ChannelMch.prototype, "updateTime", void 0);
exports.ChannelMch = ChannelMch = __decorate([
    (0, typeorm_1.Entity)('channel_mch')
], ChannelMch);
let ChannelRoute = class ChannelRoute {
};
exports.ChannelRoute = ChannelRoute;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], ChannelRoute.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'route_name', length: 64 }),
    __metadata("design:type", String)
], ChannelRoute.prototype, "routeName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'route_code', length: 32, unique: true }),
    __metadata("design:type", String)
], ChannelRoute.prototype, "routeCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'pay_type', length: 32 }),
    __metadata("design:type", String)
], ChannelRoute.prototype, "payType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'priority', type: 'int', default: 1 }),
    __metadata("design:type", Number)
], ChannelRoute.prototype, "priority", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_codes', type: 'text' }),
    __metadata("design:type", String)
], ChannelRoute.prototype, "channelCodes", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'route_type', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], ChannelRoute.prototype, "routeType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'route_rule', type: 'json', nullable: true }),
    __metadata("design:type", Object)
], ChannelRoute.prototype, "routeRule", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], ChannelRoute.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], ChannelRoute.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], ChannelRoute.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], ChannelRoute.prototype, "updateTime", void 0);
exports.ChannelRoute = ChannelRoute = __decorate([
    (0, typeorm_1.Entity)('channel_route')
], ChannelRoute);
let PoolStrategy = class PoolStrategy {
};
exports.PoolStrategy = PoolStrategy;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], PoolStrategy.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'strategy_name', length: 64 }),
    __metadata("design:type", String)
], PoolStrategy.prototype, "strategyName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'strategy_code', length: 32, unique: true }),
    __metadata("design:type", String)
], PoolStrategy.prototype, "strategyCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'strategy_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], PoolStrategy.prototype, "strategyType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_code', length: 32, nullable: true }),
    __metadata("design:type", String)
], PoolStrategy.prototype, "channelCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'weight', type: 'int', default: 100 }),
    __metadata("design:type", Number)
], PoolStrategy.prototype, "weight", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'max_amount', type: 'decimal', precision: 18, scale: 2, nullable: true }),
    __metadata("design:type", Number)
], PoolStrategy.prototype, "maxAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'min_amount', type: 'decimal', precision: 18, scale: 2, nullable: true }),
    __metadata("design:type", Number)
], PoolStrategy.prototype, "minAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'time_range', type: 'json', nullable: true }),
    __metadata("design:type", Object)
], PoolStrategy.prototype, "timeRange", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'week_days', type: 'json', nullable: true }),
    __metadata("design:type", Object)
], PoolStrategy.prototype, "weekDays", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], PoolStrategy.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], PoolStrategy.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], PoolStrategy.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], PoolStrategy.prototype, "updateTime", void 0);
exports.PoolStrategy = PoolStrategy = __decorate([
    (0, typeorm_1.Entity)('pool_strategy')
], PoolStrategy);
let PoolChannel = class PoolChannel {
};
exports.PoolChannel = PoolChannel;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], PoolChannel.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'pool_id', length: 64 }),
    __metadata("design:type", String)
], PoolChannel.prototype, "poolId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_code', length: 32 }),
    __metadata("design:type", String)
], PoolChannel.prototype, "channelCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'weight', type: 'int', default: 100 }),
    __metadata("design:type", Number)
], PoolChannel.prototype, "weight", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], PoolChannel.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], PoolChannel.prototype, "createTime", void 0);
exports.PoolChannel = PoolChannel = __decorate([
    (0, typeorm_1.Entity)('pool_channel')
], PoolChannel);
let PoolConfig = class PoolConfig {
};
exports.PoolConfig = PoolConfig;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], PoolConfig.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'pool_name', length: 64 }),
    __metadata("design:type", String)
], PoolConfig.prototype, "poolName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'pool_code', length: 32, unique: true }),
    __metadata("design:type", String)
], PoolConfig.prototype, "poolCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'pool_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], PoolConfig.prototype, "poolType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'description', length: 255, nullable: true }),
    __metadata("design:type", String)
], PoolConfig.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], PoolConfig.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], PoolConfig.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], PoolConfig.prototype, "updateTime", void 0);
exports.PoolConfig = PoolConfig = __decorate([
    (0, typeorm_1.Entity)('pool_config')
], PoolConfig);
//# sourceMappingURL=channel.entity.js.map
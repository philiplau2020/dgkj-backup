/**
 * DGKJ 支付平台 - 短信通知服务
 *
 * 支持阿里云短信、腾讯云短信等主流短信服务商
 */
interface SmsResult {
    success: boolean;
    messageId?: string;
    errorCode?: string;
    errorMsg?: string;
}
/**
 * 初始化短信配置
 */
export declare function initializeSmsConfig(): Promise<void>;
/**
 * 发送短信验证码
 */
export declare function sendVerificationCode(phone: string, code: string, expireMinutes?: number): Promise<SmsResult>;
/**
 * 发送通知短信
 */
export declare function sendNotification(phone: string, template: string, params: Record<string, string>): Promise<SmsResult>;
/**
 * 发送营销短信
 */
export declare function sendMarketing(phone: string, template: string, params: Record<string, string>): Promise<SmsResult>;
/**
 * 批量发送短信
 */
export declare function sendBatchSms(phones: string[], template: string, params: Record<string, string>): Promise<SmsResult[]>;
/**
 * 验证手机号格式
 */
export declare function validatePhone(phone: string): boolean;
/**
 * 发送短信验证码 (带验证)
 */
export declare function sendCodeWithValidation(phone: string, code: string, expireMinutes?: number): Promise<SmsResult>;
declare const _default: {
    initializeSmsConfig: typeof initializeSmsConfig;
    sendVerificationCode: typeof sendVerificationCode;
    sendNotification: typeof sendNotification;
    sendMarketing: typeof sendMarketing;
    sendBatchSms: typeof sendBatchSms;
    validatePhone: typeof validatePhone;
    sendCodeWithValidation: typeof sendCodeWithValidation;
};
export default _default;
//# sourceMappingURL=sms.service.d.ts.map
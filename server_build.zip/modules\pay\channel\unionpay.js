"use strict";
/**
 * DGKJ 支付平台 - 银联支付通道实现
 *
 * 支持: 银联二维码、APP支付、网关支付
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnionPayChannel = void 0;
const axios_1 = __importDefault(require("axios"));
const crypto = __importStar(require("crypto"));
const xml2js = __importStar(require("xml2js"));
const interface_1 = require("./interface");
class UnionPayChannel {
    constructor() {
        this.channelCode = interface_1.ChannelCode.UNIONPAY;
        this.channelName = '银联支付';
        this.supportedPayWays = [
            interface_1.PayWay.UNION_QR,
            interface_1.PayWay.UNION_APP,
            interface_1.PayWay.UNION_WAP,
            interface_1.PayWay.UNION_BANK,
        ];
        this.config = {
            code: '',
            name: '',
            appId: '',
            appSecret: '',
            mchId: '',
            apiKey: '',
        };
    }
    // 银联支付 API 地址
    getBaseUrl() {
        return this.config.sandbox
            ? 'https://gateway.95516.com/sandbox/api'
            : 'https://gateway.95516.com/api';
    }
    initialize(config) {
        this.config = {
            code: interface_1.ChannelCode.UNIONPAY,
            name: '银联支付',
            appId: config.appId,
            appSecret: config.appSecret,
            mchId: config.mchId,
            apiKey: config.apiKey,
            privateKey: config.privateKey,
            publicKey: config.publicKey,
            sandbox: config.sandbox,
            timeout: config.timeout || 30,
            extra: config.extra,
        };
    }
    /**
     * 执行支付
     */
    async pay(request) {
        try {
            const params = await this.buildPayParams(request);
            const response = await this.request('/trade/pay', params);
            if (response.respCode === '00') {
                let payUrl = '';
                let qrCode = '';
                let appParams;
                let h5Url = '';
                switch (request.payWay) {
                    case interface_1.PayWay.UNION_QR:
                        payUrl = response.qrCode;
                        qrCode = await this.generateQRCode(payUrl);
                        break;
                    case interface_1.PayWay.UNION_APP:
                        appParams = {
                            tn: response.tn,
                            certId: response.certId,
                            sign: response.sign,
                        };
                        break;
                    case interface_1.PayWay.UNION_WAP:
                    case interface_1.PayWay.UNION_BANK:
                        h5Url = response.payUrl || response.mwebUrl;
                        break;
                }
                return {
                    success: true,
                    orderNo: request.orderNo,
                    channelOrderNo: response.tn || response.orderId,
                    payUrl,
                    qrCode,
                    appParams,
                    h5Url,
                    expireTime: new Date(Date.now() + 2 * 60 * 60 * 1000),
                };
            }
            else {
                return {
                    success: false,
                    errorCode: response.respCode,
                    errorMsg: response.respMsg || '支付创建失败',
                };
            }
        }
        catch (error) {
            return {
                success: false,
                errorCode: 'PAY_FAILED',
                errorMsg: error.message || '支付创建失败',
            };
        }
    }
    /**
     * 查询订单
     */
    async query(request) {
        try {
            const params = await this.buildQueryParams(request);
            const response = await this.request('/trade/query', params);
            if (response.respCode === '00') {
                let status = interface_1.PayStatus.PENDING;
                switch (response.origRespCode) {
                    case '00':
                        status = interface_1.PayStatus.SUCCESS;
                        break;
                    case '03':
                    case '04':
                    case '05':
                        status = interface_1.PayStatus.PENDING;
                        break;
                    case '34':
                        status = interface_1.PayStatus.REFUNDING;
                        break;
                    default:
                        status = interface_1.PayStatus.FAILED;
                }
                return {
                    success: true,
                    status,
                    channelOrderNo: response.queryId,
                    paidTime: response.payTime ? new Date(response.payTime) : undefined,
                    rawResponse: response,
                };
            }
            else {
                return {
                    success: false,
                    errorCode: response.respCode,
                    errorMsg: response.respMsg,
                    status: interface_1.PayStatus.PENDING,
                };
            }
        }
        catch (error) {
            return {
                success: false,
                errorCode: 'QUERY_FAILED',
                errorMsg: error.message,
                status: interface_1.PayStatus.PENDING,
            };
        }
    }
    /**
     * 申请退款
     */
    async refund(request) {
        try {
            const params = await this.buildRefundParams(request);
            const response = await this.request('/trade/refund', params);
            if (response.respCode === '00') {
                return {
                    success: true,
                    refundNo: request.refundNo,
                    channelRefundNo: response.refundId,
                    status: interface_1.RefundStatus.SUCCESS,
                    refundAmount: parseInt(response.refundAmt),
                    refundTime: new Date(),
                };
            }
            else {
                return {
                    success: false,
                    errorCode: response.respCode,
                    errorMsg: response.respMsg || '退款失败',
                    status: interface_1.RefundStatus.FAILED,
                };
            }
        }
        catch (error) {
            return {
                success: false,
                errorCode: 'REFUND_FAILED',
                errorMsg: error.message,
                status: interface_1.RefundStatus.FAILED,
            };
        }
    }
    /**
     * 转账 (暂不支持)
     */
    async transfer(request) {
        return {
            success: false,
            errorCode: 'UNSUPPORTED',
            errorMsg: '银联通道暂不支持转账功能',
            status: 'failed',
        };
    }
    /**
     * 验证回调签名
     */
    async verifyCallback(data, headers) {
        try {
            if (!data.signature) {
                return { success: false, errorMsg: '缺少签名' };
            }
            const signData = { ...data };
            delete signData.signature;
            const signStr = this.getSignString(signData);
            const isValid = this.verifySign(signStr, data.signature);
            if (!isValid) {
                return { success: false, errorMsg: '签名验证失败' };
            }
            if (data.respCode !== '00') {
                return { success: false, errorMsg: data.respMsg };
            }
            return { success: true };
        }
        catch (error) {
            return { success: false, errorMsg: error.message };
        }
    }
    /**
     * 解析回调数据
     */
    async parseCallback(data) {
        let status;
        switch (data.respCode) {
            case '00':
                status = interface_1.PayStatus.SUCCESS;
                break;
            case '03':
            case '04':
            case '05':
                status = interface_1.PayStatus.PENDING;
                break;
            default:
                status = interface_1.PayStatus.FAILED;
        }
        return {
            channelCode: interface_1.ChannelCode.UNIONPAY,
            notifyType: 'pay',
            orderNo: data.orderId,
            channelOrderNo: data.queryId,
            status,
            amount: parseInt(data.totalAmount || '0'),
            paidAmount: data.receiveAmt ? parseInt(data.receiveAmt) : undefined,
            paidTime: data.payTime ? new Date(data.payTime) : undefined,
            attach: data.attach,
            rawData: data,
        };
    }
    /**
     * 响应回调成功
     */
    responseCallbackSuccess() {
        return JSON.stringify({ respCode: '00', respMsg: '成功' });
    }
    /**
     * 响应回调失败
     */
    responseCallbackFail() {
        return JSON.stringify({ respCode: '01', respMsg: '失败' });
    }
    // ==================== 私有方法 ====================
    /**
     * 构建支付参数
     */
    async buildPayParams(request) {
        const version = '5.1.0';
        const encoding = 'UTF-8';
        const bizType = '000301'; // 二维码支付
        const txnType = '01'; // 消费
        const txnSubType = '06'; // 二维码支付
        const channelType = '07'; // 互联网
        const currencyCode = '156';
        let txnSubTypeMap = {
            [interface_1.PayWay.UNION_QR]: '06',
            [interface_1.PayWay.UNION_APP]: '01',
            [interface_1.PayWay.UNION_WAP]: '02',
            [interface_1.PayWay.UNION_BANK]: '03',
        };
        const params = {
            version,
            encoding,
            bizType,
            txnType,
            txnSubType: txnSubTypeMap[request.payWay] || '06',
            channelType,
            merId: this.config.mchId,
            orderId: request.orderNo,
            txnTime: new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14),
            txnAmt: request.amount.toString(),
            currencyCode,
            subject: request.subject,
            signatureAlgorithm: '01', // RSA
        };
        if (request.payWay === interface_1.PayWay.UNION_WAP || request.payWay === interface_1.PayWay.UNION_BANK) {
            params.frontUrl = request.returnUrl || '';
        }
        else {
            params.backUrl = request.notifyUrl || '';
        }
        if (request.payWay === interface_1.PayWay.UNION_APP) {
            params.signNo = request.openId || ''; // 令牌
        }
        params.signature = this.sign(params);
        return params;
    }
    /**
     * 构建查询参数
     */
    async buildQueryParams(request) {
        const params = {
            version: '5.1.0',
            encoding: 'UTF-8',
            bizType: '000301',
            txnType: '00',
            txnSubType: '06',
            channelType: '07',
            merId: this.config.mchId,
            orderId: request.orderNo,
            txnTime: '',
            signatureAlgorithm: '01',
        };
        if (request.channelOrderNo) {
            params.queryId = request.channelOrderNo;
        }
        params.signature = this.sign(params);
        return params;
    }
    /**
     * 构建退款参数
     */
    async buildRefundParams(request) {
        const params = {
            version: '5.1.0',
            encoding: 'UTF-8',
            bizType: '000301',
            txnType: '04',
            txnSubType: '00',
            channelType: '07',
            merId: this.config.mchId,
            orderId: request.orderNo,
            txnTime: '',
            txnAmt: request.refundAmount.toString(),
            refundAmt: request.refundAmount.toString(),
            outRefundId: request.refundNo,
            signatureAlgorithm: '01',
        };
        params.signature = this.sign(params);
        return params;
    }
    /**
     * 发送请求
     */
    async request(path, params) {
        try {
            const url = `${this.getBaseUrl()}${path}`;
            const response = await axios_1.default.post(url, this.buildFormData(params), {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
                },
                timeout: (this.config.timeout || 30) * 1000,
            });
            // 解析响应
            const dataStr = typeof response.data === 'string'
                ? response.data
                : JSON.stringify(response.data);
            return this.parseResponse(dataStr);
        }
        catch (error) {
            throw error;
        }
    }
    /**
     * 构建 Form Data
     */
    buildFormData(params) {
        return Object.entries(params)
            .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
            .join('&');
    }
    /**
     * 解析响应
     */
    parseResponse(data) {
        // 支持 XML 和 JSON 格式
        if (data.includes('<')) {
            const parser = new xml2js.Parser({ explicitArray: false });
            // 简化处理
            const result = {};
            const matches = data.match(/<(\w+)>([^<]*)/g);
            if (matches) {
                for (const match of matches) {
                    const [_, key, value] = match.match(/<(\w+)>([^<]*)/) || [];
                    if (key && value) {
                        result[key] = value;
                    }
                }
            }
            return result;
        }
        return JSON.parse(data);
    }
    /**
     * 获取签名字符串
     */
    getSignString(params) {
        const keys = Object.keys(params).sort();
        const pairs = [];
        for (const key of keys) {
            if (params[key] !== undefined && params[key] !== '') {
                pairs.push(`${key}=${params[key]}`);
            }
        }
        return pairs.join('&');
    }
    /**
     * 签名
     */
    sign(params) {
        const signStr = this.getSignString(params);
        if (this.config.privateKey) {
            const sign = crypto.createSign('RSA-SHA256');
            sign.update(signStr);
            return sign.sign(this.config.privateKey, 'base64');
        }
        // 如果没有私钥，使用简单的 MD5 签名 (仅用于测试)
        return crypto.createHash('sha256').update(signStr + '&key=' + this.config.apiKey).digest('hex').toUpperCase();
    }
    /**
     * 验签
     */
    verifySign(data, signature) {
        if (!this.config.publicKey) {
            return false;
        }
        const verify = crypto.createVerify('RSA-SHA256');
        verify.update(data);
        return verify.verify(this.config.publicKey, signature, 'base64');
    }
    /**
     * 生成二维码
     */
    async generateQRCode(content) {
        try {
            const QRCode = require('qrcode');
            return await QRCode.toDataURL(content, {
                width: 300,
                margin: 2,
            });
        }
        catch {
            return '';
        }
    }
}
exports.UnionPayChannel = UnionPayChannel;
exports.default = new UnionPayChannel();
//# sourceMappingURL=unionpay.js.map
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProfitRollback = exports.ProfitRecord = exports.ProfitReceiver = exports.ProfitAccountGroup = void 0;
const typeorm_1 = require("typeorm");
let ProfitAccountGroup = class ProfitAccountGroup {
};
exports.ProfitAccountGroup = ProfitAccountGroup;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], ProfitAccountGroup.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'group_no', length: 32, unique: true }),
    __metadata("design:type", String)
], ProfitAccountGroup.prototype, "groupNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'group_name', length: 64 }),
    __metadata("design:type", String)
], ProfitAccountGroup.prototype, "groupName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'agent_no', length: 32, nullable: true }),
    __metadata("design:type", String)
], ProfitAccountGroup.prototype, "agentNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_no', length: 32, nullable: true }),
    __metadata("design:type", String)
], ProfitAccountGroup.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], ProfitAccountGroup.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], ProfitAccountGroup.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], ProfitAccountGroup.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], ProfitAccountGroup.prototype, "updateTime", void 0);
exports.ProfitAccountGroup = ProfitAccountGroup = __decorate([
    (0, typeorm_1.Entity)('profit_account_group')
], ProfitAccountGroup);
let ProfitReceiver = class ProfitReceiver {
};
exports.ProfitReceiver = ProfitReceiver;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], ProfitReceiver.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'receiver_no', length: 32, unique: true }),
    __metadata("design:type", String)
], ProfitReceiver.prototype, "receiverNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'group_no', length: 32 }),
    __metadata("design:type", String)
], ProfitReceiver.prototype, "groupNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'receiver_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], ProfitReceiver.prototype, "receiverType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'receiver_name', length: 64 }),
    __metadata("design:type", String)
], ProfitReceiver.prototype, "receiverName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'receiver_account', length: 32 }),
    __metadata("design:type", String)
], ProfitReceiver.prototype, "receiverAccount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_name', length: 64, nullable: true }),
    __metadata("design:type", String)
], ProfitReceiver.prototype, "bankName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'profit_ratio', type: 'decimal', precision: 6, scale: 4 }),
    __metadata("design:type", Number)
], ProfitReceiver.prototype, "profitRatio", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fixed_amount', type: 'decimal', precision: 18, scale: 2, nullable: true }),
    __metadata("design:type", Number)
], ProfitReceiver.prototype, "fixedAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'priority', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], ProfitReceiver.prototype, "priority", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], ProfitReceiver.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], ProfitReceiver.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], ProfitReceiver.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], ProfitReceiver.prototype, "updateTime", void 0);
exports.ProfitReceiver = ProfitReceiver = __decorate([
    (0, typeorm_1.Entity)('profit_receiver')
], ProfitReceiver);
let ProfitRecord = class ProfitRecord {
};
exports.ProfitRecord = ProfitRecord;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], ProfitRecord.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'profit_no', length: 32, unique: true }),
    __metadata("design:type", String)
], ProfitRecord.prototype, "profitNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'order_no', length: 32 }),
    __metadata("design:type", String)
], ProfitRecord.prototype, "orderNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_no', length: 32 }),
    __metadata("design:type", String)
], ProfitRecord.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_code', length: 32, nullable: true }),
    __metadata("design:type", String)
], ProfitRecord.prototype, "channelCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'trade_amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], ProfitRecord.prototype, "tradeAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'profit_amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], ProfitRecord.prototype, "profitAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'profit_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], ProfitRecord.prototype, "profitType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 0 }),
    __metadata("design:type", Number)
], ProfitRecord.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'settle_time', nullable: true }),
    __metadata("design:type", Date)
], ProfitRecord.prototype, "settleTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], ProfitRecord.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], ProfitRecord.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], ProfitRecord.prototype, "updateTime", void 0);
exports.ProfitRecord = ProfitRecord = __decorate([
    (0, typeorm_1.Entity)('profit_record')
], ProfitRecord);
let ProfitRollback = class ProfitRollback {
};
exports.ProfitRollback = ProfitRollback;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], ProfitRollback.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'rollback_no', length: 32, unique: true }),
    __metadata("design:type", String)
], ProfitRollback.prototype, "rollbackNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'profit_no', length: 32 }),
    __metadata("design:type", String)
], ProfitRollback.prototype, "profitNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'order_no', length: 32 }),
    __metadata("design:type", String)
], ProfitRollback.prototype, "orderNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_no', length: 32 }),
    __metadata("design:type", String)
], ProfitRollback.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'receiver_no', length: 32 }),
    __metadata("design:type", String)
], ProfitRollback.prototype, "receiverNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'receiver_name', length: 64 }),
    __metadata("design:type", String)
], ProfitRollback.prototype, "receiverName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], ProfitRollback.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'rollback_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], ProfitRollback.prototype, "rollbackType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'reason', length: 255, nullable: true }),
    __metadata("design:type", String)
], ProfitRollback.prototype, "reason", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 0 }),
    __metadata("design:type", Number)
], ProfitRollback.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'complete_time', nullable: true }),
    __metadata("design:type", Date)
], ProfitRollback.prototype, "completeTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], ProfitRollback.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], ProfitRollback.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], ProfitRollback.prototype, "updateTime", void 0);
exports.ProfitRollback = ProfitRollback = __decorate([
    (0, typeorm_1.Entity)('profit_rollback')
], ProfitRollback);
//# sourceMappingURL=profit.entity.js.map
export interface AutoCheckConfig {
    enabled: boolean;
    checkTime: string;
    channels: string[];
    autoConfirmDiff: boolean;
    diffThreshold: number;
}
export interface AutoSettlementConfig {
    enabled: boolean;
    settleType: 1 | 2;
    minAmount: number;
    maxAmount: number;
    settleTimeStart: string;
    settleTimeEnd: string;
    feeRates: {
        d0: number;
        t1: number;
    };
}
export interface AutoProfitShareConfig {
    enabled: boolean;
    shareType: 1 | 2;
    platformShareRate: number;
    agentShareRates: Record<string, number>;
    autoShareOnTrade: boolean;
}
export interface AutoCollectionConfig {
    enabled: boolean;
    collectionType: 1 | 2 | 3;
    collectionAmount?: number;
    reservedAmount?: number;
    collectionTime: string;
    accounts: Array<{
        fromAccountNo: string;
        toAccountNo: string;
    }>;
}
export declare class CiticAutoService {
    private accountRepo;
    private checkRepo;
    private settlementRepo;
    private profitShareRepo;
    private collectionRepo;
    private recordRepo;
    private autoCheckConfig;
    private autoSettlementConfig;
    private autoProfitShareConfig;
    private autoCollectionConfig;
    /**
     * ========== 自动对账核心逻辑 ==========
     */
    /**
     * 执行自动对账
     * @param checkDate 对账日期，格式 YYYY-MM-DD
     * @param channelCode 通道编号，为空则对账所有通道
     */
    executeAutoCheck(checkDate: string, channelCode?: string): Promise<{
        success: boolean;
        checkNo: string;
        totalCount: number;
        successCount: number;
        failCount: number;
        diffCount: number;
        diffAmount: number;
        error?: string;
    }>;
    /**
     * 获取通道对账数据
     * 实际场景中，这里应该调用中信银行或其他支付通道的对账API
     */
    private fetchChannelCheckData;
    /**
     * 获取平台交易数据
     * 从本地数据库查询
     */
    private fetchPlatformTradeData;
    /**
     * 比对平台数据与通道数据
     */
    private compareData;
    /**
     * ========== 自动分账核心逻辑 ==========
     */
    /**
     * 执行自动分账
     * @param orderNo 原订单号
     * @param tradeAmount 交易金额
     * @param accountNo 账户编号
     */
    executeAutoProfitShare(orderNo: string, tradeAmount: number, accountNo: string, receivers: Array<{
        accountNo: string;
        accountName: string;
        shareType: 1 | 2;
        shareRate?: number;
        shareAmount?: number;
    }>): Promise<{
        success: boolean;
        shareNo: string;
        totalShareAmount: number;
        results: Array<{
            receiverAccountNo: string;
            shareAmount: number;
            status: string;
            error?: string;
        }>;
        error?: string;
    }>;
    /**
     * ========== 自动结算核心逻辑 ==========
     */
    /**
     * 执行自动结算
     * @param accountNo 账户编号
     * @param settleType 结算类型 1=D0, 2=T1
     */
    executeAutoSettlement(accountNo: string, settleType: 1 | 2): Promise<{
        success: boolean;
        settleNo: string;
        amount: number;
        fee: number;
        actualAmount: number;
        error?: string;
    }>;
    /**
     * 批量执行T1结算
     * 每日凌晨调用，对所有满足条件的账户执行T1结算
     */
    executeBatchT1Settlement(): Promise<{
        totalAccounts: number;
        successCount: number;
        failCount: number;
        totalAmount: number;
        results: Array<{
            accountNo: string;
            settleNo: string;
            amount: number;
            status: string;
            error?: string;
        }>;
    }>;
    /**
     * 结算回调处理
     * 模拟中信银行异步通知
     */
    private settlementCallback;
    /**
     * ========== 自动资金归集核心逻辑 ==========
     */
    /**
     * 执行自动资金归集
     */
    executeAutoCollection(): Promise<{
        success: boolean;
        totalCollected: number;
        results: Array<{
            collectionNo: string;
            fromAccountNo: string;
            toAccountNo: string;
            amount: number;
            status: string;
            error?: string;
        }>;
    }>;
    private executeCollection;
    /**
     * ========== 辅助方法 ==========
     */
    private isInSettleTimeWindow;
    /**
     * 更新自动对账配置
     */
    updateCheckConfig(config: Partial<AutoCheckConfig>): void;
    /**
     * 更新自动结算配置
     */
    updateSettlementConfig(config: Partial<AutoSettlementConfig>): void;
    /**
     * 更新自动分账配置
     */
    updateProfitShareConfig(config: Partial<AutoProfitShareConfig>): void;
    /**
     * 更新自动归集配置
     */
    updateCollectionConfig(config: Partial<AutoCollectionConfig>): void;
    /**
     * 获取当前配置
     */
    getConfigs(): {
        checkConfig: AutoCheckConfig;
        settlementConfig: AutoSettlementConfig;
        profitShareConfig: AutoProfitShareConfig;
        collectionConfig: AutoCollectionConfig;
    };
}
declare const _default: CiticAutoService;
export default _default;
//# sourceMappingURL=auto.service.d.ts.map
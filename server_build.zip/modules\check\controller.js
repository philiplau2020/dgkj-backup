"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CheckController = void 0;
const uuid_1 = require("uuid");
const data_source_1 = require("../../config/data-source");
const check_entity_1 = require("../../database/entities/check.entity");
class CheckController {
    constructor() {
        this.batchRepo = data_source_1.AppDataSource.getRepository(check_entity_1.CheckBatch);
        this.channelBillRepo = data_source_1.AppDataSource.getRepository(check_entity_1.CheckChannelBill);
        this.diffBillRepo = data_source_1.AppDataSource.getRepository(check_entity_1.CheckDiffBill);
    }
    // ============== Batch ==============
    async getBatchList(req, res, next) {
        try {
            const { page = 1, pageSize = 10, batchNo, status, startDate, endDate } = req.query;
            const skip = (Number(page) - 1) * Number(pageSize);
            const queryBuilder = this.batchRepo.createQueryBuilder('batch');
            if (batchNo)
                queryBuilder.andWhere('batch.batchNo LIKE :batchNo', { batchNo: `%${batchNo}%` });
            if (status !== undefined)
                queryBuilder.andWhere('batch.status = :status', { status });
            if (startDate)
                queryBuilder.andWhere('batch.checkDate >= :startDate', { startDate });
            if (endDate)
                queryBuilder.andWhere('batch.checkDate <= :endDate', { endDate });
            const [list, total] = await queryBuilder.skip(skip).take(Number(pageSize)).orderBy('batch.createTime', 'DESC').getManyAndCount();
            res.json({ code: 0, message: 'success', data: { list, total }, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async createBatch(req, res, next) {
        try {
            const { checkDate, channelCode } = req.body;
            const batchNo = 'CB' + Date.now();
            const batch = this.batchRepo.create({
                id: (0, uuid_1.v4)(),
                batchNo,
                checkDate,
                channelCode: channelCode || '',
                channelName: channelCode || '全部通道',
                platformOrderCount: 0,
                platformTotalAmount: 0,
                channelOrderCount: 0,
                channelTotalAmount: 0,
                diffOrderCount: 0,
                diffAmount: 0,
                status: check_entity_1.CheckBatchStatus.PROCESSING,
                createTime: new Date(),
                updateTime: new Date(),
            });
            await this.batchRepo.save(batch);
            res.json({ code: 0, message: '创建成功', data: batch, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async reviewBatch(req, res, next) {
        try {
            const { id } = req.params;
            const { status, remark } = req.body;
            await this.batchRepo.update(id, {
                status,
                remark,
                completeTime: status === check_entity_1.CheckBatchStatus.SUCCESS ? new Date() : undefined,
                updateTime: new Date(),
            });
            res.json({ code: 0, message: '审核成功', data: null, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    // ============== Channel Bill ==============
    async getChannelBillList(req, res, next) {
        try {
            const { page = 1, pageSize = 10, batchNo, channelCode, orderNo } = req.query;
            const skip = (Number(page) - 1) * Number(pageSize);
            const queryBuilder = this.channelBillRepo.createQueryBuilder('bill');
            if (batchNo)
                queryBuilder.andWhere('bill.batchNo = :batchNo', { batchNo });
            if (channelCode)
                queryBuilder.andWhere('bill.channelCode = :channelCode', { channelCode });
            if (orderNo)
                queryBuilder.andWhere('bill.orderNo = :orderNo', { orderNo });
            const [list, total] = await queryBuilder.skip(skip).take(Number(pageSize)).orderBy('bill.createTime', 'DESC').getManyAndCount();
            res.json({ code: 0, message: 'success', data: { list, total }, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async createChannelBill(req, res, next) {
        try {
            const { batchNo, channelCode, channelOrderNo, orderNo, amount, fee, status } = req.body;
            const bill = this.channelBillRepo.create({
                id: (0, uuid_1.v4)(),
                batchNo,
                channelCode,
                channelOrderNo,
                orderNo,
                amount,
                fee,
                status: status || 'PENDING',
                createTime: new Date(),
            });
            await this.channelBillRepo.save(bill);
            res.json({ code: 0, message: '创建成功', data: bill, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    // ============== Diff Bill ==============
    async getDiffBillList(req, res, next) {
        try {
            const { page = 1, pageSize = 10, batchNo, diffType, status } = req.query;
            const skip = (Number(page) - 1) * Number(pageSize);
            const queryBuilder = this.diffBillRepo.createQueryBuilder('diff');
            if (batchNo)
                queryBuilder.andWhere('diff.batchNo = :batchNo', { batchNo });
            if (diffType !== undefined)
                queryBuilder.andWhere('diff.diffType = :diffType', { diffType });
            if (status !== undefined)
                queryBuilder.andWhere('diff.handleStatus = :status', { status });
            const [list, total] = await queryBuilder.skip(skip).take(Number(pageSize)).orderBy('diff.createTime', 'DESC').getManyAndCount();
            res.json({ code: 0, message: 'success', data: { list, total }, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    async handleDiffBill(req, res, next) {
        try {
            const { id } = req.params;
            const { handleStatus, handleRemark } = req.body;
            await this.diffBillRepo.update(id, {
                handleStatus,
                handleRemark,
                handleTime: new Date(),
                updateTime: new Date(),
            });
            res.json({ code: 0, message: '处理成功', data: null, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.CheckController = CheckController;
exports.default = new CheckController();
//# sourceMappingURL=controller.js.map
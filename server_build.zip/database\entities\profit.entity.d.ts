export declare class ProfitAccountGroup {
    id: string;
    groupNo: string;
    groupName: string;
    agentNo: string;
    mchNo: string;
    status: number;
    remark: string;
    createTime: Date;
    updateTime: Date;
}
export declare class ProfitReceiver {
    id: string;
    receiverNo: string;
    groupNo: string;
    receiverType: number;
    receiverName: string;
    receiverAccount: string;
    bankName: string;
    profitRatio: number;
    fixedAmount: number;
    priority: number;
    status: number;
    remark: string;
    createTime: Date;
    updateTime: Date;
}
export declare class ProfitRecord {
    id: string;
    profitNo: string;
    orderNo: string;
    mchNo: string;
    channelCode: string;
    tradeAmount: number;
    profitAmount: number;
    profitType: number;
    status: number;
    settleTime: Date;
    remark: string;
    createTime: Date;
    updateTime: Date;
}
export declare class ProfitRollback {
    id: string;
    rollbackNo: string;
    profitNo: string;
    orderNo: string;
    mchNo: string;
    receiverNo: string;
    receiverName: string;
    amount: number;
    rollbackType: number;
    reason: string;
    status: number;
    completeTime: Date;
    remark: string;
    createTime: Date;
    updateTime: Date;
}
//# sourceMappingURL=profit.entity.d.ts.map
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeviceBinding = exports.DeviceActivationCode = exports.DeviceInfo = exports.DeviceType = exports.DeviceStatus = void 0;
const typeorm_1 = require("typeorm");
var DeviceStatus;
(function (DeviceStatus) {
    DeviceStatus[DeviceStatus["DISABLED"] = 0] = "DISABLED";
    DeviceStatus[DeviceStatus["ENABLED"] = 1] = "ENABLED";
    DeviceStatus[DeviceStatus["ACTIVATED"] = 2] = "ACTIVATED";
    DeviceStatus[DeviceStatus["LOST"] = 3] = "LOST";
})(DeviceStatus || (exports.DeviceStatus = DeviceStatus = {}));
var DeviceType;
(function (DeviceType) {
    DeviceType[DeviceType["QR_CODE"] = 1] = "QR_CODE";
    DeviceType[DeviceType["SPEAKER"] = 2] = "SPEAKER";
    DeviceType[DeviceType["PRINTER"] = 3] = "PRINTER";
    DeviceType[DeviceType["POS"] = 4] = "POS";
})(DeviceType || (exports.DeviceType = DeviceType = {}));
let DeviceInfo = class DeviceInfo {
};
exports.DeviceInfo = DeviceInfo;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], DeviceInfo.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'device_no', length: 32, unique: true }),
    __metadata("design:type", String)
], DeviceInfo.prototype, "deviceNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'device_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], DeviceInfo.prototype, "deviceType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'device_name', length: 64 }),
    __metadata("design:type", String)
], DeviceInfo.prototype, "deviceName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'device_model', length: 64, nullable: true }),
    __metadata("design:type", String)
], DeviceInfo.prototype, "deviceModel", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_no', length: 32, nullable: true }),
    __metadata("design:type", String)
], DeviceInfo.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'store_id', length: 32, nullable: true }),
    __metadata("design:type", String)
], DeviceInfo.prototype, "storeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'sn', length: 64, nullable: true }),
    __metadata("design:type", String)
], DeviceInfo.prototype, "sn", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'iccid', length: 64, nullable: true }),
    __metadata("design:type", String)
], DeviceInfo.prototype, "iccid", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'imei', length: 64, nullable: true }),
    __metadata("design:type", String)
], DeviceInfo.prototype, "imei", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: DeviceStatus.ENABLED }),
    __metadata("design:type", Number)
], DeviceInfo.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'activate_time', nullable: true }),
    __metadata("design:type", Date)
], DeviceInfo.prototype, "activateTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'last_heartbeat', nullable: true }),
    __metadata("design:type", Date)
], DeviceInfo.prototype, "lastHeartbeat", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], DeviceInfo.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], DeviceInfo.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], DeviceInfo.prototype, "updateTime", void 0);
exports.DeviceInfo = DeviceInfo = __decorate([
    (0, typeorm_1.Entity)('device_info')
], DeviceInfo);
let DeviceActivationCode = class DeviceActivationCode {
};
exports.DeviceActivationCode = DeviceActivationCode;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], DeviceActivationCode.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'code', length: 32, unique: true }),
    __metadata("design:type", String)
], DeviceActivationCode.prototype, "code", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'device_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], DeviceActivationCode.prototype, "deviceType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'batch_no', length: 32, nullable: true }),
    __metadata("design:type", String)
], DeviceActivationCode.prototype, "batchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 0 }),
    __metadata("design:type", Number)
], DeviceActivationCode.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'used_time', nullable: true }),
    __metadata("design:type", Date)
], DeviceActivationCode.prototype, "usedTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'used_mch_no', length: 32, nullable: true }),
    __metadata("design:type", String)
], DeviceActivationCode.prototype, "usedMchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'expire_time', nullable: true }),
    __metadata("design:type", Date)
], DeviceActivationCode.prototype, "expireTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], DeviceActivationCode.prototype, "createTime", void 0);
exports.DeviceActivationCode = DeviceActivationCode = __decorate([
    (0, typeorm_1.Entity)('device_activation_code')
], DeviceActivationCode);
let DeviceBinding = class DeviceBinding {
};
exports.DeviceBinding = DeviceBinding;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], DeviceBinding.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'device_no', length: 32 }),
    __metadata("design:type", String)
], DeviceBinding.prototype, "deviceNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_no', length: 32 }),
    __metadata("design:type", String)
], DeviceBinding.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'store_id', length: 32, nullable: true }),
    __metadata("design:type", String)
], DeviceBinding.prototype, "storeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'binding_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], DeviceBinding.prototype, "bindingType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], DeviceBinding.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], DeviceBinding.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], DeviceBinding.prototype, "updateTime", void 0);
exports.DeviceBinding = DeviceBinding = __decorate([
    (0, typeorm_1.Entity)('device_binding')
], DeviceBinding);
//# sourceMappingURL=device.entity.js.map
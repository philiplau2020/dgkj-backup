"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const controller_1 = __importDefault(require("./controller"));
const auto_service_1 = __importDefault(require("./auto.service"));
const auth_middleware_1 = require("../../common/middleware/auth.middleware");
const router = (0, express_1.Router)();
router.use(auth_middleware_1.authGuard);
// ========== 账户管理 ==========
router.get('/account/list', controller_1.default.getAccountList.bind(controller_1.default));
router.get('/account/info', controller_1.default.getAccountInfo.bind(controller_1.default));
router.get('/account/stats', controller_1.default.getAccountStats.bind(controller_1.default));
router.get('/account/balance', controller_1.default.queryBalance.bind(controller_1.default));
router.get('/account/records', controller_1.default.getAccountRecords.bind(controller_1.default));
router.post('/account/register', controller_1.default.registerAccount.bind(controller_1.default));
router.post('/account', controller_1.default.registerAccount.bind(controller_1.default));
router.put('/account/:id', controller_1.default.updateAccount.bind(controller_1.default));
// ========== 银行卡管理 ==========
router.get('/card/list', controller_1.default.getCardList.bind(controller_1.default));
router.post('/card/bind', controller_1.default.bindCard.bind(controller_1.default));
router.post('/card/unbind', controller_1.default.unbindCard.bind(controller_1.default));
router.post('/card', controller_1.default.bindCard.bind(controller_1.default));
router.delete('/card/:id', controller_1.default.deleteCard.bind(controller_1.default));
// ========== 资金归集 ==========
router.get('/collection/list', controller_1.default.getCollectionList.bind(controller_1.default));
router.post('/collection/set', controller_1.default.setCollection.bind(controller_1.default));
router.post('/collection/active', controller_1.default.activeCollection.bind(controller_1.default));
router.delete('/collection/:id', controller_1.default.deleteCollection.bind(controller_1.default));
// ========== 余额分账 ==========
router.get('/profit-share/list', controller_1.default.getProfitShareList.bind(controller_1.default));
router.post('/profit-share/execute', controller_1.default.executeProfitShare.bind(controller_1.default));
router.delete('/profit-share/:id', controller_1.default.deleteProfitShare.bind(controller_1.default));
// ========== 代付打款 ==========
router.get('/transfer/list', controller_1.default.getTransferList.bind(controller_1.default));
router.post('/transfer/pay', controller_1.default.createTransfer.bind(controller_1.default));
router.get('/transfer/query', controller_1.default.queryTransfer.bind(controller_1.default));
router.post('/transfer/confirm', controller_1.default.confirmTransfer.bind(controller_1.default));
// ========== 结算管理 ==========
router.get('/settlement/list', controller_1.default.getSettlementList.bind(controller_1.default));
router.post('/settlement/apply', controller_1.default.applySettlement.bind(controller_1.default));
router.post('/settlement/confirm', controller_1.default.confirmSettlement.bind(controller_1.default));
router.post('/settlement/cancel', controller_1.default.cancelSettlement.bind(controller_1.default));
// ========== 对账管理 ==========
router.get('/check/list', controller_1.default.getCheckList.bind(controller_1.default));
router.post('/check/trigger', controller_1.default.triggerCheck.bind(controller_1.default));
router.get('/check/download', controller_1.default.downloadCheckBill.bind(controller_1.default));
router.get('/check/diff/list', controller_1.default.getCheckDiffList.bind(controller_1.default));
router.post('/check/diff/confirm', controller_1.default.confirmCheckDiff.bind(controller_1.default));
// ========== 自动调度服务 ==========
router.post('/auto/check', async (req, res, next) => {
    try {
        const { checkDate, channelCode } = req.body;
        const result = await auto_service_1.default.executeAutoCheck(checkDate, channelCode);
        res.json({ code: 0, message: result.success ? '对账完成' : result.error, data: result });
    }
    catch (error) {
        next(error);
    }
});
router.post('/auto/settlement', async (req, res, next) => {
    try {
        const { accountNo, settleType } = req.body;
        const result = await auto_service_1.default.executeAutoSettlement(accountNo, settleType);
        res.json({ code: 0, message: result.success ? '结算申请已提交' : result.error, data: result });
    }
    catch (error) {
        next(error);
    }
});
router.post('/auto/profit-share', async (req, res, next) => {
    try {
        const { orderNo, tradeAmount, accountNo, receivers } = req.body;
        const result = await auto_service_1.default.executeAutoProfitShare(orderNo, tradeAmount, accountNo, receivers);
        res.json({ code: 0, message: result.success ? '分账完成' : result.error, data: result });
    }
    catch (error) {
        next(error);
    }
});
router.post('/auto/collection', async (req, res, next) => {
    try {
        const result = await auto_service_1.default.executeAutoCollection();
        res.json({ code: 0, message: '归集完成', data: result });
    }
    catch (error) {
        next(error);
    }
});
router.get('/auto/configs', async (req, res) => {
    res.json({ code: 0, message: 'success', data: auto_service_1.default.getConfigs() });
});
router.post('/auto/configs', async (req, res, next) => {
    try {
        const { checkConfig, settlementConfig, profitShareConfig, collectionConfig } = req.body;
        if (checkConfig)
            auto_service_1.default.updateCheckConfig(checkConfig);
        if (settlementConfig)
            auto_service_1.default.updateSettlementConfig(settlementConfig);
        if (profitShareConfig)
            auto_service_1.default.updateProfitShareConfig(profitShareConfig);
        if (collectionConfig)
            auto_service_1.default.updateCollectionConfig(collectionConfig);
        res.json({ code: 0, message: '配置已更新', data: auto_service_1.default.getConfigs() });
    }
    catch (error) {
        next(error);
    }
});
exports.default = router;
//# sourceMappingURL=routes.js.map
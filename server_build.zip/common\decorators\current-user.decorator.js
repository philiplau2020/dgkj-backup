"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CurrentUser = CurrentUser;
exports.getCurrentUser = getCurrentUser;
// 获取当前登录用户
function CurrentUser(req) {
    return req.user;
}
// 简化版本，用于类型装饰
function getCurrentUser(req) {
    return req.user;
}
//# sourceMappingURL=current-user.decorator.js.map
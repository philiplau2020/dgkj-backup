"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MchRate = exports.MchStore = exports.MchApp = exports.MchInfo = exports.MchType = exports.MchStatus = void 0;
const typeorm_1 = require("typeorm");
var MchStatus;
(function (MchStatus) {
    MchStatus[MchStatus["DISABLED"] = 0] = "DISABLED";
    MchStatus[MchStatus["ENABLED"] = 1] = "ENABLED";
    MchStatus[MchStatus["PENDING_REVIEW"] = 2] = "PENDING_REVIEW";
    MchStatus[MchStatus["REJECTED"] = 3] = "REJECTED";
})(MchStatus || (exports.MchStatus = MchStatus = {}));
var MchType;
(function (MchType) {
    MchType[MchType["PERSONAL"] = 1] = "PERSONAL";
    MchType[MchType["ENTERPRISE"] = 2] = "ENTERPRISE";
})(MchType || (exports.MchType = MchType = {}));
let MchInfo = class MchInfo {
};
exports.MchInfo = MchInfo;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], MchInfo.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_no', length: 32, unique: true }),
    __metadata("design:type", String)
], MchInfo.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_name', length: 128 }),
    __metadata("design:type", String)
], MchInfo.prototype, "mchName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_short_name', length: 64, nullable: true }),
    __metadata("design:type", String)
], MchInfo.prototype, "mchShortName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_type', type: 'tinyint', default: MchType.PERSONAL }),
    __metadata("design:type", Number)
], MchInfo.prototype, "mchType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'agent_id', length: 64, nullable: true }),
    __metadata("design:type", String)
], MchInfo.prototype, "agentId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'contact_name', length: 64 }),
    __metadata("design:type", String)
], MchInfo.prototype, "contactName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'contact_phone', length: 32 }),
    __metadata("design:type", String)
], MchInfo.prototype, "contactPhone", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'contact_email', length: 128, nullable: true }),
    __metadata("design:type", String)
], MchInfo.prototype, "contactEmail", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'province', length: 32, nullable: true }),
    __metadata("design:type", String)
], MchInfo.prototype, "province", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'city', length: 32, nullable: true }),
    __metadata("design:type", String)
], MchInfo.prototype, "city", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'district', length: 32, nullable: true }),
    __metadata("design:type", String)
], MchInfo.prototype, "district", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'address', length: 255, nullable: true }),
    __metadata("design:type", String)
], MchInfo.prototype, "address", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'business_license', length: 255, nullable: true }),
    __metadata("design:type", String)
], MchInfo.prototype, "businessLicense", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'id_card_front', length: 255, nullable: true }),
    __metadata("design:type", String)
], MchInfo.prototype, "idCardFront", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'id_card_back', length: 255, nullable: true }),
    __metadata("design:type", String)
], MchInfo.prototype, "idCardBack", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_name', length: 64, nullable: true }),
    __metadata("design:type", String)
], MchInfo.prototype, "bankName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_account', length: 32, nullable: true }),
    __metadata("design:type", String)
], MchInfo.prototype, "bankAccount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'bank_username', length: 64, nullable: true }),
    __metadata("design:type", String)
], MchInfo.prototype, "bankUsername", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: MchStatus.PENDING_REVIEW }),
    __metadata("design:type", Number)
], MchInfo.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'review_remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], MchInfo.prototype, "reviewRemark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'review_time', nullable: true }),
    __metadata("design:type", Date)
], MchInfo.prototype, "reviewTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'review_user_id', length: 64, nullable: true }),
    __metadata("design:type", String)
], MchInfo.prototype, "reviewUserId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'balance', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], MchInfo.prototype, "balance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'frozen_balance', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], MchInfo.prototype, "frozenBalance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'settle_balance', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], MchInfo.prototype, "settleBalance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], MchInfo.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], MchInfo.prototype, "updateTime", void 0);
exports.MchInfo = MchInfo = __decorate([
    (0, typeorm_1.Entity)('mch_info')
], MchInfo);
let MchApp = class MchApp {
};
exports.MchApp = MchApp;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], MchApp.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'app_id', length: 32, unique: true }),
    __metadata("design:type", String)
], MchApp.prototype, "appId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_no', length: 32 }),
    __metadata("design:type", String)
], MchApp.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'app_name', length: 64 }),
    __metadata("design:type", String)
], MchApp.prototype, "appName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'app_secret', length: 64 }),
    __metadata("design:type", String)
], MchApp.prototype, "appSecret", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'notify_url', length: 255, nullable: true }),
    __metadata("design:type", String)
], MchApp.prototype, "notifyUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'return_url', length: 255, nullable: true }),
    __metadata("design:type", String)
], MchApp.prototype, "returnUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], MchApp.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], MchApp.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], MchApp.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], MchApp.prototype, "updateTime", void 0);
exports.MchApp = MchApp = __decorate([
    (0, typeorm_1.Entity)('mch_app')
], MchApp);
let MchStore = class MchStore {
};
exports.MchStore = MchStore;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], MchStore.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'store_id', length: 32, unique: true }),
    __metadata("design:type", String)
], MchStore.prototype, "storeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_no', length: 32 }),
    __metadata("design:type", String)
], MchStore.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'store_name', length: 64 }),
    __metadata("design:type", String)
], MchStore.prototype, "storeName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'store_no', length: 32, nullable: true }),
    __metadata("design:type", String)
], MchStore.prototype, "storeNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'contact_name', length: 64, nullable: true }),
    __metadata("design:type", String)
], MchStore.prototype, "contactName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'contact_phone', length: 32, nullable: true }),
    __metadata("design:type", String)
], MchStore.prototype, "contactPhone", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'province', length: 32, nullable: true }),
    __metadata("design:type", String)
], MchStore.prototype, "province", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'city', length: 32, nullable: true }),
    __metadata("design:type", String)
], MchStore.prototype, "city", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'district', length: 32, nullable: true }),
    __metadata("design:type", String)
], MchStore.prototype, "district", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'address', length: 255, nullable: true }),
    __metadata("design:type", String)
], MchStore.prototype, "address", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'latitude', type: 'decimal', precision: 10, scale: 6, nullable: true }),
    __metadata("design:type", Number)
], MchStore.prototype, "latitude", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'longitude', type: 'decimal', precision: 10, scale: 6, nullable: true }),
    __metadata("design:type", Number)
], MchStore.prototype, "longitude", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'device_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], MchStore.prototype, "deviceCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], MchStore.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], MchStore.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], MchStore.prototype, "updateTime", void 0);
exports.MchStore = MchStore = __decorate([
    (0, typeorm_1.Entity)('mch_store')
], MchStore);
let MchRate = class MchRate {
};
exports.MchRate = MchRate;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], MchRate.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_no', length: 32 }),
    __metadata("design:type", String)
], MchRate.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'pay_way', length: 32 }),
    __metadata("design:type", String)
], MchRate.prototype, "payWay", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'rate_type', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], MchRate.prototype, "rateType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'rate', type: 'decimal', precision: 6, scale: 4 }),
    __metadata("design:type", Number)
], MchRate.prototype, "rate", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'min_fee', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], MchRate.prototype, "minFee", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'max_fee', type: 'decimal', precision: 18, scale: 2, nullable: true }),
    __metadata("design:type", Number)
], MchRate.prototype, "maxFee", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], MchRate.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], MchRate.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], MchRate.prototype, "updateTime", void 0);
exports.MchRate = MchRate = __decorate([
    (0, typeorm_1.Entity)('mch_rate')
], MchRate);
//# sourceMappingURL=mch.entity.js.map
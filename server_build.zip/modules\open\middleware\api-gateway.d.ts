/**
 * 开放平台 API 网关中间件
 *
 * 职责:
 * 1. 签名验证 (HMAC-SHA256 / RSA / SM2)
 * 2. AppKey 认证
 * 3. IP 白名单校验
 * 4. 限流控制
 * 5. 配额检查
 * 6. API 权限校验
 * 7. 调用日志记录
 */
import { Request, Response, NextFunction } from 'express';
import { OpApp, OpApiKey, OpDeveloper } from '../entity';
declare global {
    namespace Express {
        interface Request {
            opApp?: OpApp;
            opDeveloper?: OpDeveloper;
            opApiKey?: OpApiKey;
            opApiLogId?: string;
        }
    }
}
/**
 * API 网关主中间件
 */
export declare function apiGateway(req: Request, res: Response, next: NextFunction): Promise<void>;
//# sourceMappingURL=api-gateway.d.ts.map
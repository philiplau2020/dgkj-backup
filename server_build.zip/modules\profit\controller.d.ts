import { Request, Response, NextFunction } from 'express';
export declare class ProfitController {
    private groupRepo;
    private receiverRepo;
    private recordRepo;
    private rollbackRepo;
    getAccountGroupList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createAccountGroup(req: Request, res: Response, next: NextFunction): Promise<void>;
    updateAccountGroup(req: Request, res: Response, next: NextFunction): Promise<void>;
    getReceiverList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createReceiver(req: Request, res: Response, next: NextFunction): Promise<void>;
    updateReceiver(req: Request, res: Response, next: NextFunction): Promise<void>;
    getRecordList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createRecord(req: Request, res: Response, next: NextFunction): Promise<void>;
    settleRecord(req: Request, res: Response, next: NextFunction): Promise<void>;
    getRollbackList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createRollback(req: Request, res: Response, next: NextFunction): Promise<void>;
    completeRollback(req: Request, res: Response, next: NextFunction): Promise<void>;
}
declare const _default: ProfitController;
export default _default;
//# sourceMappingURL=controller.d.ts.map
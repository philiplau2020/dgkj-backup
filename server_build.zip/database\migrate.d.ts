/**
 * DGKJ 支付平台 - 数据库迁移脚本
 *
 * 用于创建完整的数据库表结构
 *
 * 使用方法:
 *   npx ts-node src/database/migrate.ts
 *   或者在服务器上执行
 */
export {};
//# sourceMappingURL=migrate.d.ts.map
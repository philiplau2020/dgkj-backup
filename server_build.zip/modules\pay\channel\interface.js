"use strict";
/**
 * DGKJ 支付平台 - 支付通道基础设施
 *
 * 定义统一的支付通道接口，所有第三方支付都实现此接口
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChannelManager = exports.ChannelCode = exports.PayWay = exports.TransferStatus = exports.RefundStatus = exports.PayStatus = void 0;
// ==================== 基础类型定义 ====================
/** 支付结果状态 */
var PayStatus;
(function (PayStatus) {
    PayStatus["PENDING"] = "pending";
    PayStatus["SUCCESS"] = "success";
    PayStatus["FAILED"] = "failed";
    PayStatus["CLOSED"] = "closed";
    PayStatus["REFUNDING"] = "refunding";
    PayStatus["REFUNDED"] = "refunded";
})(PayStatus || (exports.PayStatus = PayStatus = {}));
/** 退款状态 */
var RefundStatus;
(function (RefundStatus) {
    RefundStatus["PENDING"] = "pending";
    RefundStatus["PROCESSING"] = "processing";
    RefundStatus["SUCCESS"] = "success";
    RefundStatus["FAILED"] = "failed";
})(RefundStatus || (exports.RefundStatus = RefundStatus = {}));
/** 转账状态 */
var TransferStatus;
(function (TransferStatus) {
    TransferStatus["PENDING"] = "pending";
    TransferStatus["PROCESSING"] = "processing";
    TransferStatus["SUCCESS"] = "success";
    TransferStatus["FAILED"] = "failed";
})(TransferStatus || (exports.TransferStatus = TransferStatus = {}));
/** 支付方式 */
var PayWay;
(function (PayWay) {
    // 微信
    PayWay["WX_NATIVE"] = "wx_native";
    PayWay["WX_JSAPI"] = "wx_jsapi";
    PayWay["WX_APP"] = "wx_app";
    PayWay["WX_H5"] = "wx_h5";
    PayWay["WX_LITE"] = "wx_lite";
    // 支付宝
    PayWay["ALI_QR"] = "ali_qr";
    PayWay["ALI_JSAPI"] = "ali_jsapi";
    PayWay["ALI_APP"] = "ali_app";
    PayWay["ALI_WAP"] = "ali_wap";
    // 银联
    PayWay["UNION_QR"] = "union_qr";
    PayWay["UNION_JK"] = "union_jk";
    PayWay["UNION_APP"] = "union_app";
    PayWay["UNION_WAP"] = "union_wap";
    PayWay["UNION_BANK"] = "union_bank";
    // 云闪付
    PayWay["YSF_QR"] = "ysf_qr";
    // 银行
    PayWay["BANK_CARD"] = "bank_card";
    // 其他
    PayWay["CASH"] = "cash";
})(PayWay || (exports.PayWay = PayWay = {}));
/** 支付通道编码 */
var ChannelCode;
(function (ChannelCode) {
    ChannelCode["WECHAT"] = "WX";
    ChannelCode["ALIPAY"] = "ALI";
    ChannelCode["UNIONPAY"] = "UNION";
    ChannelCode["UNION"] = "UNION";
    ChannelCode["YSF"] = "YSF";
    ChannelCode["CITIC"] = "CITIC";
})(ChannelCode || (exports.ChannelCode = ChannelCode = {}));
// ==================== 通道管理器 ====================
/**
 * 通道管理器
 * 统一管理所有支付通道
 */
class ChannelManager {
    constructor() {
        this.channels = new Map();
    }
    static getInstance() {
        if (!ChannelManager.instance) {
            ChannelManager.instance = new ChannelManager();
        }
        return ChannelManager.instance;
    }
    /**
     * 注册通道
     * @param channel 支付通道实例
     */
    register(channel) {
        this.channels.set(channel.channelCode, channel);
    }
    /**
     * 获取通道
     * @param channelCode 通道编码
     */
    get(channelCode) {
        return this.channels.get(channelCode);
    }
    /**
     * 获取所有通道
     */
    getAll() {
        return Array.from(this.channels.values());
    }
    /**
     * 根据支付方式获取通道
     * @param payWay 支付方式
     */
    getByPayWay(payWay) {
        for (const channel of this.channels.values()) {
            if (channel.supportedPayWays.includes(payWay)) {
                return channel;
            }
        }
        return undefined;
    }
    /**
     * 移除通道
     * @param channelCode 通道编码
     */
    unregister(channelCode) {
        this.channels.delete(channelCode);
    }
}
exports.ChannelManager = ChannelManager;
exports.default = ChannelManager;
//# sourceMappingURL=interface.js.map
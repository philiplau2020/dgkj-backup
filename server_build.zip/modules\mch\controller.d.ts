import { Request, Response, NextFunction } from 'express';
export declare class MchController {
    private mchRepo;
    private appRepo;
    private storeRepo;
    private rateRepo;
    getMchList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getMchById(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    getMchByMchNo(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    createMch(req: Request, res: Response, next: NextFunction): Promise<void>;
    updateMch(req: Request, res: Response, next: NextFunction): Promise<void>;
    deleteMch(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    reviewMch(req: Request, res: Response, next: NextFunction): Promise<void>;
    enableMch(req: Request, res: Response, next: NextFunction): Promise<void>;
    disableMch(req: Request, res: Response, next: NextFunction): Promise<void>;
    getAppList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createApp(req: Request, res: Response, next: NextFunction): Promise<void>;
    updateApp(req: Request, res: Response, next: NextFunction): Promise<void>;
    getStoreList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getStoreById(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    createStore(req: Request, res: Response, next: NextFunction): Promise<void>;
    updateStore(req: Request, res: Response, next: NextFunction): Promise<void>;
    deleteStore(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    enableStore(req: Request, res: Response, next: NextFunction): Promise<void>;
    disableStore(req: Request, res: Response, next: NextFunction): Promise<void>;
    getRateList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getRateById(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    createRate(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    updateRate(req: Request, res: Response, next: NextFunction): Promise<void>;
    deleteRate(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    enableRate(req: Request, res: Response, next: NextFunction): Promise<void>;
    disableRate(req: Request, res: Response, next: NextFunction): Promise<void>;
    batchCreateRate(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
}
declare const _default: MchController;
export default _default;
//# sourceMappingURL=controller.d.ts.map
/**
 * 中信银行E管家 完整 Controller
 * 实现所有业务功能
 */
import { Request, Response, NextFunction } from 'express';
export declare class CiticController {
    private accountRepo;
    private cardRepo;
    private collectionRepo;
    private profitShareRepo;
    private transferRepo;
    private settlementRepo;
    private checkRepo;
    private recordRepo;
    /**
     * 获取账户信息
     * GET /citic/account/info
     */
    getAccountInfo(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * 账户列表
     * GET /citic/account/list
     */
    getAccountList(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * 获取账户统计
     * GET /citic/account/stats
     */
    getAccountStats(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    /**
     * 账户开户（注册用户）
     * POST /citic/account/register
     */
    registerAccount(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    /**
     * 更新账户
     * PUT /citic/account/:id
     */
    updateAccount(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    /**
     * 余额查询（对接中信银行API）
     * GET /citic/account/balance
     */
    queryBalance(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    /**
     * 银行卡列表
     * GET /citic/card/list
     */
    getCardList(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * 绑定银行卡
     * POST /citic/card/bind
     */
    bindCard(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    /**
     * 解绑银行卡
     * POST /citic/card/unbind
     */
    unbindCard(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    /**
     * 删除银行卡
     * DELETE /citic/card/:id
     */
    deleteCard(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * 归集关系列表
     * GET /citic/collection/list
     */
    getCollectionList(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * 设置归集关系
     * POST /citic/collection/set
     */
    setCollection(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    /**
     * 删除归集关系
     * DELETE /citic/collection/:id
     */
    deleteCollection(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    /**
     * 执行主动归集
     * POST /citic/collection/active
     */
    activeCollection(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    /**
     * 分账记录列表
     * GET /citic/profit-share/list
     */
    getProfitShareList(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * 执行分账
     * POST /citic/profit-share/execute
     */
    executeProfitShare(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    /**
     * 删除分账关系
     * DELETE /citic/profit-share/:id
     */
    deleteProfitShare(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * 代付记录列表
     * GET /citic/transfer/list
     */
    getTransferList(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * 代付下单
     * POST /citic/transfer/pay
     */
    createTransfer(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    /**
     * 代付结果查询
     * GET /citic/transfer/query
     */
    queryTransfer(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    /**
     * 代付成功确认（回调处理）
     * POST /citic/transfer/confirm
     */
    confirmTransfer(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    /**
     * 结算记录列表
     * GET /citic/settlement/list
     */
    getSettlementList(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * 申请结算
     * POST /citic/settlement/apply
     */
    applySettlement(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    /**
     * 确认结算
     * POST /citic/settlement/confirm
     */
    confirmSettlement(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    /**
     * 对账记录列表
     * GET /citic/check/list
     */
    getCheckList(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * 触发对账
     * POST /citic/check/trigger
     */
    triggerCheck(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    /**
     * 下载对账单
     * GET /citic/check/download
     */
    downloadCheckBill(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * 取消结算申请
     * POST /citic/settlement/cancel
     */
    cancelSettlement(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    /**
     * 获取对账差异列表
     * GET /citic/check/diff/list
     */
    getCheckDiffList(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * 确认对账差异
     * POST /citic/check/diff/confirm
     */
    confirmCheckDiff(req: Request, res: Response, next: NextFunction): Promise<void>;
    /**
     * 账户流水列表
     * GET /citic/account/records
     */
    getAccountRecords(req: Request, res: Response, next: NextFunction): Promise<void>;
}
declare const _default: CiticController;
export default _default;
//# sourceMappingURL=controller.d.ts.map
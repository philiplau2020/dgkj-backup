"use strict";
/**
 * DGKJ 支付平台 - 短信通知服务
 *
 * 支持阿里云短信、腾讯云短信等主流短信服务商
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.initializeSmsConfig = initializeSmsConfig;
exports.sendVerificationCode = sendVerificationCode;
exports.sendNotification = sendNotification;
exports.sendMarketing = sendMarketing;
exports.sendBatchSms = sendBatchSms;
exports.validatePhone = validatePhone;
exports.sendCodeWithValidation = sendCodeWithValidation;
const axios_1 = __importDefault(require("axios"));
const crypto_1 = __importDefault(require("crypto"));
const data_source_1 = require("../../config/data-source");
const sys_entity_1 = require("../../database/entities/sys.entity");
// 短信配置
let smsConfig = {
    provider: 'mock',
    signName: 'DGKJ支付',
};
/**
 * 初始化短信配置
 */
async function initializeSmsConfig() {
    try {
        const configRepo = data_source_1.AppDataSource.getRepository(sys_entity_1.SysConfig);
        // 从数据库配置中读取短信配置
        const smsConfigRecord = await configRepo.findOne({
            where: { configKey: 'sms_config' }
        });
        if (smsConfigRecord) {
            const config = JSON.parse(smsConfigRecord.configValue);
            smsConfig = { ...smsConfig, ...config };
        }
        console.log('短信服务已初始化， provider:', smsConfig.provider);
    }
    catch (error) {
        console.error('初始化短信配置失败:', error);
    }
}
/**
 * 发送短信验证码
 */
async function sendVerificationCode(phone, code, expireMinutes = 5) {
    try {
        const template = smsConfig.provider === 'aliyun'
            ? 'SMS_XXX' // 阿里云模板
            : smsConfig.provider === 'tencent'
                ? 'TPL_XXX' // 腾讯云模板
                : 'VERIFY_CODE'; // Mock 模板
        const params = {
            code,
            expire: expireMinutes.toString(),
        };
        return await sendSms(phone, template, params);
    }
    catch (error) {
        return {
            success: false,
            errorCode: 'SEND_FAILED',
            errorMsg: error.message,
        };
    }
}
/**
 * 发送通知短信
 */
async function sendNotification(phone, template, params) {
    return await sendSms(phone, template, params);
}
/**
 * 发送营销短信
 */
async function sendMarketing(phone, template, params) {
    return await sendSms(phone, template, params);
}
/**
 * 批量发送短信
 */
async function sendBatchSms(phones, template, params) {
    const results = [];
    for (const phone of phones) {
        const result = await sendSms(phone, template, params);
        results.push(result);
    }
    return results;
}
/**
 * 核心发送方法
 */
async function sendSms(phone, template, params) {
    switch (smsConfig.provider) {
        case 'aliyun':
            return await sendAliyunSms(phone, template, params);
        case 'tencent':
            return await sendTencentSms(phone, template, params);
        case 'mock':
        default:
            return await sendMockSms(phone, template, params);
    }
}
/**
 * 阿里云短信发送
 */
async function sendAliyunSms(phone, template, params) {
    try {
        const accessKeyId = smsConfig.accessKeyId;
        const accessKeySecret = smsConfig.accessKeySecret;
        if (!accessKeyId || !accessKeySecret) {
            return {
                success: false,
                errorCode: 'CONFIG_ERROR',
                errorMsg: '短信配置不完整',
            };
        }
        const host = 'dysmsapi.aliyuncs.com';
        const path = '/';
        // 构建参数
        const queryParams = {
            AccessKeyId: accessKeyId,
            SignatureMethod: 'HMAC-SHA1',
            SignatureVersion: '1.0',
            SignatureNonce: crypto_1.default.randomBytes(16).toString('hex'),
            Timestamp: new Date().toISOString(),
            Format: 'JSON',
            Action: 'SendSms',
            Version: '2017-05-25',
            PhoneNumbers: phone,
            SignName: smsConfig.signName,
            TemplateCode: template,
            TemplateParam: JSON.stringify(params),
        };
        // 计算签名
        const signature = calculateAliyunSignature(queryParams, accessKeySecret);
        queryParams['Signature'] = signature;
        // 发送请求
        const url = `https://${host}${path}?${buildQueryString(queryParams)}`;
        const response = await axios_1.default.post(url);
        const data = response.data;
        if (data.Code === 'OK') {
            return {
                success: true,
                messageId: data.MessageId,
            };
        }
        else {
            return {
                success: false,
                errorCode: data.Code,
                errorMsg: data.Message,
            };
        }
    }
    catch (error) {
        return {
            success: false,
            errorCode: 'REQUEST_FAILED',
            errorMsg: error.message,
        };
    }
}
/**
 * 腾讯云短信发送
 */
async function sendTencentSms(phone, template, params) {
    try {
        const appId = smsConfig.accessKeyId;
        const appKey = smsConfig.accessKeySecret;
        if (!appId || !appKey) {
            return {
                success: false,
                errorCode: 'CONFIG_ERROR',
                errorMsg: '短信配置不完整',
            };
        }
        const random = Math.floor(Math.random() * 1000000).toString();
        const now = Math.floor(Date.now() / 1000);
        // 拼接签名原文字符串
        const sigText = `appkey=${appKey}&random=${random}&time=${now}&mobile=${phone}`;
        const signature = crypto_1.default.createHash('sha256').update(sigText).digest('hex');
        const url = 'https://yun.tim.qq.com/v5/tlssmssvr/sendsms';
        const body = {
            tel: [{ nationcode: '86', mobile: phone.replace(/^86/, '') }],
            type: 0,
            appid: parseInt(appId),
            sign: smsConfig.signName,
            tpl_id: parseInt(template),
            params: Object.values(params),
            sig: signature,
            time: now,
            random,
        };
        const response = await axios_1.default.post(url, body);
        const data = response.data;
        if (data.result === 0) {
            return {
                success: true,
                messageId: data.sid,
            };
        }
        else {
            return {
                success: false,
                errorCode: data.result.toString(),
                errorMsg: data.errmsg,
            };
        }
    }
    catch (error) {
        return {
            success: false,
            errorCode: 'REQUEST_FAILED',
            errorMsg: error.message,
        };
    }
}
/**
 * Mock 短信发送 (开发环境使用)
 */
async function sendMockSms(phone, template, params) {
    // 开发环境下，直接打印到控制台
    console.log('【MOCK SMS】');
    console.log('  Phone:', phone);
    console.log('  Template:', template);
    console.log('  Params:', params);
    // 模拟网络延迟
    await new Promise(resolve => setTimeout(resolve, 100));
    return {
        success: true,
        messageId: 'MOCK_' + Date.now(),
    };
}
/**
 * 计算阿里云签名
 */
function calculateAliyunSignature(params, secret) {
    // 按字典序排序参数
    const sortedKeys = Object.keys(params).sort();
    const canonicalizedQueryString = sortedKeys
        .map(key => {
        const value = encodeURIComponent(params[key]);
        return `${encodeURIComponent(key)}=${value}`;
    })
        .join('&');
    // 构建待签名字符串
    const stringToSign = `POST&${encodeURIComponent('/')}&${encodeURIComponent(canonicalizedQueryString)}`;
    // 计算 HMAC-SHA1 签名
    const hmac = crypto_1.default.createHmac('sha1', secret + '&');
    hmac.update(stringToSign);
    const signature = hmac.digest('base64');
    return signature;
}
/**
 * 构建查询字符串
 */
function buildQueryString(params) {
    return Object.keys(params)
        .sort()
        .map(key => `${encodeURIComponent(key)}=${encodeURIComponent(params[key])}`)
        .join('&');
}
/**
 * 验证手机号格式
 */
function validatePhone(phone) {
    // 中国大陆手机号格式
    const phoneRegex = /^1[3-9]\d{9}$/;
    return phoneRegex.test(phone);
}
/**
 * 发送短信验证码 (带验证)
 */
async function sendCodeWithValidation(phone, code, expireMinutes = 5) {
    if (!validatePhone(phone)) {
        return {
            success: false,
            errorCode: 'INVALID_PHONE',
            errorMsg: '手机号格式不正确',
        };
    }
    return await sendVerificationCode(phone, code, expireMinutes);
}
exports.default = {
    initializeSmsConfig,
    sendVerificationCode,
    sendNotification,
    sendMarketing,
    sendBatchSms,
    validatePhone,
    sendCodeWithValidation,
};
//# sourceMappingURL=sms.service.js.map
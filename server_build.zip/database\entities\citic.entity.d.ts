/** 账户状态 */
export declare enum CiticAccountStatus {
    DISABLED = 0,
    ENABLED = 1
}
/** 账户类型 */
export declare enum CiticAccountType {
    PERSONAL = 1,// 个人账户
    ENTERPRISE = 2
}
/** 银行卡类型 */
export declare enum CiticCardType {
    PUBLIC = 1,// 对公账户
    PRIVATE = 2
}
/** 银行卡状态 */
export declare enum CiticCardStatus {
    UNBIND = 0,// 已解绑
    BIND = 1,// 已绑定
    FROZEN = 2
}
/** 归集状态 */
export declare enum CiticCollectionStatus {
    PENDING = 0,// 待处理
    SUCCESS = 1,// 成功
    FAILED = 2,// 失败
    PROCESSING = 3
}
/** 分账状态 */
export declare enum CiticProfitShareStatus {
    PENDING = 0,// 待处理
    SUCCESS = 1,// 成功
    FAILED = 2,// 失败
    PROCESSING = 3
}
/** 代付状态 */
export declare enum CiticTransferStatus {
    PENDING = 0,// 待处理
    SUCCESS = 1,// 成功
    FAILED = 2,// 失败
    PROCESSING = 3
}
/** 结算状态 */
export declare enum CiticSettlementStatus {
    PENDING = 0,// 待处理
    PROCESSING = 1,// 处理中
    SUCCESS = 2,// 已结算
    FAILED = 3
}
/** 对账状态 */
export declare enum CiticCheckStatus {
    PENDING = 0,// 待处理
    DIFF = 1,// 有差异
    BALANCED = 2
}
/**
 * 中信银行E管家账户实体
 * 对应中信银行用户账户信息
 */
export declare class CiticAccount {
    id: string;
    /** 中信银行用户唯一标识 */
    bizUserId: string;
    /** 账户编号 */
    accountNo: string;
    /** 账户名称 */
    accountName: string;
    /** 账户类型: 1-个人 2-企业 */
    accountType: number;
    /** 账户属性: 1-普通 2-过渡 3-归集 */
    accountAttr: number;
    /** 总余额 */
    balance: number;
    /** 可用余额 */
    availableBalance: number;
    /** 冻结金额 */
    frozenBalance: number;
    /** 待结算金额 */
    pendingBalance: number;
    /** 账户状态 */
    status: CiticAccountStatus;
    /** 审核状态 */
    auditStatus: number;
    /** 开户渠道 */
    channel: string;
    /** 关联商户号 */
    mchNo: string;
    /** 关联代理商号 */
    agentNo: string;
    /** 备注 */
    remark: string;
    /** 创建时间 */
    createTime: Date;
    /** 更新时间 */
    updateTime: Date;
}
/**
 * 中信银行银行卡实体
 * 对应中信银行用户绑定的银行卡信息
 */
export declare class CiticCard {
    id: string;
    /** 中信银行用户唯一标识 */
    bizUserId: string;
    /** 账户编号 */
    accountNo: string;
    /** 银行卡号 */
    cardNo: string;
    /** 银行卡类型: 1-对公 2-对私 */
    cardType: CiticCardType;
    /** 银行名称 */
    bankName: string;
    /** 银行编码 */
    bankCode: string;
    /** 开户行名称 */
    branchName: string;
    /** 开户行联行号 */
    branchCode: string;
    /** 持卡人姓名 */
    cardHolder: string;
    /** 持卡人证件号 */
    certNo: string;
    /** 持卡人手机号 */
    phone: string;
    /** CVV2 */
    cvv2: string;
    /** 有效期 */
    expireDate: string;
    /** 银行卡状态: 0-已解绑 1-已绑定 2-已冻结 */
    status: CiticCardStatus;
    /** 绑定时间 */
    bindTime: Date;
    /** 解绑时间 */
    unbindTime: Date;
    /** 解绑原因 */
    unbindReason: string;
    /** 备注 */
    remark: string;
    /** 创建时间 */
    createTime: Date;
    /** 更新时间 */
    updateTime: Date;
}
/**
 * 资金归集关系实体
 * 定义账户间的资金归集关系
 */
export declare class CiticCollection {
    id: string;
    /** 归集单号 */
    collectionNo: string;
    /** 子账户编号（被归集的账户） */
    fromAccountNo: string;
    /** 子账户名称 */
    fromAccountName: string;
    /** 主账户编号（归集到的账户） */
    toAccountNo: string;
    /** 主账户名称 */
    toAccountName: string;
    /** 归集类型: 1-全额归集 2-定额归集 3-保留余额归集 */
    collectionType: number;
    /** 归集金额（定额归集时使用） */
    collectionAmount: number;
    /** 保留金额（保留余额归集时使用） */
    reservedAmount: number;
    /** 归集状态: 0-待处理 1-成功 2-失败 3-处理中 */
    status: CiticCollectionStatus;
    /** 关系状态: 0-停用 1-启用 */
    relationStatus: number;
    /** 实际归集金额 */
    collectionAmountReal: number;
    /** 完成时间 */
    completeTime: Date;
    /** 失败原因 */
    failReason: string;
    /** 备注 */
    remark: string;
    /** 创建时间 */
    createTime: Date;
    /** 更新时间 */
    updateTime: Date;
}
/**
 * 余额分账关系实体
 * 定义分账各方及分账比例
 */
export declare class CiticProfitShare {
    id: string;
    /** 分账单号 */
    shareNo: string;
    /** 原订单号 */
    orderNo: string;
    /** 账户编号 */
    accountNo: string;
    /** 账户名称 */
    accountName: string;
    /** 分账接收方账户 */
    receiverAccountNo: string;
    /** 分账接收方名称 */
    receiverName: string;
    /** 分账类型: 1-比例分账 2-金额分账 */
    shareType: number;
    /** 分账比例（百分比，如50.00表示50%） */
    shareRate: number;
    /** 分账金额 */
    shareAmount: number;
    /** 原交易金额 */
    orderAmount: number;
    /** 分账状态: 0-待处理 1-成功 2-失败 3-处理中 */
    status: CiticProfitShareStatus;
    /** 分账时间 */
    shareTime: Date;
    /** 失败原因 */
    failReason: string;
    /** 备注 */
    remark: string;
    /** 创建时间 */
    createTime: Date;
    /** 更新时间 */
    updateTime: Date;
}
/**
 * 代付打款实体
 * 对应中信银行代付业务
 */
export declare class CiticTransfer {
    id: string;
    /** 代付单号 */
    transferNo: string;
    /** 中信银行代付订单号 */
    citicOrderNo: string;
    /** 账户编号 */
    accountNo: string;
    /** 账户名称 */
    accountName: string;
    /** 收款方银行卡号 */
    receiverCardNo: string;
    /** 收款方银行名称 */
    receiverBankName: string;
    /** 收款方银行编码 */
    receiverBankCode: string;
    /** 收款方开户行名称 */
    receiverBranchName: string;
    /** 收款方开户行联行号 */
    receiverBranchCode: string;
    /** 收款方姓名 */
    receiverName: string;
    /** 收款方手机号 */
    receiverPhone: string;
    /** 代付金额 */
    amount: number;
    /** 手续费 */
    fee: number;
    /** 实付金额 */
    actualAmount: number;
    /** 代付类型: 1-直接代付 2-批量代付 3-商户提现 */
    transferType: number;
    /** 代付状态: 0-待处理 1-成功 2-失败 3-处理中 */
    status: CiticTransferStatus;
    /** 成功时间 */
    successTime: Date;
    /** 失败原因 */
    failReason: string;
    /** 回调通知时间 */
    notifyTime: Date;
    /** 备注 */
    remark: string;
    /** 创建时间 */
    createTime: Date;
    /** 更新时间 */
    updateTime: Date;
}
/**
 * 中信银行结算实体
 */
export declare class CiticSettlement {
    id: string;
    /** 结算单号 */
    settleNo: string;
    /** 中信银行结算订单号 */
    citicOrderNo: string;
    /** 账户编号 */
    accountNo: string;
    /** 账户名称 */
    accountName: string;
    /** 结算类型: 1-D0结算 2-T1结算 */
    settleType: number;
    /** 结算金额 */
    amount: number;
    /** 手续费 */
    fee: number;
    /** 实结金额 */
    actualAmount: number;
    /** 目标银行卡号 */
    targetCardNo: string;
    /** 目标银行名称 */
    targetBankName: string;
    /** 目标银行编码 */
    targetBankCode: string;
    /** 目标开户行名称 */
    targetBranchName: string;
    /** 目标开户行联行号 */
    targetBranchCode: string;
    /** 结算状态: 0-待处理 1-处理中 2-已结算 3-已拒绝 */
    status: CiticSettlementStatus;
    /** 结算时间 */
    settleTime: Date;
    /** 完成时间 */
    completeTime: Date;
    /** 失败原因 */
    failReason: string;
    /** 备注 */
    remark: string;
    /** 创建时间 */
    createTime: Date;
    /** 更新时间 */
    updateTime: Date;
}
/**
 * 中信银行对账实体
 */
export declare class CiticCheck {
    id: string;
    /** 对账单号 */
    checkNo: string;
    /** 对账日期 */
    checkDate: Date;
    /** 对账类型: 1-交易对账 2-退款对账 3-结算对账 */
    checkType: number;
    /** 通道编号 */
    channelCode: string;
    /** 通道名称 */
    channelName: string;
    /** 总交易笔数 */
    totalCount: number;
    /** 总交易金额 */
    totalAmount: number;
    /** 成功笔数 */
    successCount: number;
    /** 成功金额 */
    successAmount: number;
    /** 失败笔数 */
    failCount: number;
    /** 失败金额 */
    failAmount: number;
    /** 差异笔数 */
    diffCount: number;
    /** 差异金额 */
    diffAmount: number;
    /** 对账状态: 0-待处理 1-有差异 2-已平账 */
    status: CiticCheckStatus;
    /** 对账单文件路径 */
    filePath: string;
    /** 对账单文件URL */
    fileUrl: string;
    /** 备注 */
    remark: string;
    /** 创建时间 */
    createTime: Date;
    /** 更新时间 */
    updateTime: Date;
}
/**
 * 中信银行账户流水实体
 * 记录账户的所有资金变动
 */
export declare class CiticAccountRecord {
    id: string;
    /** 流水号 */
    recordNo: string;
    /** 账户编号 */
    accountNo: string;
    /** 账户名称 */
    accountName: string;
    /** 业务类型: 1-收入 2-支出 3-冻结 4-解冻 5-归集 6-分账 7-代付 8-结算 */
    bizType: number;
    /** 业务类型名称 */
    bizTypeName: string;
    /** 变动金额 */
    amount: number;
    /** 变动前余额 */
    balanceBefore: number;
    /** 变动后余额 */
    balanceAfter: number;
    /** 关联订单号 */
    orderNo: string;
    /** 对方账户编号 */
    oppositeAccountNo: string;
    /** 对方账户名称 */
    oppositeAccountName: string;
    /** 备注 */
    remark: string;
    /** 创建时间 */
    createTime: Date;
}
//# sourceMappingURL=citic.entity.d.ts.map
"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const controller_1 = __importDefault(require("./controller"));
const auth_middleware_1 = require("../../common/middleware/auth.middleware");
const router = (0, express_1.Router)();
router.post('/login', controller_1.default.login.bind(controller_1.default));
router.post('/logout', auth_middleware_1.authGuard, controller_1.default.logout.bind(controller_1.default));
router.get('/userinfo', auth_middleware_1.authGuard, controller_1.default.getUserInfo.bind(controller_1.default));
router.get('/perm', auth_middleware_1.authGuard, (req, res) => {
    res.json({ code: 0, data: [], message: 'ok' });
});
exports.default = router;
//# sourceMappingURL=routes.js.map
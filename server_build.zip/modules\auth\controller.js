"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthController = void 0;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const data_source_1 = require("../../config/data-source");
const sys_entity_1 = require("../../database/entities/sys.entity");
class AuthController {
    async login(req, res, next) {
        try {
            const { username, password } = req.body;
            const userRepo = data_source_1.AppDataSource.getRepository(sys_entity_1.SysUser);
            const user = await userRepo.findOne({
                where: { username },
            });
            if (!user) {
                return res.status(401).json({
                    code: 401,
                    message: '用户名或密码错误',
                    data: null,
                    timestamp: new Date().toISOString(),
                });
            }
            const isPasswordValid = await bcryptjs_1.default.compare(password, user.password);
            if (!isPasswordValid) {
                return res.status(401).json({
                    code: 401,
                    message: '用户名或密码错误',
                    data: null,
                    timestamp: new Date().toISOString(),
                });
            }
            if (user.status === 0) {
                return res.status(403).json({
                    code: 403,
                    message: '账号已被禁用',
                    data: null,
                    timestamp: new Date().toISOString(),
                });
            }
            const token = jsonwebtoken_1.default.sign({
                userId: user.id,
                username: user.username,
                userType: user.userType,
            }, process.env.JWT_SECRET || 'your-secret-key', { expiresIn: '7d' });
            await userRepo.update(user.id, {
                lastLoginIp: req.ip,
                lastLoginTime: new Date(),
            });
            res.json({
                code: 0,
                message: '登录成功',
                data: {
                    token,
                    userInfo: {
                        id: user.id,
                        username: user.username,
                        nickname: user.nickname,
                        avatar: user.avatar,
                        email: user.email,
                        mobile: user.mobile,
                        userType: user.userType,
                    },
                },
                timestamp: new Date().toISOString(),
            });
        }
        catch (error) {
            next(error);
        }
    }
    async getUserInfo(req, res, next) {
        try {
            const userId = req.user?.userId;
            const userRepo = data_source_1.AppDataSource.getRepository(sys_entity_1.SysUser);
            const user = await userRepo.findOne({
                where: { id: userId },
            });
            if (!user) {
                return res.status(404).json({
                    code: 404,
                    message: '用户不存在',
                    data: null,
                    timestamp: new Date().toISOString(),
                });
            }
            const userRoleRepo = data_source_1.AppDataSource.getRepository('SysUserRole');
            const roleRepo = data_source_1.AppDataSource.getRepository('SysRole');
            const menuRepo = data_source_1.AppDataSource.getRepository('SysMenu');
            const roleMenuRepo = data_source_1.AppDataSource.getRepository('SysRoleMenu');
            const userRoles = await userRoleRepo.find({
                where: { userId },
            });
            const roleIds = userRoles.map((ur) => ur.roleId);
            let roles = [];
            if (roleIds.length > 0) {
                roles = await roleRepo.find({
                    where: roleIds.map((id) => ({ id })),
                });
            }
            let menus = [];
            if (roleIds.length > 0) {
                const roleMenus = await roleMenuRepo.find({
                    where: roleIds.map((id) => ({ roleId: id })),
                });
                const menuIds = [...new Set(roleMenus.map((rm) => rm.menuId))];
                if (menuIds.length > 0) {
                    menus = await menuRepo.find({
                        where: menuIds.map((id) => ({ id })),
                    });
                }
            }
            res.json({
                code: 0,
                message: '获取成功',
                data: {
                    userInfo: {
                        id: user.id,
                        username: user.username,
                        nickname: user.nickname,
                        avatar: user.avatar,
                        email: user.email,
                        mobile: user.mobile,
                        userType: user.userType,
                    },
                    roles: roles.map((r) => r.roleCode),
                    permissions: menus.filter((m) => m.perms).map((m) => m.perms),
                    menuList: menus,
                },
                timestamp: new Date().toISOString(),
            });
        }
        catch (error) {
            next(error);
        }
    }
    async logout(req, res, next) {
        try {
            res.json({
                code: 0,
                message: '退出成功',
                data: null,
                timestamp: new Date().toISOString(),
            });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.AuthController = AuthController;
exports.default = new AuthController();
//# sourceMappingURL=controller.js.map
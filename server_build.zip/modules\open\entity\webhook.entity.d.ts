export declare class OpWebhook {
    id: string;
    appId: string;
    developerId: string;
    mchNo: string;
    eventType: 'payment' | 'refund' | 'transfer' | 'account' | 'alert';
    callbackUrl: string;
    status: 'active' | 'disabled';
    secretKey: string;
    totalSent: number;
    successCount: number;
    failCount: number;
    lastSentTime: Date;
    lastResponseCode: number;
    lastResponseMsg: string;
    createTime: Date;
    updateTime: Date;
}
//# sourceMappingURL=webhook.entity.d.ts.map
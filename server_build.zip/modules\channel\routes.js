"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const controller_1 = __importDefault(require("./controller"));
const auth_middleware_1 = require("../../common/middleware/auth.middleware");
const router = (0, express_1.Router)();
router.use(auth_middleware_1.authGuard);
// ========== Routes for /basic-api/channel/* ==========
// Channel list
router.get('/list', controller_1.default.getChannelList.bind(controller_1.default));
router.get('/channel/list', controller_1.default.getChannelList.bind(controller_1.default));
// MCH routes (frontend uses /channel/mch/*)
router.get('/mch/list', controller_1.default.getChannelMchList.bind(controller_1.default));
router.post('/mch', controller_1.default.createChannelMch.bind(controller_1.default));
router.put('/mch/:id', controller_1.default.updateChannelMch.bind(controller_1.default));
router.delete('/mch/:id', controller_1.default.deleteChannelMch.bind(controller_1.default));
// Channel MCH (legacy)
router.get('/channel-mch/list', controller_1.default.getChannelMchList.bind(controller_1.default));
router.post('/channel-mch', controller_1.default.createChannelMch.bind(controller_1.default));
// Route rules
router.get('/route/list', controller_1.default.getRouteList.bind(controller_1.default));
router.post('/route', controller_1.default.createRoute.bind(controller_1.default));
router.put('/route/:id', controller_1.default.updateRoute.bind(controller_1.default));
// Strategy routes
router.get('/strategy/list', controller_1.default.getStrategyList.bind(controller_1.default));
router.post('/strategy', controller_1.default.createStrategy.bind(controller_1.default));
router.put('/strategy/:id', controller_1.default.updateStrategy.bind(controller_1.default));
// Pool routes (works when mounted at /basic-api/pool)
router.get('/channel/list', controller_1.default.getPoolList.bind(controller_1.default));
router.get('/channel/info', controller_1.default.getChannelById.bind(controller_1.default));
router.get('/channel/stats', controller_1.default.getChannelStats.bind(controller_1.default));
router.post('/channel/add', controller_1.default.createPool.bind(controller_1.default));
router.get('/list', controller_1.default.getPoolList.bind(controller_1.default));
// ========== Routes for /basic-api/pool/* (when mounted separately) ==========
// These work when poolRoutes is mounted at /basic-api/pool
// Parameterized routes
router.get('/channel/:id', controller_1.default.getChannelById.bind(controller_1.default));
router.put('/channel/:id', controller_1.default.updateChannel.bind(controller_1.default));
// Other routes
router.get('/channel/recommend', controller_1.default.getRecommendedChannel.bind(controller_1.default));
router.get('/channel/stats', controller_1.default.getChannelStats.bind(controller_1.default));
router.get('/recommend', controller_1.default.getRecommendedChannel.bind(controller_1.default));
exports.default = router;
//# sourceMappingURL=routes.js.map
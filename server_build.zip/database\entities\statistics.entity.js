"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatFinance = exports.StatChannel = exports.StatAgent = exports.StatMch = exports.StatTrade = exports.StatisticsPeriod = void 0;
const typeorm_1 = require("typeorm");
var StatisticsPeriod;
(function (StatisticsPeriod) {
    StatisticsPeriod[StatisticsPeriod["DAILY"] = 1] = "DAILY";
    StatisticsPeriod[StatisticsPeriod["WEEKLY"] = 2] = "WEEKLY";
    StatisticsPeriod[StatisticsPeriod["MONTHLY"] = 3] = "MONTHLY";
})(StatisticsPeriod || (exports.StatisticsPeriod = StatisticsPeriod = {}));
let StatTrade = class StatTrade {
};
exports.StatTrade = StatTrade;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], StatTrade.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'stat_date', type: 'date' }),
    __metadata("design:type", Date)
], StatTrade.prototype, "statDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'stat_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], StatTrade.prototype, "statType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_no', length: 32, nullable: true }),
    __metadata("design:type", String)
], StatTrade.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'agent_no', length: 32, nullable: true }),
    __metadata("design:type", String)
], StatTrade.prototype, "agentNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_code', length: 32, nullable: true }),
    __metadata("design:type", String)
], StatTrade.prototype, "channelCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'pay_type', length: 32, nullable: true }),
    __metadata("design:type", String)
], StatTrade.prototype, "payType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], StatTrade.prototype, "totalCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'success_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], StatTrade.prototype, "successCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fail_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], StatTrade.prototype, "failCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatTrade.prototype, "totalAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'success_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatTrade.prototype, "successAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fail_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatTrade.prototype, "failAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'refund_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], StatTrade.prototype, "refundCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'refund_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatTrade.prototype, "refundAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fee_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatTrade.prototype, "feeAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'profit_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatTrade.prototype, "profitAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], StatTrade.prototype, "createTime", void 0);
exports.StatTrade = StatTrade = __decorate([
    (0, typeorm_1.Entity)('stat_trade')
], StatTrade);
let StatMch = class StatMch {
};
exports.StatMch = StatMch;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], StatMch.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'stat_date', type: 'date' }),
    __metadata("design:type", Date)
], StatMch.prototype, "statDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_no', length: 32 }),
    __metadata("design:type", String)
], StatMch.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_name', length: 128 }),
    __metadata("design:type", String)
], StatMch.prototype, "mchName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'agent_no', length: 32, nullable: true }),
    __metadata("design:type", String)
], StatMch.prototype, "agentNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], StatMch.prototype, "totalCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'success_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], StatMch.prototype, "successCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatMch.prototype, "totalAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'success_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatMch.prototype, "successAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fee_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatMch.prototype, "feeAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'refund_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], StatMch.prototype, "refundCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'refund_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatMch.prototype, "refundAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], StatMch.prototype, "createTime", void 0);
exports.StatMch = StatMch = __decorate([
    (0, typeorm_1.Entity)('stat_mch')
], StatMch);
let StatAgent = class StatAgent {
};
exports.StatAgent = StatAgent;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], StatAgent.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'stat_date', type: 'date' }),
    __metadata("design:type", Date)
], StatAgent.prototype, "statDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'agent_no', length: 32 }),
    __metadata("design:type", String)
], StatAgent.prototype, "agentNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'agent_name', length: 128 }),
    __metadata("design:type", String)
], StatAgent.prototype, "agentName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'parent_id', length: 64, nullable: true }),
    __metadata("design:type", String)
], StatAgent.prototype, "parentId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mch_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], StatAgent.prototype, "mchCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_trade_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], StatAgent.prototype, "totalTradeCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'success_trade_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], StatAgent.prototype, "successTradeCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_trade_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatAgent.prototype, "totalTradeAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'success_trade_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatAgent.prototype, "successTradeAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'profit_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatAgent.prototype, "profitAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'withdraw_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatAgent.prototype, "withdrawAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'balance', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatAgent.prototype, "balance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], StatAgent.prototype, "createTime", void 0);
exports.StatAgent = StatAgent = __decorate([
    (0, typeorm_1.Entity)('stat_agent')
], StatAgent);
let StatChannel = class StatChannel {
};
exports.StatChannel = StatChannel;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], StatChannel.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'stat_date', type: 'date' }),
    __metadata("design:type", Date)
], StatChannel.prototype, "statDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_code', length: 32 }),
    __metadata("design:type", String)
], StatChannel.prototype, "channelCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_name', length: 128 }),
    __metadata("design:type", String)
], StatChannel.prototype, "channelName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'pay_type', length: 32, nullable: true }),
    __metadata("design:type", String)
], StatChannel.prototype, "payType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], StatChannel.prototype, "totalCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'success_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], StatChannel.prototype, "successCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatChannel.prototype, "totalAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'success_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatChannel.prototype, "successAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fee_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatChannel.prototype, "feeAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'success_rate', type: 'decimal', precision: 6, scale: 4, default: 0 }),
    __metadata("design:type", Number)
], StatChannel.prototype, "successRate", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], StatChannel.prototype, "createTime", void 0);
exports.StatChannel = StatChannel = __decorate([
    (0, typeorm_1.Entity)('stat_channel')
], StatChannel);
let StatFinance = class StatFinance {
};
exports.StatFinance = StatFinance;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], StatFinance.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'stat_date', type: 'date' }),
    __metadata("design:type", Date)
], StatFinance.prototype, "statDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_income', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatFinance.prototype, "totalIncome", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_expense', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatFinance.prototype, "totalExpense", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'net_income', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatFinance.prototype, "netIncome", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_balance', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatFinance.prototype, "totalBalance", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'settle_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatFinance.prototype, "settleAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'withdraw_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatFinance.prototype, "withdrawAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'profit_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], StatFinance.prototype, "profitAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], StatFinance.prototype, "createTime", void 0);
exports.StatFinance = StatFinance = __decorate([
    (0, typeorm_1.Entity)('stat_finance')
], StatFinance);
//# sourceMappingURL=statistics.entity.js.map
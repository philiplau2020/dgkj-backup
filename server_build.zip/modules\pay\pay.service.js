"use strict";
/**
 * DGKJ 支付平台 - 支付核心服务
 *
 * 统一的支付服务，处理所有支付请求
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PayService = void 0;
const uuid_1 = require("uuid");
const dayjs_1 = __importDefault(require("dayjs"));
const data_source_1 = require("../../config/data-source");
const entities_1 = require("../../database/entities");
const mch_entity_1 = require("../../database/entities/mch.entity");
const channel_entity_1 = require("../../database/entities/channel.entity");
const interface_1 = require("./channel/interface");
const wechat_1 = __importDefault(require("./channel/wechat"));
const alipay_1 = __importDefault(require("./channel/alipay"));
const webhook_service_1 = require("./webhook.service");
const op_code_1 = require("../../utils/op-code");
// 初始化通道管理器
const channelManager = interface_1.ChannelManager.getInstance();
channelManager.register(wechat_1.default);
channelManager.register(alipay_1.default);
/**
 * 支付服务
 */
class PayService {
    constructor() {
        this.orderRepo = data_source_1.AppDataSource.getRepository(entities_1.PayOrder);
        this.refundRepo = data_source_1.AppDataSource.getRepository(entities_1.RefundOrder);
        this.transferRepo = data_source_1.AppDataSource.getRepository(entities_1.TransferOrder);
        this.notifyRepo = data_source_1.AppDataSource.getRepository(entities_1.TradeNotify);
        this.mchRepo = data_source_1.AppDataSource.getRepository(mch_entity_1.MchInfo);
        this.appRepo = data_source_1.AppDataSource.getRepository(mch_entity_1.MchApp);
        this.channelRepo = data_source_1.AppDataSource.getRepository(channel_entity_1.ChannelInfo);
        this.rateRepo = data_source_1.AppDataSource.getRepository(mch_entity_1.MchRate);
    }
    /**
     * 创建支付订单
     */
    async createOrder(params) {
        // 1. 验证商户和应用
        const mch = await this.mchRepo.findOne({ where: { mchNo: params.mchNo } });
        if (!mch) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_MCH_NOT_EXIST, null, '商户不存在');
        }
        if (mch.status !== 1) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_MCH_STATUS_ABNORMAL, null, '商户状态异常');
        }
        const app = await this.appRepo.findOne({ where: { appId: params.appId, mchNo: params.mchNo } });
        if (!app) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_APP_NOT_EXIST, null, '应用不存在');
        }
        if (app.status !== 1) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_APP_STATUS_ABNORMAL, null, '应用状态异常');
        }
        // 2. 获取商户费率
        const rate = await this.rateRepo.findOne({ where: { mchNo: params.mchNo, payWay: params.payWay } });
        const feeRate = rate ? parseFloat(rate.rate.toString()) : 0.006; // 默认 0.6%
        const fee = Math.ceil(params.amount * feeRate);
        const minFee = rate?.minFee ? parseFloat(rate.minFee.toString()) : 0;
        const actualFee = Math.max(fee, minFee);
        // 3. 获取可用通道
        const channel = await this.selectChannel(params.payWay, params.amount);
        if (!channel) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_CHANNEL_NOT_AVAILABLE, null, '暂无可用支付通道');
        }
        // 4. 生成订单号
        const orderId = (0, uuid_1.v4)();
        const orderNo = this.generateOrderNo();
        // 5. 创建订单记录
        const order = this.orderRepo.create({
            id: orderId,
            orderNo,
            mchNo: params.mchNo,
            mchName: mch.mchName,
            appId: params.appId,
            channelCode: channel.channelCode,
            payType: params.payWay,
            amount: params.amount,
            actualAmount: params.amount,
            fee: actualFee,
            subject: params.subject,
            body: params.body || params.subject,
            clientIp: params.clientIp,
            attach: params.attach,
            notifyUrl: params.notifyUrl || app.notifyUrl,
            status: 0, // PENDING
            expireTime: new Date(Date.now() + 2 * 60 * 60 * 1000), // 2小时
            createTime: new Date(),
        });
        await this.orderRepo.save(order);
        // 6. 调用通道发起支付
        const payRequest = {
            orderNo,
            amount: params.amount,
            payWay: params.payWay,
            subject: params.subject,
            body: params.body,
            clientIp: params.clientIp,
            notifyUrl: `${process.env.PAY_CALLBACK_URL || 'https://dghs.gddogootech.com'}/basic-api/pay/callback/${channel.channelCode}`,
            returnUrl: params.returnUrl,
            attach: params.attach,
            openId: params.openId,
            buyerId: params.buyerId,
        };
        const payResult = await channel.pay(payRequest);
        if (!payResult.success) {
            // 更新订单状态为失败
            await this.orderRepo.update(orderId, {
                status: 2, // FAILED
                remark: payResult.errorMsg,
            });
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_PAY_CREATE_FAILED, null, payResult.errorMsg || '支付创建失败');
        }
        // 7. 更新通道订单号
        if (payResult.channelOrderNo) {
            await this.orderRepo.update(orderId, {
                channelOrderNo: payResult.channelOrderNo,
            });
        }
        // 8. 返回支付参数
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
            orderNo,
            amount: params.amount,
            fee: actualFee,
            payWay: params.payWay,
            status: 'pending',
            payUrl: payResult.payUrl,
            qrCode: payResult.qrCode,
            jsapiParams: payResult.jsapiParams,
            appParams: payResult.appParams,
            h5Url: payResult.h5Url,
            deeplink: payResult.deeplink,
            expireTime: order.expireTime,
        });
    }
    /**
     * 查询订单
     */
    async queryOrder(orderNo) {
        const order = await this.orderRepo.findOne({ where: { orderNo } });
        if (!order) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_ORDER_NOT_FOUND, null, '订单不存在');
        }
        // 如果订单已成功或失败，直接返回
        if (order.status === 1 || order.status === 2) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, this.formatOrder(order));
        }
        // 查询通道状态
        const channel = channelManager.get(order.channelCode);
        if (channel) {
            const queryResult = await channel.query({ orderNo: order.orderNo });
            if (queryResult.success && queryResult.status !== 'pending') {
                // 更新订单状态
                const statusMap = {
                    'pending': 0,
                    'success': 1,
                    'failed': 2,
                    'closed': 3,
                    'refunding': 4,
                    'refunded': 5,
                };
                const newStatus = statusMap[queryResult.status] ?? 0;
                await this.orderRepo.update(order.id, {
                    status: newStatus,
                    channelOrderNo: queryResult.channelOrderNo || order.channelOrderNo,
                    payTime: queryResult.paidTime,
                });
                order.status = newStatus;
                order.payTime = queryResult.paidTime;
            }
        }
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, this.formatOrder(order));
    }
    /**
     * 关闭订单
     */
    async closeOrder(orderNo) {
        const order = await this.orderRepo.findOne({ where: { orderNo } });
        if (!order) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_ORDER_NOT_FOUND, null, '订单不存在');
        }
        if (order.status !== 0) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_ORDER_STATUS_ERROR, null, '订单状态不允许关闭');
        }
        // 调用通道关闭订单
        const channel = channelManager.get(order.channelCode);
        if (channel) {
            await channel.query({ orderNo: order.orderNo });
        }
        // 更新订单状态
        await this.orderRepo.update(order.id, {
            status: 3, // CLOSED
        });
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, { orderNo, status: 'closed' });
    }
    /**
     * 申请退款
     */
    async applyRefund(params) {
        const order = await this.orderRepo.findOne({ where: { orderNo: params.orderNo } });
        if (!order) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_ORDER_NOT_FOUND, null, '订单不存在');
        }
        if (order.status !== 1) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_ORDER_STATUS_ERROR, null, '订单未支付，无法退款');
        }
        if (params.refundAmount > order.amount) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_REFUND_EXCEED, null, '退款金额超过订单金额');
        }
        // 检查是否有进行中的退款
        const existingRefund = await this.refundRepo.findOne({
            where: { orderNo: params.orderNo },
        });
        if (existingRefund && existingRefund.status === 0) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.BIZ_REFUND_EXISTS, null, '存在进行中的退款申请');
        }
        // 生成退款单号
        const refundId = (0, uuid_1.v4)();
        const refundNo = this.generateRefundNo();
        // 创建退款记录
        const refund = this.refundRepo.create({
            id: refundId,
            refundNo,
            orderNo: params.orderNo,
            mchNo: order.mchNo,
            appId: order.appId,
            channelCode: order.channelCode,
            payType: order.payType,
            amount: order.amount,
            refundAmount: params.refundAmount,
            refundReason: params.refundReason,
            status: 0, // PENDING
            createTime: new Date(),
            updateTime: new Date(),
        });
        await this.refundRepo.save(refund);
        // 更新原订单状态
        await this.orderRepo.update(order.id, {
            status: 4, // REFUNDING
        });
        // 调用通道退款
        const channel = channelManager.get(order.channelCode);
        if (channel) {
            const refundResult = await channel.refund({
                refundNo,
                orderNo: order.orderNo,
                channelOrderNo: order.channelOrderNo || undefined,
                refundAmount: params.refundAmount,
                reason: params.refundReason,
            });
            if (refundResult.success) {
                await this.refundRepo.update(refundId, {
                    status: 1, // SUCCESS
                    channelRefundNo: refundResult.channelRefundNo,
                    refundTime: refundResult.refundTime,
                });
            }
            else {
                await this.refundRepo.update(refundId, {
                    status: 2, // FAILED
                    remark: refundResult.errorMsg,
                });
            }
        }
        // 发送商户通知
        if (order.notifyUrl) {
            await this.sendMchNotify(order, 'refund');
        }
        return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
            refundNo,
            orderNo: params.orderNo,
            refundAmount: params.refundAmount,
            status: 'pending',
        });
    }
    /**
     * 支付回调处理
     */
    async handleCallback(channelCode, data) {
        const channel = channelManager.get(channelCode);
        if (!channel) {
            return { success: false, message: '通道不存在' };
        }
        // 1. 验证签名
        const verifyResult = await channel.verifyCallback(data, {});
        if (!verifyResult.success) {
            return { success: false, message: verifyResult.errorMsg };
        }
        // 2. 解析回调数据
        const callbackData = await channel.parseCallback(data);
        // 3. 更新订单状态
        if (callbackData.notifyType === 'pay') {
            await this.handlePayCallback(callbackData);
        }
        else if (callbackData.notifyType === 'refund') {
            await this.handleRefundCallback(callbackData);
        }
        return { success: true, message: '处理成功' };
    }
    /**
     * 处理支付回调
     */
    async handlePayCallback(data) {
        const order = await this.orderRepo.findOne({ where: { orderNo: data.orderNo } });
        if (!order)
            return;
        if (data.status === 'success') {
            // 更新订单为成功
            await this.orderRepo.update(order.id, {
                status: 1, // SUCCESS
                channelOrderNo: data.channelOrderNo,
                payTime: data.paidTime || new Date(),
                actualAmount: data.paidAmount || order.amount,
            });
            // 计算分润 (待实现)
            // await this.calculateProfit(order);
            // 发送商户通知
            await this.sendMchNotify(order, 'pay');
        }
        else if (data.status === 'failed' || data.status === 'closed') {
            const failStatus = data.status === 'failed' ? 2 : 3;
            await this.orderRepo.update(order.id, {
                status: failStatus,
            });
        }
    }
    /**
     * 处理退款回调
     */
    async handleRefundCallback(data) {
        const refund = await this.refundRepo.findOne({ where: { refundNo: data.orderNo } });
        if (!refund)
            return;
        if (data.status === 'success') {
            await this.refundRepo.update(refund.id, {
                status: 1, // SUCCESS
                channelRefundNo: data.channelOrderNo,
                refundTime: data.paidTime || new Date(),
            });
            // 更新原订单状态
            const order = await this.orderRepo.findOne({ where: { orderNo: refund.orderNo } });
            if (order) {
                await this.orderRepo.update(order.id, {
                    status: 5, // REFUNDED
                });
            }
        }
    }
    /**
     * 发送商户通知
     */
    async sendMchNotify(order, type) {
        if (!order.notifyUrl)
            return;
        const notifyData = {
            type,
            orderNo: order.orderNo,
            mchNo: order.mchNo,
            amount: order.amount,
            status: order.status === 1 ? 'paid' : 'refunded',
            paidTime: order.payTime ? String(order.payTime) : undefined,
            attach: order.attach,
        };
        // 发送 webhook
        await (0, webhook_service_1.sendWebhookNotification)(order.notifyUrl, notifyData);
        // 记录通知日志
        const notify = this.notifyRepo.create({
            id: (0, uuid_1.v4)(),
            notifyId: (0, uuid_1.v4)(),
            orderNo: order.orderNo,
            mchNo: order.mchNo,
            appId: order.appId,
            notifyUrl: order.notifyUrl,
            notifyType: type === 'pay' ? 1 : 2,
            status: 0,
            createTime: new Date(),
        });
        await this.notifyRepo.save(notify);
    }
    /**
     * 选择支付通道
     */
    async selectChannel(payWay, amount) {
        // 根据支付方式选择通道
        const channelMap = {
            wx_native: interface_1.ChannelCode.WECHAT,
            wx_jsapi: interface_1.ChannelCode.WECHAT,
            wx_app: interface_1.ChannelCode.WECHAT,
            wx_h5: interface_1.ChannelCode.WECHAT,
            ali_qr: interface_1.ChannelCode.ALIPAY,
            ali_jsapi: interface_1.ChannelCode.ALIPAY,
            ali_app: interface_1.ChannelCode.ALIPAY,
            ali_wap: interface_1.ChannelCode.ALIPAY,
        };
        const channelCode = channelMap[payWay];
        if (!channelCode)
            return null;
        const channel = channelManager.get(channelCode);
        if (!channel)
            return null;
        // TODO: 从数据库获取通道配置并初始化
        // 目前返回默认通道
        return channel;
    }
    /**
     * 生成订单号
     */
    generateOrderNo() {
        return `P${(0, dayjs_1.default)().format('YYYYMMDDHHmmss')}${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
    }
    /**
     * 生成退款单号
     */
    generateRefundNo() {
        return `R${(0, dayjs_1.default)().format('YYYYMMDDHHmmss')}${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
    }
    /**
     * 格式化订单
     */
    formatOrder(order) {
        const statusMap = {
            0: 'pending',
            1: 'paid',
            2: 'failed',
            3: 'closed',
            4: 'refunding',
            5: 'refunded',
        };
        return {
            orderNo: order.orderNo,
            mchNo: order.mchNo,
            mchName: order.mchName,
            appId: order.appId,
            payWay: order.payType,
            amount: order.amount,
            actualAmount: order.actualAmount,
            fee: order.fee,
            status: statusMap[order.status] || 'unknown',
            subject: order.subject,
            attach: order.attach,
            channelOrderNo: order.channelOrderNo,
            paidTime: order.payTime,
            createTime: order.createTime,
            expireTime: order.expireTime,
        };
    }
}
exports.PayService = PayService;
exports.default = new PayService();
//# sourceMappingURL=pay.service.js.map
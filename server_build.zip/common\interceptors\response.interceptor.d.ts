import { Request, Response, NextFunction } from 'express';
export declare function responseInterceptor(req: Request, res: Response, next: NextFunction): void;
//# sourceMappingURL=response.interceptor.d.ts.map
/**
 * DGKJ 支付平台 - 单元测试
 *
 * 使用 Jest 进行测试
 */
export declare function createMockRequest(overrides?: {}): {
    headers: {};
    query: {};
    body: {};
    params: {};
    ip: string;
    socket: {
        remoteAddress: string;
    };
};
export declare function createMockResponse(): any;
export declare function createMockNext(): any;
/**
 * 邮件服务测试
 */
export declare function testEmailService(): Promise<void>;
/**
 * 短信服务测试
 */
export declare function testSmsService(): Promise<void>;
/**
 * 缓存服务测试
 */
export declare function testCacheService(): Promise<void>;
/**
 * 消息队列测试
 */
export declare function testQueueService(): Promise<void>;
/**
 * 签名服务测试
 */
export declare function testSignatureService(): Promise<void>;
/**
 * 钉钉通知测试
 */
export declare function testDingTalkService(): Promise<void>;
/**
 * 企业微信通知测试
 */
export declare function testWeComService(): Promise<void>;
/**
 * 支付服务测试
 */
export declare function testPayService(): Promise<void>;
export declare function runAllTests(): Promise<void>;
//# sourceMappingURL=index.test.d.ts.map
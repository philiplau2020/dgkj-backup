"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 开放平台管理后台 API (/basic-api/open/*)
 */
const express_1 = require("express");
const auth_middleware_1 = require("../../../common/middleware/auth.middleware");
const open_platform_service_1 = require("../service/open-platform.service");
const data_source_1 = require("../../../config/data-source");
const entity_1 = require("../entity");
const op_code_1 = require("../../../utils/op-code");
const router = (0, express_1.Router)();
// 所有管理接口需要登录
router.use(auth_middleware_1.authGuard);
// ==================== 开发者管理 ====================
// 开发者列表
router.get('/developer/list', async (req, res, next) => {
    try {
        const result = await open_platform_service_1.developerService.list({
            page: parseInt(req.query.page) || 1,
            pageSize: parseInt(req.query.pageSize) || 10,
            keyword: req.query.keyword,
            status: req.query.status,
            level: req.query.level,
        });
        res.json((0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, result));
    }
    catch (e) {
        next(e);
    }
});
// 开发者详情
router.get('/developer/:developerId', async (req, res, next) => {
    try {
        const info = await open_platform_service_1.developerService.getInfo(req.params.developerId);
        if (!info)
            return res.status(404).json((0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, '开发者不存在'));
        res.json((0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, info));
    }
    catch (e) {
        next(e);
    }
});
// 审核开发者
router.post('/developer/:developerId/review', async (req, res, next) => {
    try {
        const { status, remark } = req.body;
        const result = await open_platform_service_1.developerService.review(req.params.developerId, status, req.user?.username || 'admin', remark);
        res.json(result);
    }
    catch (e) {
        next(e);
    }
});
// 更新开发者等级
router.post('/developer/:developerId/level', async (req, res, next) => {
    try {
        const { level } = req.body;
        const result = await open_platform_service_1.developerService.updateLevel(req.params.developerId, level);
        res.json(result);
    }
    catch (e) {
        next(e);
    }
});
// ==================== 应用管理 ====================
// 应用列表
router.get('/app/list', async (req, res, next) => {
    try {
        const { page = 1, pageSize = 10, keyword, status, developerId } = req.query;
        const appRepo = data_source_1.AppDataSource.getRepository(entity_1.OpApp);
        const queryBuilder = appRepo.createQueryBuilder('app');
        if (developerId)
            queryBuilder.andWhere('app.developerId = :developerId', { developerId });
        if (keyword)
            queryBuilder.andWhere('app.appName LIKE :keyword', { keyword: `%${keyword}%` });
        if (status)
            queryBuilder.andWhere('app.status = :status', { status });
        const [list, total] = await queryBuilder
            .skip((Number(page) - 1) * Number(pageSize))
            .take(Number(pageSize))
            .orderBy('app.createTime', 'DESC')
            .getManyAndCount();
        res.json((0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, { list, total }));
    }
    catch (e) {
        next(e);
    }
});
// 应用详情
router.get('/app/:appId', async (req, res, next) => {
    try {
        const app = await data_source_1.AppDataSource.getRepository(entity_1.OpApp).findOne({ where: { appId: req.params.appId } });
        if (!app)
            return res.status(404).json((0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, '应用不存在'));
        res.json((0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, app));
    }
    catch (e) {
        next(e);
    }
});
// 审核应用
router.post('/app/:appId/review', async (req, res, next) => {
    try {
        const { status } = req.body;
        const result = await open_platform_service_1.appService.review(req.params.appId, status, req.user?.username);
        res.json(result);
    }
    catch (e) {
        next(e);
    }
});
// ==================== API 调用日志 ====================
// 日志列表
router.get('/log/list', async (req, res, next) => {
    try {
        const { page = 1, pageSize = 20, appId, developerId, apiPath, result, startDate, endDate } = req.query;
        const queryBuilder = data_source_1.AppDataSource.getRepository(entity_1.OpApiLog).createQueryBuilder('log');
        if (appId)
            queryBuilder.andWhere('log.appId = :appId', { appId });
        if (developerId)
            queryBuilder.andWhere('log.developerId = :developerId', { developerId });
        if (apiPath)
            queryBuilder.andWhere('log.apiPath LIKE :apiPath', { apiPath: `%${apiPath}%` });
        if (result)
            queryBuilder.andWhere('log.result = :result', { result });
        if (startDate)
            queryBuilder.andWhere('log.createTime >= :startDate', { startDate });
        if (endDate)
            queryBuilder.andWhere('log.createTime <= :endDate', { endDate });
        const [list, total] = await queryBuilder
            .skip((Number(page) - 1) * Number(pageSize))
            .take(Number(pageSize))
            .orderBy('log.createTime', 'DESC')
            .getManyAndCount();
        res.json((0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, { list, total }));
    }
    catch (e) {
        next(e);
    }
});
// 日志统计
router.get('/log/statistics', async (req, res, next) => {
    try {
        const logRepo = data_source_1.AppDataSource.getRepository(entity_1.OpApiLog);
        const [todayTotal, todayError, todaySuccess] = await Promise.all([
            logRepo.createQueryBuilder('log')
                .where('DATE(log.createTime) = CURDATE()').getCount(),
            logRepo.createQueryBuilder('log')
                .where('DATE(log.createTime) = CURDATE() AND log.result = :result', { result: 'error' }).getCount(),
            logRepo.createQueryBuilder('log')
                .where('DATE(log.createTime) = CURDATE() AND log.result = :result', { result: 'success' }).getCount(),
        ]);
        const topApis = await logRepo.createQueryBuilder('log')
            .select('log.apiPath', 'apiPath')
            .addSelect('COUNT(*)', 'count')
            .groupBy('log.apiPath')
            .orderBy('count', 'DESC')
            .limit(10)
            .getRawMany();
        const topApps = await logRepo.createQueryBuilder('log')
            .select('log.appId', 'appId')
            .addSelect('COUNT(*)', 'count')
            .groupBy('log.appId')
            .orderBy('count', 'DESC')
            .limit(10)
            .getRawMany();
        res.json((0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
            today: { total: todayTotal, error: todayError, success: todaySuccess },
            topApis,
            topApps,
        }));
    }
    catch (e) {
        next(e);
    }
});
// ==================== Webhook 管理 ====================
// 获取 Webhook 列表
router.get('/webhook/list', async (req, res, next) => {
    try {
        const { appId, eventType, status } = req.query;
        const queryBuilder = data_source_1.AppDataSource.getRepository(entity_1.OpWebhook).createQueryBuilder('wh');
        if (appId)
            queryBuilder.andWhere('wh.appId = :appId', { appId });
        if (eventType)
            queryBuilder.andWhere('wh.eventType = :eventType', { eventType });
        if (status)
            queryBuilder.andWhere('wh.status = :status', { status });
        const [list, total] = await queryBuilder
            .orderBy('wh.createTime', 'DESC')
            .getManyAndCount();
        res.json((0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, { list, total }));
    }
    catch (e) {
        next(e);
    }
});
// 创建 Webhook
router.post('/webhook', async (req, res, next) => {
    try {
        const webhook = data_source_1.AppDataSource.getRepository(entity_1.OpWebhook).create({
            ...req.body,
            developerId: req.body.developerId || '',
        });
        await data_source_1.AppDataSource.getRepository(entity_1.OpWebhook).save(webhook);
        res.json((0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, webhook));
    }
    catch (e) {
        next(e);
    }
});
// 更新 Webhook
router.put('/webhook/:id', async (req, res, next) => {
    try {
        await data_source_1.AppDataSource.getRepository(entity_1.OpWebhook).update(req.params.id, req.body);
        res.json((0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, null));
    }
    catch (e) {
        next(e);
    }
});
// 删除 Webhook
router.delete('/webhook/:id', async (req, res, next) => {
    try {
        await data_source_1.AppDataSource.getRepository(entity_1.OpWebhook).delete(req.params.id);
        res.json((0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, null));
    }
    catch (e) {
        next(e);
    }
});
// 推送测试
router.post('/webhook/:id/test', async (req, res, next) => {
    try {
        const webhook = await data_source_1.AppDataSource.getRepository(entity_1.OpWebhook).findOne({ where: { id: req.params.id } });
        if (!webhook)
            return res.status(404).json((0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, 'Webhook不存在'));
        res.json((0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
            success: true,
            responseCode: 200,
            responseTime: Math.floor(Math.random() * 300) + 50,
            message: '测试通知已发送',
        }));
    }
    catch (e) {
        next(e);
    }
});
exports.default = router;
//# sourceMappingURL=admin.js.map
"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const controller_1 = __importDefault(require("./controller"));
const auth_middleware_1 = require("../../common/middleware/auth.middleware");
const router = (0, express_1.Router)();
router.use(auth_middleware_1.authGuard);
// Main list route (alias for batch list)
router.get('/list', controller_1.default.getBatchList.bind(controller_1.default));
router.get('/batch/list', controller_1.default.getBatchList.bind(controller_1.default));
router.post('/batch', controller_1.default.createBatch.bind(controller_1.default));
router.put('/batch/:id/review', controller_1.default.reviewBatch.bind(controller_1.default));
// Channel Bill routes
router.get('/channel-bill/list', controller_1.default.getChannelBillList.bind(controller_1.default));
router.post('/channel-bill', controller_1.default.createChannelBill.bind(controller_1.default));
// Diff Bill routes
router.get('/diff-bill/list', controller_1.default.getDiffBillList.bind(controller_1.default));
router.put('/diff-bill/:id/handle', controller_1.default.handleDiffBill.bind(controller_1.default));
exports.default = router;
//# sourceMappingURL=routes.js.map
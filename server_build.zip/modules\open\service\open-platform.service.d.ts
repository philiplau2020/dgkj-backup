import { OpApp, AppStatus } from '../entity';
/**
 * 开发者服务
 */
export declare class DeveloperService {
    private repo;
    constructor();
    /** 注册开发者 */
    register(params: {
        developerName: string;
        username: string;
        password: string;
        email: string;
        mobile: string;
        company?: string;
        businessLicense?: string;
        contactPerson?: string;
        contactPhone?: string;
        description?: string;
        website?: string;
    }): Promise<import("../../../utils/op-code").OpResult<any>>;
    /** 开发者登录 */
    login(username: string, password: string, ip: string): Promise<import("../../../utils/op-code").OpResult<any>>;
    /** 获取开发者信息 */
    getInfo(developerId: string): Promise<{
        developerId: string;
        developerName: string;
        email: string;
        mobile: string;
        company: string;
        level: "trial" | "basic" | "professional" | "enterprise";
        status: "pending" | "active" | "suspended" | "rejected";
        appCount: number;
        totalCallCount: number;
        lastLoginTime: Date;
        lastLoginIp: string;
        createTime: Date;
    }>;
    /** 获取开发者列表 (后台管理) */
    list(params: {
        page?: number;
        pageSize?: number;
        keyword?: string;
        status?: string;
        level?: string;
    }): Promise<{
        list: {
            developerId: string;
            developerName: string;
            username: string;
            email: string;
            mobile: string;
            company: string;
            level: "trial" | "basic" | "professional" | "enterprise";
            status: "pending" | "active" | "suspended" | "rejected";
            appCount: number;
            totalCallCount: number;
            lastLoginTime: Date;
            createTime: Date;
        }[];
        total: number;
    }>;
    /** 审核开发者 */
    review(developerId: string, status: 'active' | 'rejected', reviewBy: string, remark?: string): Promise<import("../../../utils/op-code").OpResult<any>>;
    /** 更新开发者等级 */
    updateLevel(developerId: string, level: 'trial' | 'basic' | 'professional' | 'enterprise'): Promise<import("../../../utils/op-code").OpResult<any>>;
    private generateToken;
}
/**
 * 应用服务
 */
export declare class AppService {
    private repo;
    private devRepo;
    constructor();
    /** 创建应用 */
    create(params: {
        developerId: string;
        appName: string;
        appType: 'web' | 'mobile' | 'miniapp' | 'api';
        description?: string;
        appScenario?: string;
        domain?: string;
        notifyUrl?: string;
        refundNotifyUrl?: string;
        transferNotifyUrl?: string;
        enabledPayTypes?: string[];
    }): Promise<import("../../../utils/op-code").OpResult<any>>;
    /** 获取应用详情 */
    getApp(appId: string, developerId: string): Promise<{
        appId: string;
        appKey: string;
        appSecret: string;
        appName: string;
        appType: import("../entity").AppType;
        description: string;
        mchNo: string;
        domain: string;
        notifyUrl: string;
        refundNotifyUrl: string;
        transferNotifyUrl: string;
        enabledPayTypes: string[];
        enabledApis: string[];
        status: AppStatus;
        todayCallCount: number;
        totalCallCount: number;
        monthCallCount: number;
        monthTradeAmount: number;
        secretUpdateTime: Date;
        createTime: Date;
    }>;
    /** 获取应用列表 */
    list(developerId: string, params: {
        page?: number;
        pageSize?: number;
        keyword?: string;
        status?: string;
    }): Promise<{
        list: OpApp[];
        total: number;
    }>;
    /** 更新应用 */
    update(appId: string, developerId: string, data: Partial<OpApp>): Promise<import("../../../utils/op-code").OpResult<any>>;
    /** 重置 AppSecret */
    resetSecret(appId: string, developerId: string): Promise<import("../../../utils/op-code").OpResult<any>>;
    /** 更新IP白名单 */
    updateIpWhitelist(appId: string, developerId: string, ips: string[]): Promise<import("../../../utils/op-code").OpResult<any>>;
    /** 审核应用 */
    review(appId: string, status: 'active' | 'suspended', reviewBy?: string): Promise<import("../../../utils/op-code").OpResult<any>>;
    /** 获取应用配置信息 (供前端调试使用) */
    getAppConfig(appId: string): Promise<{
        appId: string;
        mchNo: string;
        enabledApis: string[];
        enabledPayTypes: string[];
    }>;
}
/**
 * API Key 管理服务
 */
export declare class ApiKeyService {
    private repo;
    constructor();
    /** 创建 API Key */
    createKey(params: {
        appId: string;
        developerId: string;
        alias?: string;
        signType?: 'hmac_sha256' | 'rsa_2048' | 'sm2';
        boundIp?: string;
        expireDays?: number;
    }): Promise<import("../../../utils/op-code").OpResult<{
        keyId: string;
        keyValue: string;
        keySecret: string;
        signType: "hmac_sha256" | "rsa_2048" | "sm2";
        expireTime: Date;
        message: string;
    }>>;
    /** 获取 Key 列表 */
    listKeys(appId: string): Promise<{
        keyId: string;
        keyValue: string;
        keySecret: string;
        signType: "hmac_sha256" | "rsa_2048" | "sm2";
        alias: string;
        boundIp: string;
        status: "active" | "disabled" | "expired";
        expireTime: Date;
        usedCount: number;
        lastUsedTime: Date;
        lastUsedIp: string;
        createTime: Date;
    }[]>;
    /** 禁用 Key */
    disableKey(keyId: string, developerId: string): Promise<import("../../../utils/op-code").OpResult<any>>;
    /** 启用 Key */
    enableKey(keyId: string, developerId: string): Promise<import("../../../utils/op-code").OpResult<any>>;
    /** 删除 Key */
    deleteKey(keyId: string, developerId: string): Promise<import("../../../utils/op-code").OpResult<any>>;
}
/**
 * 配额服务
 */
export declare class QuotaService {
    private repo;
    private appRepo;
    constructor();
    /** 获取配额信息 */
    getQuota(appId: string): Promise<{
        daily: {
            used: number;
            limit: 100 | 10000 | 1000000 | 100000;
        };
        monthly: {
            used: number;
            limit: 1000 | 1000000 | 100000 | 10000000;
        };
        rateLimit: 5 | 100 | 500 | 20;
        appLimit: 1 | 3 | 10 | 50;
    }>;
}
export declare const developerService: DeveloperService;
export declare const appService: AppService;
export declare const apiKeyService: ApiKeyService;
export declare const quotaService: QuotaService;
//# sourceMappingURL=open-platform.service.d.ts.map
/**
 * DGKJ 支付平台 - 运维监控路由
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=routes.d.ts.map
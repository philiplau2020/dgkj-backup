"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CheckDiffBill = exports.CheckChannelBill = exports.CheckBatch = exports.CheckBatchStatus = void 0;
const typeorm_1 = require("typeorm");
/** 对账批次状态 */
var CheckBatchStatus;
(function (CheckBatchStatus) {
    CheckBatchStatus[CheckBatchStatus["PROCESSING"] = 0] = "PROCESSING";
    CheckBatchStatus[CheckBatchStatus["SUCCESS"] = 1] = "SUCCESS";
    CheckBatchStatus[CheckBatchStatus["DIFF_FOUND"] = 2] = "DIFF_FOUND";
    CheckBatchStatus[CheckBatchStatus["FAILED"] = 3] = "FAILED";
})(CheckBatchStatus || (exports.CheckBatchStatus = CheckBatchStatus = {}));
let CheckBatch = class CheckBatch {
};
exports.CheckBatch = CheckBatch;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], CheckBatch.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'batch_no', length: 32, unique: true }),
    __metadata("design:type", String)
], CheckBatch.prototype, "batchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'check_date', length: 8 }),
    __metadata("design:type", String)
], CheckBatch.prototype, "checkDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_code', length: 32, default: '' }),
    __metadata("design:type", String)
], CheckBatch.prototype, "channelCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_name', length: 100, nullable: true }),
    __metadata("design:type", String)
], CheckBatch.prototype, "channelName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'platform_order_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], CheckBatch.prototype, "platformOrderCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'platform_total_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CheckBatch.prototype, "platformTotalAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_order_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], CheckBatch.prototype, "channelOrderCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_total_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CheckBatch.prototype, "channelTotalAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'diff_order_count', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], CheckBatch.prototype, "diffOrderCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'diff_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CheckBatch.prototype, "diffAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 0 }),
    __metadata("design:type", Number)
], CheckBatch.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'complete_time', nullable: true }),
    __metadata("design:type", Date)
], CheckBatch.prototype, "completeTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 500, nullable: true }),
    __metadata("design:type", String)
], CheckBatch.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], CheckBatch.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], CheckBatch.prototype, "updateTime", void 0);
exports.CheckBatch = CheckBatch = __decorate([
    (0, typeorm_1.Entity)('check_batch')
], CheckBatch);
let CheckChannelBill = class CheckChannelBill {
};
exports.CheckChannelBill = CheckChannelBill;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], CheckChannelBill.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'batch_no', length: 32 }),
    __metadata("design:type", String)
], CheckChannelBill.prototype, "batchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_code', length: 32 }),
    __metadata("design:type", String)
], CheckChannelBill.prototype, "channelCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'order_no', length: 64 }),
    __metadata("design:type", String)
], CheckChannelBill.prototype, "orderNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_order_no', length: 100, nullable: true }),
    __metadata("design:type", String)
], CheckChannelBill.prototype, "channelOrderNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], CheckChannelBill.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'fee', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CheckChannelBill.prototype, "fee", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', length: 20 }),
    __metadata("design:type", String)
], CheckChannelBill.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], CheckChannelBill.prototype, "createTime", void 0);
exports.CheckChannelBill = CheckChannelBill = __decorate([
    (0, typeorm_1.Entity)('check_channel_bill')
], CheckChannelBill);
let CheckDiffBill = class CheckDiffBill {
};
exports.CheckDiffBill = CheckDiffBill;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], CheckDiffBill.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'batch_no', length: 32 }),
    __metadata("design:type", String)
], CheckDiffBill.prototype, "batchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'order_no', length: 64 }),
    __metadata("design:type", String)
], CheckDiffBill.prototype, "orderNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_order_no', length: 100, nullable: true }),
    __metadata("design:type", String)
], CheckDiffBill.prototype, "channelOrderNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'diff_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], CheckDiffBill.prototype, "diffType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'platform_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CheckDiffBill.prototype, "platformAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_amount', type: 'decimal', precision: 18, scale: 2, default: 0 }),
    __metadata("design:type", Number)
], CheckDiffBill.prototype, "channelAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'diff_amount', type: 'decimal', precision: 18, scale: 2 }),
    __metadata("design:type", Number)
], CheckDiffBill.prototype, "diffAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'platform_status', length: 20, default: '' }),
    __metadata("design:type", String)
], CheckDiffBill.prototype, "platformStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'channel_status', length: 20, default: '' }),
    __metadata("design:type", String)
], CheckDiffBill.prototype, "channelStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'handle_status', type: 'tinyint', default: 0 }),
    __metadata("design:type", Number)
], CheckDiffBill.prototype, "handleStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'handle_remark', length: 255, nullable: true }),
    __metadata("design:type", String)
], CheckDiffBill.prototype, "handleRemark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'handle_time', nullable: true }),
    __metadata("design:type", Date)
], CheckDiffBill.prototype, "handleTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'remark', length: 500, nullable: true }),
    __metadata("design:type", String)
], CheckDiffBill.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], CheckDiffBill.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], CheckDiffBill.prototype, "updateTime", void 0);
exports.CheckDiffBill = CheckDiffBill = __decorate([
    (0, typeorm_1.Entity)('check_diff_bill')
], CheckDiffBill);
//# sourceMappingURL=check.entity.js.map
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OpApp = exports.AppType = exports.AppStatus = void 0;
/**
 * 开放平台应用实体
 */
const typeorm_1 = require("typeorm");
var AppStatus;
(function (AppStatus) {
    AppStatus["PENDING"] = "pending";
    AppStatus["ACTIVE"] = "active";
    AppStatus["SUSPENDED"] = "suspended";
    AppStatus["DELETED"] = "deleted";
})(AppStatus || (exports.AppStatus = AppStatus = {}));
var AppType;
(function (AppType) {
    AppType["WEB"] = "web";
    AppType["MOBILE"] = "mobile";
    AppType["MINIAPP"] = "miniapp";
    AppType["API"] = "api";
})(AppType || (exports.AppType = AppType = {}));
let OpApp = class OpApp {
};
exports.OpApp = OpApp;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], OpApp.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, unique: true, comment: '应用ID' }),
    __metadata("design:type", String)
], OpApp.prototype, "appId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 32, unique: true, comment: '应用Key(AppKey)' }),
    __metadata("design:type", String)
], OpApp.prototype, "appKey", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, comment: '应用密钥(AppSecret)' }),
    __metadata("design:type", String)
], OpApp.prototype, "appSecret", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, comment: '所属开发者ID' }),
    __metadata("design:type", String)
], OpApp.prototype, "developerId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, comment: '商户号(关联)' }),
    __metadata("design:type", String)
], OpApp.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 128, comment: '应用名称' }),
    __metadata("design:type", String)
], OpApp.prototype, "appName", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: AppType, default: AppType.WEB, comment: '应用类型' }),
    __metadata("design:type", String)
], OpApp.prototype, "appType", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true, comment: '应用描述' }),
    __metadata("design:type", String)
], OpApp.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true, comment: '应用场景说明' }),
    __metadata("design:type", String)
], OpApp.prototype, "appScenario", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 500, nullable: true, comment: '应用图标URL' }),
    __metadata("design:type", String)
], OpApp.prototype, "appIcon", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 500, nullable: true, comment: '正式域名' }),
    __metadata("design:type", String)
], OpApp.prototype, "domain", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 500, nullable: true, comment: '回调地址(支付通知)' }),
    __metadata("design:type", String)
], OpApp.prototype, "notifyUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 500, nullable: true, comment: '退款回调地址' }),
    __metadata("design:type", String)
], OpApp.prototype, "refundNotifyUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 500, nullable: true, comment: '转账回调地址' }),
    __metadata("design:type", String)
], OpApp.prototype, "transferNotifyUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'simple-array', nullable: true, comment: '已授权支付方式(wx_jsapi,wx_native,alipay,alipay_qr,unionpay,bank)' }),
    __metadata("design:type", Array)
], OpApp.prototype, "enabledPayTypes", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'simple-array', nullable: true, comment: '已授权API接口列表' }),
    __metadata("design:type", Array)
], OpApp.prototype, "enabledApis", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: AppStatus, default: AppStatus.PENDING, comment: '应用状态' }),
    __metadata("design:type", String)
], OpApp.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, comment: '今日API调用次数' }),
    __metadata("design:type", Number)
], OpApp.prototype, "todayCallCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, comment: '累计API调用次数' }),
    __metadata("design:type", Number)
], OpApp.prototype, "totalCallCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, comment: '当月API调用次数' }),
    __metadata("design:type", Number)
], OpApp.prototype, "monthCallCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, default: 0, comment: '本月累计交易金额(元)' }),
    __metadata("design:type", Number)
], OpApp.prototype, "monthTradeAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, comment: 'IP白名单数量' }),
    __metadata("design:type", Number)
], OpApp.prototype, "ipWhitelistCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true, comment: 'IP白名单(JSON数组)' }),
    __metadata("design:type", String)
], OpApp.prototype, "ipWhitelist", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'datetime', nullable: true, comment: '秘钥最后更新时间' }),
    __metadata("design:type", Date)
], OpApp.prototype, "secretUpdateTime", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'datetime' }),
    __metadata("design:type", Date)
], OpApp.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ type: 'datetime' }),
    __metadata("design:type", Date)
], OpApp.prototype, "updateTime", void 0);
exports.OpApp = OpApp = __decorate([
    (0, typeorm_1.Entity)('op_app')
], OpApp);
//# sourceMappingURL=app.entity.js.map
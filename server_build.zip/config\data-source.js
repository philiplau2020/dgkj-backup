"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppDataSource = void 0;
require("reflect-metadata");
const dotenv_1 = __importDefault(require("dotenv"));
const typeorm_1 = require("typeorm");
const sys_entity_1 = require("../database/entities/sys.entity");
const agent_entity_1 = require("../database/entities/agent.entity");
const mch_entity_1 = require("../database/entities/mch.entity");
const trade_entity_1 = require("../database/entities/trade.entity");
const finance_entity_1 = require("../database/entities/finance.entity");
const channel_entity_1 = require("../database/entities/channel.entity");
const citic_entity_1 = require("../database/entities/citic.entity");
const statistics_entity_1 = require("../database/entities/statistics.entity");
const device_entity_1 = require("../database/entities/device.entity");
const check_entity_1 = require("../database/entities/check.entity");
const profit_entity_1 = require("../database/entities/profit.entity");
const developer_entity_1 = require("../modules/open/entity/developer.entity");
const app_entity_1 = require("../modules/open/entity/app.entity");
const api_key_entity_1 = require("../modules/open/entity/api-key.entity");
const webhook_entity_1 = require("../modules/open/entity/webhook.entity");
const api_log_entity_1 = require("../modules/open/entity/api-log.entity");
const quota_entity_1 = require("../modules/open/entity/quota.entity");
dotenv_1.default.config();
exports.AppDataSource = new typeorm_1.DataSource({
    type: 'mysql',
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '3306'),
    username: process.env.DB_USERNAME || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_DATABASE || 'dgkj',
    synchronize: process.env.NODE_ENV !== 'production',
    logging: process.env.NODE_ENV === 'development',
    entities: [
        sys_entity_1.SysUser, sys_entity_1.SysRole, sys_entity_1.SysDept, sys_entity_1.SysMenu, sys_entity_1.SysUserRole, sys_entity_1.SysRoleMenu, sys_entity_1.SysDict, sys_entity_1.SysDictData, sys_entity_1.SysConfig, sys_entity_1.SysLog, sys_entity_1.SysNotice,
        agent_entity_1.AgentInfo, agent_entity_1.AgentProfit, agent_entity_1.AgentWithdraw,
        mch_entity_1.MchInfo, mch_entity_1.MchApp, mch_entity_1.MchStore, mch_entity_1.MchRate,
        trade_entity_1.PayOrder, trade_entity_1.RefundOrder, trade_entity_1.TransferOrder, trade_entity_1.TradeNotify,
        finance_entity_1.AccountInfo, finance_entity_1.AccountRecord, finance_entity_1.AccountSettlement, finance_entity_1.AccountWithdraw, finance_entity_1.AccountStatement,
        channel_entity_1.ChannelInfo, channel_entity_1.ChannelMch, channel_entity_1.ChannelRoute, channel_entity_1.PoolStrategy, channel_entity_1.PoolChannel, channel_entity_1.PoolConfig,
        citic_entity_1.CiticAccount, citic_entity_1.CiticCard, citic_entity_1.CiticCollection, citic_entity_1.CiticProfitShare, citic_entity_1.CiticTransfer, citic_entity_1.CiticSettlement, citic_entity_1.CiticCheck, citic_entity_1.CiticAccountRecord,
        statistics_entity_1.StatTrade, statistics_entity_1.StatMch, statistics_entity_1.StatAgent, statistics_entity_1.StatChannel, statistics_entity_1.StatFinance,
        device_entity_1.DeviceInfo, device_entity_1.DeviceActivationCode, device_entity_1.DeviceBinding,
        check_entity_1.CheckBatch, check_entity_1.CheckChannelBill, check_entity_1.CheckDiffBill,
        profit_entity_1.ProfitAccountGroup, profit_entity_1.ProfitReceiver, profit_entity_1.ProfitRecord, profit_entity_1.ProfitRollback,
        developer_entity_1.OpDeveloper, app_entity_1.OpApp, api_key_entity_1.OpApiKey, webhook_entity_1.OpWebhook, api_log_entity_1.OpApiLog, quota_entity_1.OpApiQuota,
    ],
    migrations: [__dirname + '/../database/migrations/**/*.ts'],
    subscribers: [],
});
//# sourceMappingURL=data-source.js.map
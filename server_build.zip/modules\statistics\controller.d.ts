import { Request, Response, NextFunction } from 'express';
export declare class StatisticsController {
    private tradeRepo;
    private mchRepo;
    private agentRepo;
    private channelRepo;
    private financeRepo;
    getDashboardStats(req: Request, res: Response, next: NextFunction): Promise<void>;
    getTradeStatList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getMchStatList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getAgentStatList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getChannelStatList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getFinanceStatList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getTradeTrend(req: Request, res: Response, next: NextFunction): Promise<void>;
    getPayTypeStats(req: Request, res: Response, next: NextFunction): Promise<void>;
}
declare const _default: StatisticsController;
export default _default;
//# sourceMappingURL=controller.d.ts.map
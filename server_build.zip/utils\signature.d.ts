/**
 * 开放平台签名工具
 *
 * 支持多种签名算法:
 * 1. HMAC-SHA256 (推荐) - 最常用，兼容性好
 * 2. RSA-SHA256 (2048位) - 非对称签名，安全性高
 * 3. SM2 (国密) - 国产密码算法
 */
/** 签名算法枚举 */
export declare const SignType: {
    readonly HMAC_SHA256: "HMAC-SHA256";
    readonly RSA_SHA256: "RSA-SHA256";
    readonly SM2: "SM2";
    readonly MD5: "MD5";
    readonly SHA1: "SHA1";
};
export type SignType = (typeof SignType)[keyof typeof SignType];
/** 按字典序排序并拼接参数 */
export declare function sortParams(params: Record<string, any>): string;
/** 生成签名 (HMAC-SHA256) */
export declare function signHmacSha256(params: Record<string, any>, secret: string): string;
/** 验证签名 (HMAC-SHA256) */
export declare function verifyHmacSha256(params: Record<string, any>, sign: string, secret: string): boolean;
/** 生成 RSA 签名 */
export declare function signRsaSha256(data: string, privateKey: string): string;
/** 验证 RSA 签名 */
export declare function verifyRsaSha256(data: string, signature: string, publicKey: string): boolean;
/** 生成 MD5 签名 (兼容老系统) */
export declare function signMd5(params: Record<string, any>, secret: string): string;
/** 验证 MD5 签名 */
export declare function verifyMd5(params: Record<string, any>, sign: string, secret: string): boolean;
/** 根据签名类型签名 */
export declare function sign(params: Record<string, any>, secret: string, signType?: SignType): string;
/** 通用验签 */
export declare function verifySign(params: Record<string, any>, sign: string, secret: string, signType?: SignType): boolean;
/** 生成随机字符串 */
export declare function generateNonce(length?: number): string;
/** 生成 AppKey (公开标识) */
export declare function generateAppKey(): string;
/** 生成 AppSecret */
export declare function generateAppSecret(): string;
/** 生成 KeyId */
export declare function generateKeyId(): string;
/** 生成商户号 */
export declare function generateMchNo(): string;
/** 生成应用ID */
export declare function generateAppId(): string;
/** AES 加密 */
export declare function aesEncrypt(data: string, key: string, iv: string): string;
/** AES 解密 */
export declare function aesDecrypt(data: string, key: string, iv: string): string;
/** 加密敏感数据 (AppSecret 存储) */
export declare function encryptSecret(secret: string, key: string): string;
/** 解密敏感数据 */
export declare function decryptSecret(encrypted: string, key: string): string;
/** 脱敏处理 */
export declare function maskSecret(value: string, showLength?: number): string;
export declare function maskPhone(phone: string): string;
export declare function maskEmail(email: string): string;
export declare function maskIdCard(idCard: string): string;
export declare function maskBankCard(cardNo: string): string;
//# sourceMappingURL=signature.d.ts.map
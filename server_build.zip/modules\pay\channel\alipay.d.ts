/**
 * DGKJ 支付平台 - 支付宝支付通道实现
 *
 * 支持: 扫码支付、JSAPI支付、APP支付、WAP支付
 */
import { IPaymentChannel, ChannelConfig, UnifiedPayRequest, UnifiedPayResponse, UnifiedQueryRequest, UnifiedQueryResponse, UnifiedRefundRequest, UnifiedRefundResponse, UnifiedTransferRequest, UnifiedTransferResponse, UnifiedCallbackData, PayWay, ChannelCode } from './interface';
export declare class AlipayChannel implements IPaymentChannel {
    readonly channelCode = ChannelCode.ALIPAY;
    readonly channelName = "\u652F\u4ED8\u5B9D";
    readonly supportedPayWays: PayWay[];
    private config;
    private getGateWay;
    initialize(config: ChannelConfig): void;
    /**
     * 执行支付
     */
    pay(request: UnifiedPayRequest): Promise<UnifiedPayResponse>;
    /**
     * 查询订单
     */
    query(request: UnifiedQueryRequest): Promise<UnifiedQueryResponse>;
    /**
     * 申请退款
     */
    refund(request: UnifiedRefundRequest): Promise<UnifiedRefundResponse>;
    /**
     * 转账
     */
    transfer(request: UnifiedTransferRequest): Promise<UnifiedTransferResponse>;
    /**
     * 验证回调签名
     */
    verifyCallback(data: any, headers: any): Promise<{
        success: boolean;
        errorMsg?: string;
    }>;
    /**
     * 解析回调数据
     */
    parseCallback(data: any): Promise<UnifiedCallbackData>;
    /**
     * 响应回调成功
     */
    responseCallbackSuccess(): string;
    /**
     * 响应回调失败
     */
    responseCallbackFail(): string;
    /**
     * 执行支付宝 API
     */
    private execute;
    /**
     * 签名
     */
    private sign;
    /**
     * 验签
     */
    private verifySign;
    /**
     * 获取签名字符串
     */
    private getSignContent;
    /**
     * 构建表单 (用于 WAP 支付)
     */
    private buildForm;
    /**
     * 生成二维码
     */
    private generateQRCode;
    /**
     * 格式化日期
     */
    private formatDate;
}
declare const _default: AlipayChannel;
export default _default;
//# sourceMappingURL=alipay.d.ts.map
/**
 * DGKJ 支付平台 - 中信银行 E+管家 API 对接服务
 *
 * 实现与中信银行 E+管家系统的完整对接
 */
interface CiticConfig {
    platformId: string;
    appId: string;
    appSecret: string;
    privateKey: string;
    publicKey: string;
    apiUrl: string;
    notifyUrl: string;
}
/**
 * 中信银行 API 服务
 */
export declare class CiticBankService {
    private config;
    private http;
    private accountRepo;
    private cardRepo;
    private collectionRepo;
    private profitShareRepo;
    private transferRepo;
    private settlementRepo;
    private recordRepo;
    constructor();
    /**
     * 初始化配置
     */
    initialize(config: Partial<CiticConfig>): void;
    /**
     * 创建子账户 (开户)
     */
    createAccount(params: {
        bizUserId: string;
        accountNo: string;
        accountName: string;
        accountType: number;
        mchNo?: string;
        agentNo?: string;
    }): Promise<import("../../utils/op-code").OpResult<any>>;
    /**
     * 查询账户余额
     */
    queryBalance(accountNo: string): Promise<import("../../utils/op-code").OpResult<any>>;
    /**
     * 查询账户详情
     */
    queryAccount(accountNo: string): Promise<import("../../utils/op-code").OpResult<any>>;
    /**
     * 绑定银行卡
     */
    bindCard(params: {
        accountNo: string;
        cardNo: string;
        cardType: number;
        bankName: string;
        bankCode: string;
        cardHolder: string;
        certNo: string;
        phone: string;
    }): Promise<import("../../utils/op-code").OpResult<any>>;
    /**
     * 解绑银行卡
     */
    unbindCard(params: {
        accountNo: string;
        cardNo: string;
        unbindReason?: string;
    }): Promise<import("../../utils/op-code").OpResult<any>>;
    /**
     * 设置归集关系
     */
    setCollection(params: {
        fromAccountNo: string;
        toAccountNo: string;
        collectionType: number;
        collectionAmount?: number;
        reservedAmount?: number;
    }): Promise<import("../../utils/op-code").OpResult<any>>;
    /**
     * 执行主动归集
     */
    executeCollection(collectionNo: string, amount?: number): Promise<import("../../utils/op-code").OpResult<any>>;
    /**
     * 执行分账
     */
    executeProfitShare(params: {
        orderNo: string;
        accountNo: string;
        receiverAccountNo: string;
        shareType: number;
        shareRate?: number;
        shareAmount?: number;
        shareRemark?: string;
    }): Promise<import("../../utils/op-code").OpResult<any>>;
    /**
     * 申请代付
     */
    applyTransfer(params: {
        accountNo: string;
        receiverCardNo: string;
        receiverName: string;
        receiverBank: string;
        receiverBankCode: string;
        amount: number;
        fee?: number;
        bizContent?: string;
        notifyUrl?: string;
    }): Promise<import("../../utils/op-code").OpResult<any>>;
    /**
     * 代付回调处理
     */
    handleTransferCallback(data: any): Promise<import("../../utils/op-code").OpResult<any>>;
    /**
     * 申请结算
     */
    applySettlement(params: {
        accountNo: string;
        settleType: number;
        amount: number;
        targetCardNo: string;
        targetBank: string;
        targetBankCode: string;
    }): Promise<import("../../utils/op-code").OpResult<any>>;
    /**
     * 下载对账单
     */
    downloadBill(params: {
        checkDate: string;
        accountNo?: string;
    }): Promise<import("../../utils/op-code").OpResult<any>>;
    /**
     * 发送 API 请求
     */
    private request;
    /**
     * 签名
     */
    private sign;
    /**
     * 记录账户流水
     */
    private recordAccountFlow;
    /**
     * 加密身份证号
     */
    private encryptCertNo;
    /**
     * 加密手机号
     */
    private maskPhone;
    /**
     * 脱敏银行卡号
     */
    private maskCardNo;
}
declare const _default: CiticBankService;
export default _default;
//# sourceMappingURL=citic-bank.service.d.ts.map
/**
 * DGKJ 支付平台 - 性能优化工具
 *
 * 提供请求限流、响应缓存、压缩等性能优化功能
 */
import { Request, Response, NextFunction } from 'express';
interface RateLimitOptions {
    windowMs?: number;
    maxRequests?: number;
    keyGenerator?: (req: Request) => string;
    handler?: (req: Request, res: Response, next: NextFunction) => void;
    skip?: (req: Request) => boolean;
}
export declare function createRateLimiter(options?: RateLimitOptions): (req: Request, res: Response, next: NextFunction) => Promise<void | Response<any, Record<string, any>>>;
export declare const apiRateLimiter: (req: Request, res: Response, next: NextFunction) => Promise<void | Response<any, Record<string, any>>>;
export declare const authRateLimiter: (req: Request, res: Response, next: NextFunction) => Promise<void | Response<any, Record<string, any>>>;
export declare const payRateLimiter: (req: Request, res: Response, next: NextFunction) => Promise<void | Response<any, Record<string, any>>>;
interface CacheOptions {
    ttl?: number;
    condition?: (req: Request, res: Response) => boolean;
    keyGenerator?: (req: Request) => string;
}
export declare function responseCache(options?: CacheOptions): (req: Request, res: Response, next: NextFunction) => Promise<void | Response<any, Record<string, any>>>;
interface CompressionOptions {
    level?: number;
    threshold?: number;
}
export declare function optimizeResponse(options?: CompressionOptions): (req: Request, res: Response, next: NextFunction) => void;
interface PerformanceMetrics {
    method: string;
    path: string;
    statusCode: number;
    responseTime: number;
    timestamp: number;
}
export declare function performanceMonitor(req: Request, res: Response, next: NextFunction): void;
export declare function getPerformanceMetrics(): {
    recent: PerformanceMetrics[];
    summary: {
        avgResponseTime: number;
        p95ResponseTime: number;
        p99ResponseTime: number;
        errorRate: number;
        totalRequests: number;
    };
};
export declare function memoryRateLimit(maxRequests: number, windowMs: number): (req: Request, res: Response, next: NextFunction) => void | Response<any, Record<string, any>>;
declare const _default: {
    createRateLimiter: typeof createRateLimiter;
    apiRateLimiter: (req: Request, res: Response, next: NextFunction) => Promise<void | Response<any, Record<string, any>>>;
    authRateLimiter: (req: Request, res: Response, next: NextFunction) => Promise<void | Response<any, Record<string, any>>>;
    payRateLimiter: (req: Request, res: Response, next: NextFunction) => Promise<void | Response<any, Record<string, any>>>;
    responseCache: typeof responseCache;
    optimizeResponse: typeof optimizeResponse;
    performanceMonitor: typeof performanceMonitor;
    getPerformanceMetrics: typeof getPerformanceMetrics;
    memoryRateLimit: typeof memoryRateLimit;
};
export default _default;
//# sourceMappingURL=performance.service.d.ts.map
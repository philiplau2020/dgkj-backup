import { Request, Response, NextFunction } from 'express';
export declare class DeviceController {
    private deviceRepo;
    private codeRepo;
    private bindingRepo;
    getDeviceList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getDeviceById(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    createDevice(req: Request, res: Response, next: NextFunction): Promise<void>;
    updateDevice(req: Request, res: Response, next: NextFunction): Promise<void>;
    bindDevice(req: Request, res: Response, next: NextFunction): Promise<void>;
    getActivationCodeList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createActivationCode(req: Request, res: Response, next: NextFunction): Promise<void>;
    getQrCodeList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getSpeakerList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getPrinterList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getPosList(req: Request, res: Response, next: NextFunction): Promise<void>;
}
declare const _default: DeviceController;
export default _default;
//# sourceMappingURL=controller.d.ts.map
"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const controller_1 = __importDefault(require("./controller"));
const auth_middleware_1 = require("../../common/middleware/auth.middleware");
const router = (0, express_1.Router)();
router.use(auth_middleware_1.authGuard);
// Main list route (alias for record list)
router.get('/list', controller_1.default.getRecordList.bind(controller_1.default));
// Account Group routes
router.get('/account-group/list', controller_1.default.getAccountGroupList.bind(controller_1.default));
router.post('/account-group', controller_1.default.createAccountGroup.bind(controller_1.default));
router.put('/account-group/:id', controller_1.default.updateAccountGroup.bind(controller_1.default));
// Receiver routes
router.get('/receiver/list', controller_1.default.getReceiverList.bind(controller_1.default));
router.post('/receiver', controller_1.default.createReceiver.bind(controller_1.default));
router.put('/receiver/:id', controller_1.default.updateReceiver.bind(controller_1.default));
// Record routes
router.get('/record/list', controller_1.default.getRecordList.bind(controller_1.default));
router.post('/record', controller_1.default.createRecord.bind(controller_1.default));
router.put('/record/:id/settle', controller_1.default.settleRecord.bind(controller_1.default));
// Rollback routes
router.get('/rollback/list', controller_1.default.getRollbackList.bind(controller_1.default));
router.post('/rollback', controller_1.default.createRollback.bind(controller_1.default));
router.put('/rollback/:id/complete', controller_1.default.completeRollback.bind(controller_1.default));
exports.default = router;
//# sourceMappingURL=routes.js.map
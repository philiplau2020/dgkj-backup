"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const controller_1 = __importDefault(require("./controller"));
const auth_middleware_1 = require("../../common/middleware/auth.middleware");
const router = (0, express_1.Router)();
router.use(auth_middleware_1.authGuard);
// Dashboard
router.get('/dashboard', controller_1.default.getDashboardStats.bind(controller_1.default));
// Trade Statistics
router.get('/trade/list', controller_1.default.getTradeStatList.bind(controller_1.default));
router.get('/trade/trend', controller_1.default.getTradeTrend.bind(controller_1.default));
router.get('/trade/pay-type', controller_1.default.getPayTypeStats.bind(controller_1.default));
// Merchant Statistics
router.get('/merchant/list', controller_1.default.getMchStatList.bind(controller_1.default));
// Agent Statistics
router.get('/agent/list', controller_1.default.getAgentStatList.bind(controller_1.default));
// Channel Statistics
router.get('/channel/list', controller_1.default.getChannelStatList.bind(controller_1.default));
// Finance Statistics
router.get('/finance/list', controller_1.default.getFinanceStatList.bind(controller_1.default));
exports.default = router;
//# sourceMappingURL=routes.js.map
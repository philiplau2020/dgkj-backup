import { Request, Response, NextFunction } from 'express';
export declare class CheckController {
    private batchRepo;
    private channelBillRepo;
    private diffBillRepo;
    getBatchList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createBatch(req: Request, res: Response, next: NextFunction): Promise<void>;
    reviewBatch(req: Request, res: Response, next: NextFunction): Promise<void>;
    getChannelBillList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createChannelBill(req: Request, res: Response, next: NextFunction): Promise<void>;
    getDiffBillList(req: Request, res: Response, next: NextFunction): Promise<void>;
    handleDiffBill(req: Request, res: Response, next: NextFunction): Promise<void>;
}
declare const _default: CheckController;
export default _default;
//# sourceMappingURL=controller.d.ts.map
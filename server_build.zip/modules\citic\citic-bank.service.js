"use strict";
/**
 * DGKJ 支付平台 - 中信银行 E+管家 API 对接服务
 *
 * 实现与中信银行 E+管家系统的完整对接
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CiticBankService = void 0;
const axios_1 = __importDefault(require("axios"));
const crypto = __importStar(require("crypto"));
const uuid_1 = require("uuid");
const data_source_1 = require("../../config/data-source");
const citic_entity_1 = require("../../database/entities/citic.entity");
const op_code_1 = require("../../utils/op-code");
// API 地址
const CITIC_API_URL = {
    // 测试环境
    sandbox: 'https://i.citiccloud.com/citic-b2b-gateway/sandbox',
    // 生产环境
    production: 'https://i.citiccloud.com/citic-b2b-gateway/prod',
};
/**
 * 中信银行 API 服务
 */
class CiticBankService {
    constructor() {
        this.config = {
            platformId: process.env.CITIC_PLATFORM_ID || '',
            appId: process.env.CITIC_APP_ID || '',
            appSecret: process.env.CITIC_APP_SECRET || '',
            privateKey: process.env.CITIC_PRIVATE_KEY || '',
            publicKey: process.env.CITIC_PUBLIC_KEY || '',
            apiUrl: process.env.CITIC_API_URL || CITIC_API_URL.sandbox,
            notifyUrl: process.env.CITIC_NOTIFY_URL || '',
        };
        // Repository
        this.accountRepo = data_source_1.AppDataSource.getRepository(citic_entity_1.CiticAccount);
        this.cardRepo = data_source_1.AppDataSource.getRepository(citic_entity_1.CiticCard);
        this.collectionRepo = data_source_1.AppDataSource.getRepository(citic_entity_1.CiticCollection);
        this.profitShareRepo = data_source_1.AppDataSource.getRepository(citic_entity_1.CiticProfitShare);
        this.transferRepo = data_source_1.AppDataSource.getRepository(citic_entity_1.CiticTransfer);
        this.settlementRepo = data_source_1.AppDataSource.getRepository(citic_entity_1.CiticSettlement);
        this.recordRepo = data_source_1.AppDataSource.getRepository(citic_entity_1.CiticAccountRecord);
        this.http = axios_1.default.create({
            baseURL: this.config.apiUrl,
            timeout: 30000,
            headers: {
                'Content-Type': 'application/json',
            },
        });
    }
    /**
     * 初始化配置
     */
    initialize(config) {
        this.config = { ...this.config, ...config };
        if (config.apiUrl) {
            this.http = axios_1.default.create({
                baseURL: this.config.apiUrl,
                timeout: 30000,
                headers: {
                    'Content-Type': 'application/json',
                },
            });
        }
    }
    // ==================== 账户管理 ====================
    /**
     * 创建子账户 (开户)
     */
    async createAccount(params) {
        try {
            // 构建请求参数
            const requestData = {
                platformId: this.config.platformId,
                requestId: (0, uuid_1.v4)(),
                timestamp: Date.now(),
                bizUserId: params.bizUserId,
                accountNo: params.accountNo,
                accountName: params.accountName,
                accountType: params.accountType,
                mchNo: params.mchNo,
                agentNo: params.agentNo,
            };
            // 签名
            const sign = this.sign(requestData);
            requestData['sign'] = sign;
            // 发送请求
            const response = await this.request('/account/create', requestData);
            if (response.code === 'SUCCESS') {
                // 保存账户记录
                const account = this.accountRepo.create({
                    id: (0, uuid_1.v4)(),
                    bizUserId: params.bizUserId,
                    accountNo: params.accountNo,
                    accountName: params.accountName,
                    accountType: params.accountType,
                    mchNo: params.mchNo,
                    agentNo: params.agentNo,
                    balance: 0,
                    availableBalance: 0,
                    frozenBalance: 0,
                    pendingBalance: 0,
                    status: citic_entity_1.CiticAccountStatus.ENABLED,
                    auditStatus: 1,
                    createTime: new Date(),
                    updateTime: new Date(),
                });
                await this.accountRepo.save(account);
                return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
                    accountNo: params.accountNo,
                    accountName: params.accountName,
                    status: 'success',
                });
            }
            else {
                return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, response.message || '开户失败');
            }
        }
        catch (error) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, error.message);
        }
    }
    /**
     * 查询账户余额
     */
    async queryBalance(accountNo) {
        try {
            const requestData = {
                platformId: this.config.platformId,
                requestId: (0, uuid_1.v4)(),
                timestamp: Date.now(),
                accountNo,
            };
            const sign = this.sign(requestData);
            requestData['sign'] = sign;
            const response = await this.request('/account/balance/query', requestData);
            if (response.code === 'SUCCESS') {
                // 更新本地账户余额
                const account = await this.accountRepo.findOne({ where: { accountNo } });
                if (account) {
                    account.balance = parseFloat(response.data.balance || '0');
                    account.availableBalance = parseFloat(response.data.availableBalance || '0');
                    account.frozenBalance = parseFloat(response.data.frozenBalance || '0');
                    account.pendingBalance = parseFloat(response.data.pendingBalance || '0');
                    account.updateTime = new Date();
                    await this.accountRepo.save(account);
                }
                return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
                    accountNo,
                    balance: parseFloat(response.data.balance || '0'),
                    availableBalance: parseFloat(response.data.availableBalance || '0'),
                    frozenBalance: parseFloat(response.data.frozenBalance || '0'),
                    pendingBalance: parseFloat(response.data.pendingBalance || '0'),
                });
            }
            else {
                return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, response.message);
            }
        }
        catch (error) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, error.message);
        }
    }
    /**
     * 查询账户详情
     */
    async queryAccount(accountNo) {
        try {
            const requestData = {
                platformId: this.config.platformId,
                requestId: (0, uuid_1.v4)(),
                timestamp: Date.now(),
                accountNo,
            };
            const sign = this.sign(requestData);
            requestData['sign'] = sign;
            const response = await this.request('/account/query', requestData);
            if (response.code === 'SUCCESS') {
                return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, response.data);
            }
            else {
                return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, response.message);
            }
        }
        catch (error) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, error.message);
        }
    }
    // ==================== 银行卡管理 ====================
    /**
     * 绑定银行卡
     */
    async bindCard(params) {
        try {
            const requestData = {
                platformId: this.config.platformId,
                requestId: (0, uuid_1.v4)(),
                timestamp: Date.now(),
                accountNo: params.accountNo,
                cardNo: params.cardNo,
                cardType: params.cardType,
                bankName: params.bankName,
                bankCode: params.bankCode,
                cardHolder: params.cardHolder,
                certNo: params.certNo,
                phone: params.phone,
                notifyUrl: this.config.notifyUrl + '/citic/card/callback',
            };
            const sign = this.sign(requestData);
            requestData['sign'] = sign;
            const response = await this.request('/card/bind', requestData);
            if (response.code === 'SUCCESS') {
                // 保存银行卡记录
                const card = this.cardRepo.create({
                    id: (0, uuid_1.v4)(),
                    bizUserId: '',
                    accountNo: params.accountNo,
                    cardNo: params.cardNo,
                    cardType: params.cardType,
                    bankName: params.bankName,
                    bankCode: params.bankCode,
                    cardHolder: params.cardHolder,
                    certNo: this.encryptCertNo(params.certNo),
                    phone: this.maskPhone(params.phone),
                    status: citic_entity_1.CiticCardStatus.BIND,
                    bindTime: new Date(),
                    createTime: new Date(),
                    updateTime: new Date(),
                });
                await this.cardRepo.save(card);
                return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
                    cardNo: this.maskCardNo(params.cardNo),
                    status: 'bind_success',
                });
            }
            else {
                return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, response.message);
            }
        }
        catch (error) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, error.message);
        }
    }
    /**
     * 解绑银行卡
     */
    async unbindCard(params) {
        try {
            const requestData = {
                platformId: this.config.platformId,
                requestId: (0, uuid_1.v4)(),
                timestamp: Date.now(),
                accountNo: params.accountNo,
                cardNo: params.cardNo,
                unbindReason: params.unbindReason || '用户主动解绑',
            };
            const sign = this.sign(requestData);
            requestData['sign'] = sign;
            const response = await this.request('/card/unbind', requestData);
            if (response.code === 'SUCCESS') {
                // 更新银行卡状态
                const card = await this.cardRepo.findOne({ where: { cardNo: params.cardNo } });
                if (card) {
                    card.status = citic_entity_1.CiticCardStatus.UNBIND;
                    card.unbindTime = new Date();
                    card.unbindReason = params.unbindReason;
                    card.updateTime = new Date();
                    await this.cardRepo.save(card);
                }
                return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, { status: 'unbind_success' });
            }
            else {
                return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, response.message);
            }
        }
        catch (error) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, error.message);
        }
    }
    // ==================== 资金归集 ====================
    /**
     * 设置归集关系
     */
    async setCollection(params) {
        try {
            const requestData = {
                platformId: this.config.platformId,
                requestId: (0, uuid_1.v4)(),
                timestamp: Date.now(),
                fromAccountNo: params.fromAccountNo,
                toAccountNo: params.toAccountNo,
                collectionType: params.collectionType,
                collectionAmount: params.collectionAmount,
                reservedAmount: params.reservedAmount,
            };
            const sign = this.sign(requestData);
            requestData['sign'] = sign;
            const response = await this.request('/collection/set', requestData);
            if (response.code === 'SUCCESS') {
                // 保存归集关系
                const collectionNo = response.data?.collectionNo || 'COL' + Date.now();
                const fromAccount = await this.accountRepo.findOne({ where: { accountNo: params.fromAccountNo } });
                const toAccount = await this.accountRepo.findOne({ where: { accountNo: params.toAccountNo } });
                const collection = this.collectionRepo.create({
                    id: (0, uuid_1.v4)(),
                    collectionNo,
                    fromAccountNo: params.fromAccountNo,
                    fromAccountName: fromAccount?.accountName || '',
                    toAccountNo: params.toAccountNo,
                    toAccountName: toAccount?.accountName || '',
                    collectionType: params.collectionType,
                    collectionAmount: params.collectionAmount,
                    reservedAmount: params.reservedAmount,
                    status: citic_entity_1.CiticCollectionStatus.PENDING,
                    relationStatus: 1,
                    createTime: new Date(),
                    updateTime: new Date(),
                });
                await this.collectionRepo.save(collection);
                return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
                    collectionNo,
                    status: 'set_success',
                });
            }
            else {
                return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, response.message);
            }
        }
        catch (error) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, error.message);
        }
    }
    /**
     * 执行主动归集
     */
    async executeCollection(collectionNo, amount) {
        try {
            const collection = await this.collectionRepo.findOne({ where: { collectionNo } });
            if (!collection) {
                return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, '归集关系不存在');
            }
            // 获取账户余额
            const fromAccount = await this.accountRepo.findOne({ where: { accountNo: collection.fromAccountNo } });
            const toAccount = await this.accountRepo.findOne({ where: { accountNo: collection.toAccountNo } });
            if (!fromAccount || !toAccount) {
                return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, '账户不存在');
            }
            // 计算归集金额
            let collectAmount = 0;
            switch (collection.collectionType) {
                case 1: // 全额归集
                    collectAmount = fromAccount.availableBalance;
                    break;
                case 2: // 定额归集
                    collectAmount = collection.collectionAmount || amount || 0;
                    break;
                case 3: // 保留余额归集
                    collectAmount = fromAccount.availableBalance - (collection.reservedAmount || 0);
                    break;
            }
            if (collectAmount <= 0) {
                return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, '归集金额必须大于0');
            }
            const requestData = {
                platformId: this.config.platformId,
                requestId: (0, uuid_1.v4)(),
                timestamp: Date.now(),
                collectionNo,
                amount: collectAmount,
            };
            const sign = this.sign(requestData);
            requestData['sign'] = sign;
            const response = await this.request('/collection/execute', requestData);
            if (response.code === 'SUCCESS') {
                const beforeBalance = fromAccount.availableBalance;
                // 更新本地账户余额
                fromAccount.availableBalance = fromAccount.availableBalance - collectAmount;
                toAccount.availableBalance = toAccount.availableBalance + collectAmount;
                fromAccount.updateTime = new Date();
                toAccount.updateTime = new Date();
                await this.accountRepo.save([fromAccount, toAccount]);
                // 更新归集状态
                collection.status = citic_entity_1.CiticCollectionStatus.SUCCESS;
                collection.collectionAmount = collectAmount;
                collection.completeTime = new Date();
                collection.updateTime = new Date();
                await this.collectionRepo.save(collection);
                // 记录流水
                await this.recordAccountFlow({
                    accountNo: fromAccount.accountNo,
                    bizType: 5,
                    bizTypeName: '资金归集-转出',
                    amount: -collectAmount,
                    balanceBefore: beforeBalance,
                    balanceAfter: fromAccount.availableBalance,
                    orderNo: collectionNo,
                    oppositeAccountNo: toAccount.accountNo,
                    oppositeAccountName: toAccount.accountName,
                });
                await this.recordAccountFlow({
                    accountNo: toAccount.accountNo,
                    bizType: 5,
                    bizTypeName: '资金归集-转入',
                    amount: collectAmount,
                    balanceBefore: toAccount.availableBalance - collectAmount,
                    balanceAfter: toAccount.availableBalance,
                    orderNo: collectionNo,
                    oppositeAccountNo: fromAccount.accountNo,
                    oppositeAccountName: fromAccount.accountName,
                });
                return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
                    collectionNo,
                    amount: collectAmount,
                    status: 'success',
                });
            }
            else {
                return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, response.message);
            }
        }
        catch (error) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, error.message);
        }
    }
    // ==================== 分账 ====================
    /**
     * 执行分账
     */
    async executeProfitShare(params) {
        try {
            const requestData = {
                platformId: this.config.platformId,
                requestId: (0, uuid_1.v4)(),
                timestamp: Date.now(),
                orderNo: params.orderNo,
                accountNo: params.accountNo,
                receiverList: [{
                        receiverAccountNo: params.receiverAccountNo,
                        shareType: params.shareType,
                        shareRate: params.shareRate,
                        shareAmount: params.shareAmount,
                    }],
                shareRemark: params.shareRemark,
            };
            const sign = this.sign(requestData);
            requestData['sign'] = sign;
            const response = await this.request('/profit/share', requestData);
            if (response.code === 'SUCCESS') {
                const shareNo = response.data?.shareNo || 'PS' + Date.now();
                // 获取账户信息
                const account = await this.accountRepo.findOne({ where: { accountNo: params.accountNo } });
                const receiverAccount = await this.accountRepo.findOne({ where: { accountNo: params.receiverAccountNo } });
                const shareAmount = params.shareAmount || (params.shareRate ? params.shareAmount : 0);
                // 保存分账记录
                const profitShare = this.profitShareRepo.create({
                    id: (0, uuid_1.v4)(),
                    shareNo,
                    orderNo: params.orderNo,
                    accountNo: params.accountNo,
                    accountName: account?.accountName || '',
                    receiverAccountNo: params.receiverAccountNo,
                    receiverName: receiverAccount?.accountName || '',
                    shareType: params.shareType,
                    shareRate: params.shareRate,
                    shareAmount,
                    orderAmount: 0,
                    status: citic_entity_1.CiticProfitShareStatus.SUCCESS,
                    shareTime: new Date(),
                    createTime: new Date(),
                    updateTime: new Date(),
                });
                await this.profitShareRepo.save(profitShare);
                // 更新账户余额
                if (account && receiverAccount) {
                    const beforeBalance = account.availableBalance;
                    account.availableBalance = account.availableBalance - shareAmount;
                    receiverAccount.availableBalance = receiverAccount.availableBalance + shareAmount;
                    account.updateTime = new Date();
                    receiverAccount.updateTime = new Date();
                    await this.accountRepo.save([account, receiverAccount]);
                    // 记录流水
                    await this.recordAccountFlow({
                        accountNo: account.accountNo,
                        bizType: 6,
                        bizTypeName: '分账支出',
                        amount: -shareAmount,
                        balanceBefore: beforeBalance,
                        balanceAfter: account.availableBalance,
                        orderNo: shareNo,
                        oppositeAccountNo: receiverAccount.accountNo,
                        oppositeAccountName: receiverAccount.accountName,
                    });
                    await this.recordAccountFlow({
                        accountNo: receiverAccount.accountNo,
                        bizType: 6,
                        bizTypeName: '分账收入',
                        amount: shareAmount,
                        balanceBefore: receiverAccount.availableBalance - shareAmount,
                        balanceAfter: receiverAccount.availableBalance,
                        orderNo: shareNo,
                        oppositeAccountNo: account.accountNo,
                        oppositeAccountName: account.accountName,
                    });
                }
                return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
                    shareNo,
                    shareAmount,
                    status: 'success',
                });
            }
            else {
                return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, response.message);
            }
        }
        catch (error) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, error.message);
        }
    }
    // ==================== 代付 ====================
    /**
     * 申请代付
     */
    async applyTransfer(params) {
        try {
            const requestData = {
                platformId: this.config.platformId,
                requestId: (0, uuid_1.v4)(),
                timestamp: Date.now(),
                accountNo: params.accountNo,
                receiverCardNo: params.receiverCardNo,
                receiverName: params.receiverName,
                receiverBank: params.receiverBank,
                receiverBankCode: params.receiverBankCode,
                amount: params.amount,
                fee: params.fee || 0,
                bizContent: params.bizContent || '代付',
                notifyUrl: params.notifyUrl || this.config.notifyUrl + '/citic/transfer/callback',
            };
            const sign = this.sign(requestData);
            requestData['sign'] = sign;
            const response = await this.request('/transfer/apply', requestData);
            if (response.code === 'SUCCESS') {
                const transferNo = response.data?.transferNo || 'TRF' + Date.now();
                // 获取账户信息
                const account = await this.accountRepo.findOne({ where: { accountNo: params.accountNo } });
                // 保存代付记录
                const transfer = this.transferRepo.create({
                    id: (0, uuid_1.v4)(),
                    transferNo,
                    accountNo: params.accountNo,
                    accountName: account?.accountName || '',
                    receiverCardNo: params.receiverCardNo,
                    receiverBankName: params.receiverBank,
                    receiverBankCode: params.receiverBankCode,
                    amount: params.amount,
                    fee: params.fee || 0,
                    actualAmount: params.amount - (params.fee || 0),
                    transferType: 1,
                    status: citic_entity_1.CiticTransferStatus.PROCESSING,
                    createTime: new Date(),
                    updateTime: new Date(),
                });
                await this.transferRepo.save(transfer);
                // 冻结金额
                if (account) {
                    const beforeBalance = account.availableBalance;
                    account.availableBalance = account.availableBalance - params.amount - (params.fee || 0);
                    account.frozenBalance = account.frozenBalance + params.amount + (params.fee || 0);
                    account.updateTime = new Date();
                    await this.accountRepo.save(account);
                    // 记录流水
                    await this.recordAccountFlow({
                        accountNo: account.accountNo,
                        bizType: 7,
                        bizTypeName: '代付冻结',
                        amount: -(params.amount + (params.fee || 0)),
                        balanceBefore: beforeBalance,
                        balanceAfter: account.availableBalance,
                        orderNo: transferNo,
                    });
                }
                return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
                    transferNo,
                    amount: params.amount,
                    fee: params.fee || 0,
                    status: 'processing',
                });
            }
            else {
                return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, response.message);
            }
        }
        catch (error) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, error.message);
        }
    }
    /**
     * 代付回调处理
     */
    async handleTransferCallback(data) {
        try {
            const { transferNo, status, failReason } = data;
            const transfer = await this.transferRepo.findOne({ where: { transferNo } });
            if (!transfer) {
                return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, '代付记录不存在');
            }
            const account = await this.accountRepo.findOne({ where: { accountNo: transfer.accountNo } });
            if (status === 'SUCCESS') {
                // 代付成功
                transfer.status = citic_entity_1.CiticTransferStatus.SUCCESS;
                transfer.successTime = new Date();
                transfer.notifyTime = new Date();
                await this.transferRepo.save(transfer);
                // 解冻金额
                if (account) {
                    const totalAmount = transfer.amount + transfer.fee;
                    account.frozenBalance = account.frozenBalance - totalAmount;
                    account.updateTime = new Date();
                    await this.accountRepo.save(account);
                    // 记录流水
                    await this.recordAccountFlow({
                        accountNo: account.accountNo,
                        bizType: 7,
                        bizTypeName: '代付成功',
                        amount: -totalAmount,
                        balanceBefore: account.frozenBalance + totalAmount,
                        balanceAfter: account.frozenBalance,
                        orderNo: transferNo,
                        remark: `代付成功，金额：${transfer.amount}，手续费：${transfer.fee}`,
                    });
                }
            }
            else {
                // 代付失败
                transfer.status = citic_entity_1.CiticTransferStatus.FAILED;
                transfer.failReason = failReason;
                transfer.notifyTime = new Date();
                await this.transferRepo.save(transfer);
                // 解冻并返还金额
                if (account) {
                    const totalAmount = transfer.amount + transfer.fee;
                    account.availableBalance = account.availableBalance + totalAmount;
                    account.frozenBalance = account.frozenBalance - totalAmount;
                    account.updateTime = new Date();
                    await this.accountRepo.save(account);
                    // 记录流水
                    await this.recordAccountFlow({
                        accountNo: account.accountNo,
                        bizType: 7,
                        bizTypeName: '代付失败-返还',
                        amount: totalAmount,
                        balanceBefore: account.frozenBalance,
                        balanceAfter: account.availableBalance,
                        orderNo: transferNo,
                        remark: `代付失败，金额返还：${totalAmount}，原因：${failReason}`,
                    });
                }
            }
            return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, { transferNo, status });
        }
        catch (error) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, error.message);
        }
    }
    // ==================== 结算 ====================
    /**
     * 申请结算
     */
    async applySettlement(params) {
        try {
            // 计算手续费
            const feeRate = params.settleType === 1 ? 0.0035 : 0.0025; // D+0: 0.35%, T+1: 0.25%
            const fee = Math.ceil(params.amount * feeRate * 100) / 100;
            const actualAmount = params.amount - fee;
            // 获取账户
            const account = await this.accountRepo.findOne({ where: { accountNo: params.accountNo } });
            if (!account) {
                return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, '账户不存在');
            }
            if (account.availableBalance < params.amount) {
                return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, '余额不足');
            }
            const requestData = {
                platformId: this.config.platformId,
                requestId: (0, uuid_1.v4)(),
                timestamp: Date.now(),
                accountNo: params.accountNo,
                settleType: params.settleType,
                amount: params.amount,
                fee,
                actualAmount,
                targetCardNo: params.targetCardNo,
                targetBank: params.targetBank,
                targetBankCode: params.targetBankCode,
                notifyUrl: this.config.notifyUrl + '/citic/settlement/callback',
            };
            const sign = this.sign(requestData);
            requestData['sign'] = sign;
            const response = await this.request('/settlement/apply', requestData);
            if (response.code === 'SUCCESS') {
                const settleNo = response.data?.settleNo || 'STL' + Date.now();
                // 保存结算记录
                const settlement = this.settlementRepo.create({
                    id: (0, uuid_1.v4)(),
                    settleNo,
                    accountNo: params.accountNo,
                    accountName: account.accountName,
                    settleType: params.settleType,
                    amount: params.amount,
                    fee,
                    actualAmount,
                    targetCardNo: params.targetCardNo,
                    targetBankName: params.targetBank,
                    targetBankCode: params.targetBankCode,
                    status: citic_entity_1.CiticSettlementStatus.PROCESSING,
                    createTime: new Date(),
                    updateTime: new Date(),
                });
                await this.settlementRepo.save(settlement);
                // 冻结金额
                const beforeBalance = account.availableBalance;
                account.availableBalance = account.availableBalance - params.amount;
                account.frozenBalance = account.frozenBalance + params.amount;
                account.updateTime = new Date();
                await this.accountRepo.save(account);
                // 记录流水
                await this.recordAccountFlow({
                    accountNo: account.accountNo,
                    bizType: 8,
                    bizTypeName: params.settleType === 1 ? 'D+0结算申请' : 'T+1结算申请',
                    amount: -params.amount,
                    balanceBefore: beforeBalance,
                    balanceAfter: account.availableBalance,
                    orderNo: settleNo,
                    remark: `结算申请，金额：${params.amount}，手续费：${fee}`,
                });
                return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
                    settleNo,
                    amount: params.amount,
                    fee,
                    actualAmount,
                    status: 'processing',
                });
            }
            else {
                return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, response.message);
            }
        }
        catch (error) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, error.message);
        }
    }
    // ==================== 对账 ====================
    /**
     * 下载对账单
     */
    async downloadBill(params) {
        try {
            const requestData = {
                platformId: this.config.platformId,
                requestId: (0, uuid_1.v4)(),
                timestamp: Date.now(),
                checkDate: params.checkDate,
                accountNo: params.accountNo,
            };
            const sign = this.sign(requestData);
            requestData['sign'] = sign;
            const response = await this.request('/check/bill/download', requestData);
            if (response.code === 'SUCCESS') {
                return (0, op_code_1.opResult)(op_code_1.OpCode.SUCCESS, {
                    fileUrl: response.data?.fileUrl,
                    fileName: `中信银行对账单_${params.checkDate}.xlsx`,
                });
            }
            else {
                return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, response.message);
            }
        }
        catch (error) {
            return (0, op_code_1.opResult)(op_code_1.OpCode.SYS_ERROR, null, error.message);
        }
    }
    // ==================== 私有方法 ====================
    /**
     * 发送 API 请求
     */
    async request(path, data) {
        try {
            const response = await this.http.post(path, data);
            return response.data;
        }
        catch (error) {
            if (error.response) {
                return error.response.data;
            }
            throw error;
        }
    }
    /**
     * 签名
     */
    sign(data) {
        if (!this.config.privateKey) {
            // 如果没有私钥，使用简单的签名
            const str = JSON.stringify(data) + this.config.appSecret;
            return crypto.createHash('md5').update(str).digest('hex');
        }
        // RSA 签名
        const sign = crypto.createSign('RSA-SHA256');
        sign.update(JSON.stringify(data));
        return sign.sign(this.config.privateKey, 'base64');
    }
    /**
     * 记录账户流水
     */
    async recordAccountFlow(params) {
        const record = this.recordRepo.create({
            id: (0, uuid_1.v4)(),
            recordNo: 'REC' + Date.now() + Math.random().toString(36).slice(2, 6).toUpperCase(),
            accountNo: params.accountNo,
            bizType: params.bizType,
            bizTypeName: params.bizTypeName,
            amount: params.amount,
            balanceBefore: params.balanceBefore,
            balanceAfter: params.balanceAfter,
            orderNo: params.orderNo,
            oppositeAccountNo: params.oppositeAccountNo,
            oppositeAccountName: params.oppositeAccountName,
            remark: params.remark,
            createTime: new Date(),
        });
        await this.recordRepo.save(record);
    }
    /**
     * 加密身份证号
     */
    encryptCertNo(certNo) {
        // 使用 AES 加密 (实际应使用配置的密钥)
        const key = crypto.scryptSync(this.config.appSecret, 'salt', 32);
        const iv = crypto.randomBytes(16);
        const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
        let encrypted = cipher.update(certNo, 'utf8', 'hex');
        encrypted += cipher.final('hex');
        return iv.toString('hex') + ':' + encrypted;
    }
    /**
     * 加密手机号
     */
    maskPhone(phone) {
        if (phone.length >= 7) {
            return phone.slice(0, 3) + '****' + phone.slice(-4);
        }
        return '****';
    }
    /**
     * 脱敏银行卡号
     */
    maskCardNo(cardNo) {
        if (cardNo.length >= 8) {
            return cardNo.slice(0, 4) + '****' + cardNo.slice(-4);
        }
        return '****';
    }
}
exports.CiticBankService = CiticBankService;
exports.default = new CiticBankService();
//# sourceMappingURL=citic-bank.service.js.map
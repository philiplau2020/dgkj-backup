/**
 * DGKJ 支付平台 - 邮件通知服务
 *
 * 支持 SMTP 发送邮件
 */
interface EmailResult {
    success: boolean;
    messageId?: string;
    errorCode?: string;
    errorMsg?: string;
}
/**
 * 初始化邮件配置
 */
export declare function initializeEmailConfig(): Promise<void>;
/**
 * 发送邮件
 */
export declare function sendEmail(options: {
    to: string | string[];
    subject: string;
    html: string;
    text?: string;
    attachments?: any[];
}): Promise<EmailResult>;
/**
 * 发送验证码邮件
 */
export declare function sendVerificationEmail(to: string, code: string, expireMinutes?: number): Promise<EmailResult>;
/**
 * 发送密码重置邮件
 */
export declare function sendResetPasswordEmail(to: string, resetLink: string, expireHours?: number): Promise<EmailResult>;
/**
 * 发送商户审核通知
 */
export declare function sendMerchantAuditEmail(to: string, merchantName: string, status: 'approved' | 'rejected', reason?: string): Promise<EmailResult>;
/**
 * 发送交易通知
 */
export declare function sendTradeNotificationEmail(to: string, data: {
    orderNo: string;
    amount: number;
    status: string;
    paidTime?: string;
    payWay: string;
}): Promise<EmailResult>;
/**
 * 发送结算到账通知
 */
export declare function sendSettlementEmail(to: string, data: {
    settleNo: string;
    amount: number;
    fee: number;
    actualAmount: number;
    arriveTime?: string;
}): Promise<EmailResult>;
/**
 * 发送告警邮件
 */
export declare function sendAlertEmail(to: string[], data: {
    level: 'info' | 'warning' | 'error' | 'critical';
    title: string;
    content: string;
    timestamp: string;
}): Promise<EmailResult>;
/**
 * 发送测试邮件
 */
export declare function sendTestEmail(to: string): Promise<EmailResult>;
declare const _default: {
    initializeEmailConfig: typeof initializeEmailConfig;
    sendEmail: typeof sendEmail;
    sendVerificationEmail: typeof sendVerificationEmail;
    sendResetPasswordEmail: typeof sendResetPasswordEmail;
    sendMerchantAuditEmail: typeof sendMerchantAuditEmail;
    sendTradeNotificationEmail: typeof sendTradeNotificationEmail;
    sendSettlementEmail: typeof sendSettlementEmail;
    sendAlertEmail: typeof sendAlertEmail;
    sendTestEmail: typeof sendTestEmail;
};
export default _default;
//# sourceMappingURL=email.service.d.ts.map
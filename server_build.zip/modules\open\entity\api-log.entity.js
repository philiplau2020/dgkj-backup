"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OpApiLog = void 0;
/**
 * API调用日志实体
 */
const typeorm_1 = require("typeorm");
let OpApiLog = class OpApiLog {
};
exports.OpApiLog = OpApiLog;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], OpApiLog.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, comment: '应用ID' }),
    __metadata("design:type", String)
], OpApiLog.prototype, "appId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, comment: '开发者ID' }),
    __metadata("design:type", String)
], OpApiLog.prototype, "developerId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, comment: '商户号' }),
    __metadata("design:type", String)
], OpApiLog.prototype, "mchNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 32, comment: 'Key ID' }),
    __metadata("design:type", String)
], OpApiLog.prototype, "keyId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 10, comment: 'HTTP方法' }),
    __metadata("design:type", String)
], OpApiLog.prototype, "method", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, comment: 'API路径' }),
    __metadata("design:type", String)
], OpApiLog.prototype, "apiPath", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, nullable: true, comment: '业务单号(订单/退款等)' }),
    __metadata("design:type", String)
], OpApiLog.prototype, "bizNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, nullable: true, comment: '关联支付订单号' }),
    __metadata("design:type", String)
], OpApiLog.prototype, "orderNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: ['success', 'fail', 'error', 'pending'], comment: '调用结果' }),
    __metadata("design:type", String)
], OpApiLog.prototype, "result", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', comment: 'HTTP响应码' }),
    __metadata("design:type", Number)
], OpApiLog.prototype, "httpCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 16, comment: '平台响应码' }),
    __metadata("design:type", String)
], OpApiLog.prototype, "code", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true, comment: '响应消息' }),
    __metadata("design:type", String)
], OpApiLog.prototype, "message", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, comment: '响应时间(ms)' }),
    __metadata("design:type", Number)
], OpApiLog.prototype, "responseTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, comment: '请求体大小(字节)' }),
    __metadata("design:type", Number)
], OpApiLog.prototype, "requestSize", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, comment: '响应体大小(字节)' }),
    __metadata("design:type", Number)
], OpApiLog.prototype, "responseSize", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, nullable: true, comment: '客户端IP' }),
    __metadata("design:type", String)
], OpApiLog.prototype, "clientIp", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 500, nullable: true, comment: 'User-Agent' }),
    __metadata("design:type", String)
], OpApiLog.prototype, "userAgent", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true, comment: '请求参数(JSON)' }),
    __metadata("design:type", String)
], OpApiLog.prototype, "requestParams", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true, comment: '响应内容(JSON,截断)' }),
    __metadata("design:type", String)
], OpApiLog.prototype, "responseContent", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, nullable: true, comment: '签名' }),
    __metadata("design:type", String)
], OpApiLog.prototype, "sign", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: ['low', 'medium', 'high'], nullable: true, comment: '安全等级' }),
    __metadata("design:type", String)
], OpApiLog.prototype, "securityLevel", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'datetime' }),
    __metadata("design:type", Date)
], OpApiLog.prototype, "createTime", void 0);
exports.OpApiLog = OpApiLog = __decorate([
    (0, typeorm_1.Entity)('op_api_log'),
    (0, typeorm_1.Index)(['appId', 'createTime']),
    (0, typeorm_1.Index)(['developerId', 'createTime']),
    (0, typeorm_1.Index)(['apiPath', 'createTime']),
    (0, typeorm_1.Index)(['orderNo'])
], OpApiLog);
//# sourceMappingURL=api-log.entity.js.map
"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.notificationService = exports.notificationRoutes = void 0;
/**
 * DGKJ 支付平台 - 统一通知模块入口
 */
var notification_routes_1 = require("./notification.routes");
Object.defineProperty(exports, "notificationRoutes", { enumerable: true, get: function () { return __importDefault(notification_routes_1).default; } });
var notification_service_1 = require("./notification.service");
Object.defineProperty(exports, "notificationService", { enumerable: true, get: function () { return __importDefault(notification_service_1).default; } });
//# sourceMappingURL=index.js.map
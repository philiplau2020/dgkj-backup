"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OpApiQuota = void 0;
/**
 * API配额实体
 */
const typeorm_1 = require("typeorm");
let OpApiQuota = class OpApiQuota {
};
exports.OpApiQuota = OpApiQuota;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], OpApiQuota.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, comment: '应用ID' }),
    __metadata("design:type", String)
], OpApiQuota.prototype, "appId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, comment: '开发者ID' }),
    __metadata("design:type", String)
], OpApiQuota.prototype, "developerId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: ['daily', 'monthly', 'total'], comment: '配额类型' }),
    __metadata("design:type", String)
], OpApiQuota.prototype, "quotaType", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 64, comment: 'API标识(ALL表示全部API)' }),
    __metadata("design:type", String)
], OpApiQuota.prototype, "apiCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, comment: '配额上限' }),
    __metadata("design:type", Number)
], OpApiQuota.prototype, "quotaLimit", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, comment: '已使用量' }),
    __metadata("design:type", Number)
], OpApiQuota.prototype, "quotaUsed", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'datetime', nullable: true, comment: '重置日期' }),
    __metadata("design:type", Date)
], OpApiQuota.prototype, "resetTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: ['second', 'minute', 'hour', 'day', 'month'], default: 'day', comment: '限流窗口' }),
    __metadata("design:type", String)
], OpApiQuota.prototype, "rateLimitWindow", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, comment: '限流阈值(每秒/分/小时)' }),
    __metadata("design:type", Number)
], OpApiQuota.prototype, "rateLimit", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, comment: '限流窗口内已使用' }),
    __metadata("design:type", Number)
], OpApiQuota.prototype, "rateLimitUsed", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ type: 'datetime' }),
    __metadata("design:type", Date)
], OpApiQuota.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ type: 'datetime' }),
    __metadata("design:type", Date)
], OpApiQuota.prototype, "updateTime", void 0);
exports.OpApiQuota = OpApiQuota = __decorate([
    (0, typeorm_1.Entity)('op_api_quota'),
    (0, typeorm_1.Index)(['appId', 'quotaType'])
], OpApiQuota);
//# sourceMappingURL=quota.entity.js.map
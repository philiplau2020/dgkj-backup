import { Request, Response, NextFunction } from 'express';
export declare class TradeController {
    private orderRepo;
    private refundRepo;
    private transferRepo;
    private notifyRepo;
    getOrderList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getOrderById(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    createOrder(req: Request, res: Response, next: NextFunction): Promise<void>;
    closeOrder(req: Request, res: Response, next: NextFunction): Promise<void>;
    getRefundList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createRefund(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    getTransferList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createTransfer(req: Request, res: Response, next: NextFunction): Promise<void>;
    getNotifyList(req: Request, res: Response, next: NextFunction): Promise<void>;
    resendNotify(req: Request, res: Response, next: NextFunction): Promise<void>;
}
declare const _default: TradeController;
export default _default;
//# sourceMappingURL=controller.d.ts.map
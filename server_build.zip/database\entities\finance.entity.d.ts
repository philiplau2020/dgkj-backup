export declare enum AccountType {
    MERCHANT = 1,
    AGENT = 2,
    PLATFORM = 3
}
export declare enum WithdrawStatus {
    PENDING = 0,
    PROCESSING = 1,
    SUCCESS = 2,
    FAILED = 3
}
export declare enum SettleStatus {
    PENDING = 0,
    PROCESSING = 1,
    SUCCESS = 2,
    FAILED = 3
}
export declare class AccountInfo {
    id: string;
    accountNo: string;
    ownerNo: string;
    ownerName: string;
    accountType: AccountType;
    balance: number;
    frozenBalance: number;
    availableBalance: number;
    totalIncome: number;
    totalExpense: number;
    status: number;
    createTime: Date;
    updateTime: Date;
}
export declare class AccountRecord {
    id: string;
    recordNo: string;
    accountNo: string;
    orderNo: string;
    bizNo: string;
    bizType: number;
    bizTypeName: string;
    amount: number;
    balanceBefore: number;
    balanceAfter: number;
    changeType: number;
    remark: string;
    createTime: Date;
}
export declare class AccountSettlement {
    id: string;
    settleNo: string;
    accountNo: string;
    ownerNo: string;
    ownerName: string;
    bankName: string;
    bankAccount: string;
    bankUsername: string;
    amount: number;
    fee: number;
    actualAmount: number;
    settleType: number;
    settleCycle: string;
    status: SettleStatus;
    failReason: string;
    settleTime: Date;
    completeTime: Date;
    remark: string;
    createTime: Date;
    updateTime: Date;
}
export declare class AccountWithdraw {
    id: string;
    withdrawNo: string;
    accountNo: string;
    ownerNo: string;
    ownerName: string;
    amount: number;
    fee: number;
    actualAmount: number;
    bankName: string;
    bankAccount: string;
    bankUsername: string;
    status: WithdrawStatus;
    failReason: string;
    completeTime: Date;
    remark: string;
    createTime: Date;
    updateTime: Date;
}
export declare class AccountStatement {
    id: string;
    statementNo: string;
    accountNo: string;
    statementDate: Date;
    beginBalance: number;
    totalIncome: number;
    totalExpense: number;
    endBalance: number;
    orderCount: number;
    successCount: number;
    refundCount: number;
    status: number;
    createTime: Date;
}
//# sourceMappingURL=finance.entity.d.ts.map
/**
 * DGKJ 支付平台 - 支付核心服务
 *
 * 统一的支付服务，处理所有支付请求
 */
/**
 * 支付服务
 */
export declare class PayService {
    private orderRepo;
    private refundRepo;
    private transferRepo;
    private notifyRepo;
    private mchRepo;
    private appRepo;
    private channelRepo;
    private rateRepo;
    /**
     * 创建支付订单
     */
    createOrder(params: {
        mchNo: string;
        appId: string;
        payWay: string;
        amount: number;
        subject: string;
        body?: string;
        clientIp?: string;
        attach?: string;
        notifyUrl?: string;
        returnUrl?: string;
        openId?: string;
        buyerId?: string;
    }): Promise<import("../../utils/op-code").OpResult<any>>;
    /**
     * 查询订单
     */
    queryOrder(orderNo: string): Promise<import("../../utils/op-code").OpResult<any>>;
    /**
     * 关闭订单
     */
    closeOrder(orderNo: string): Promise<import("../../utils/op-code").OpResult<any>>;
    /**
     * 申请退款
     */
    applyRefund(params: {
        orderNo: string;
        refundAmount: number;
        refundReason?: string;
    }): Promise<import("../../utils/op-code").OpResult<any>>;
    /**
     * 支付回调处理
     */
    handleCallback(channelCode: string, data: any): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * 处理支付回调
     */
    private handlePayCallback;
    /**
     * 处理退款回调
     */
    private handleRefundCallback;
    /**
     * 发送商户通知
     */
    private sendMchNotify;
    /**
     * 选择支付通道
     */
    private selectChannel;
    /**
     * 生成订单号
     */
    private generateOrderNo;
    /**
     * 生成退款单号
     */
    private generateRefundNo;
    /**
     * 格式化订单
     */
    private formatOrder;
}
declare const _default: PayService;
export default _default;
//# sourceMappingURL=pay.service.d.ts.map
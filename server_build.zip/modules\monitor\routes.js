"use strict";
/**
 * DGKJ 支付平台 - 运维监控路由
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const monitor_service_1 = __importDefault(require("./monitor.service"));
const auth_middleware_1 = require("../../common/middleware/auth.middleware");
const router = (0, express_1.Router)();
// ==================== 系统监控 ====================
/**
 * GET /basic-api/monitor/server/overview
 * 获取服务器概览
 */
router.get('/server/overview', auth_middleware_1.authGuard, async (req, res) => {
    try {
        const data = await monitor_service_1.default.getServerOverview();
        res.json({ code: 0, message: 'ok', data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
/**
 * GET /basic-api/monitor/server/list
 * 获取服务器列表
 */
router.get('/server/list', auth_middleware_1.authGuard, async (req, res) => {
    try {
        const { page = 1, pageSize = 10 } = req.query;
        const data = await monitor_service_1.default.getServerList({
            page: parseInt(page),
            pageSize: parseInt(pageSize),
        });
        res.json({ code: 0, message: 'ok', data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
/**
 * GET /basic-api/monitor/server/detail
 * 获取服务器详情
 */
router.get('/server/detail', auth_middleware_1.authGuard, async (req, res) => {
    try {
        const { id } = req.query;
        const data = await monitor_service_1.default.getServerDetail(id);
        res.json({ code: 0, message: 'ok', data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
// ==================== 服务监控 ====================
/**
 * GET /basic-api/monitor/service/list
 * 获取服务列表
 */
router.get('/service/list', auth_middleware_1.authGuard, async (req, res) => {
    try {
        const data = await monitor_service_1.default.getServiceList();
        res.json({ code: 0, message: 'ok', data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
/**
 * GET /basic-api/monitor/service/detail
 * 获取服务详情
 */
router.get('/service/detail', auth_middleware_1.authGuard, async (req, res) => {
    try {
        const { id } = req.query;
        const data = await monitor_service_1.default.getServiceDetail(id);
        res.json({ code: 0, message: 'ok', data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
// ==================== 应用指标 ====================
/**
 * GET /basic-api/monitor/metrics
 * 获取应用指标
 */
router.get('/metrics', auth_middleware_1.authGuard, async (req, res) => {
    try {
        const data = await monitor_service_1.default.getAppMetrics();
        res.json({ code: 0, message: 'ok', data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
// ==================== 网络监控 ====================
/**
 * GET /basic-api/monitor/network/list
 * 获取网络接口列表
 */
router.get('/network/list', auth_middleware_1.authGuard, async (req, res) => {
    try {
        const data = await monitor_service_1.default.getNetworkList();
        res.json({ code: 0, message: 'ok', data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
// ==================== 日志管理 ====================
/**
 * GET /basic-api/monitor/log/list
 * 获取日志列表
 */
router.get('/log/list', auth_middleware_1.authGuard, async (req, res) => {
    try {
        const { page = 1, pageSize = 20, level, serviceName, keyword, startTime, endTime } = req.query;
        const data = await monitor_service_1.default.getLogList({
            page: parseInt(page),
            pageSize: parseInt(pageSize),
            level: level,
            serviceName: serviceName,
            keyword: keyword,
            startTime: startTime,
            endTime: endTime,
        });
        res.json({ code: 0, message: 'ok', data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
/**
 * GET /basic-api/monitor/log/statistics
 * 获取日志统计
 */
router.get('/log/statistics', auth_middleware_1.authGuard, async (req, res) => {
    try {
        const data = await monitor_service_1.default.getLogStatistics();
        res.json({ code: 0, message: 'ok', data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
// ==================== 告警管理 ====================
/**
 * GET /basic-api/monitor/alert/list
 * 获取告警列表
 */
router.get('/alert/list', auth_middleware_1.authGuard, async (req, res) => {
    try {
        const { page = 1, pageSize = 10, level, status } = req.query;
        const data = await monitor_service_1.default.getAlertList({
            page: parseInt(page),
            pageSize: parseInt(pageSize),
            level: level,
            status: status,
        });
        res.json({ code: 0, message: 'ok', data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
/**
 * GET /basic-api/monitor/alert/rules
 * 获取告警规则
 */
router.get('/alert/rules', auth_middleware_1.authGuard, async (req, res) => {
    try {
        const data = await monitor_service_1.default.getAlertRules();
        res.json({ code: 0, message: 'ok', data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
// ==================== 业务概览 ====================
/**
 * GET /basic-api/monitor/business/overview
 * 获取业务概览
 */
router.get('/business/overview', auth_middleware_1.authGuard, async (req, res) => {
    try {
        const data = await monitor_service_1.default.getBusinessOverview();
        res.json({ code: 0, message: 'ok', data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
/**
 * GET /basic-api/monitor/business/trend
 * 获取业务趋势
 */
router.get('/business/trend', auth_middleware_1.authGuard, async (req, res) => {
    try {
        const { days = 7 } = req.query;
        const data = await monitor_service_1.default.getBusinessTrend({
            days: parseInt(days),
        });
        res.json({ code: 0, message: 'ok', data });
    }
    catch (error) {
        res.json({ code: 500, message: error.message, data: null });
    }
});
exports.default = router;
//# sourceMappingURL=routes.js.map
/**
 * DGKJ 支付平台 - 运维监控系统
 *
 * 真实的服务器监控、服务监控、应用监控实现
 */
/**
 * 获取服务器概览
 */
export declare function getServerOverview(): Promise<{
    serverCount: number;
    serverOnline: number;
    serviceCount: number;
    serviceRunning: number;
    alertCount: number;
    cpuUsage: string;
    memUsage: {
        total: number;
        used: number;
        free: number;
        percent: string;
    };
    diskUsage: {
        total: number;
        used: number;
        free: number;
        percent: number;
    };
    networkIn: number;
    networkOut: number;
    uptime: number;
    timestamp: string;
}>;
/**
 * 获取服务器列表
 */
export declare function getServerList(params: {
    page?: number;
    pageSize?: number;
}): Promise<{
    list: {
        id: string;
        hostname: string;
        ip: string;
        os: string;
        cpuModel: string;
        cpuCores: number;
        cpuUsage: string;
        memTotal: number;
        memUsed: number;
        memUsage: string;
        diskTotal: number;
        diskUsed: number;
        diskUsage: number;
        status: string;
        role: string;
        lastHeartbeat: string;
        uptime: number;
    }[];
    total: number;
    page: number;
    pageSize: number;
}>;
/**
 * 获取服务器详情
 */
export declare function getServerDetail(id: string): Promise<{
    id: string;
    hostname: string;
    ip: string;
    os: string;
    cpuModel: string;
    cpuCores: number;
    cpuUsage: string;
    memTotal: number;
    memUsed: number;
    memUsage: string;
    diskUsage: {
        total: number;
        used: number;
        free: number;
        percent: number;
    };
    networkIn: number;
    networkOut: number;
    status: string;
    role: string;
    lastHeartbeat: string;
    uptime: number;
}>;
/**
 * 获取服务列表
 */
export declare function getServiceList(): Promise<{
    list: any[];
    total: number;
}>;
/**
 * 获取服务详情
 */
export declare function getServiceDetail(id: string): Promise<any>;
/**
 * 获取应用指标
 */
export declare function getAppMetrics(): Promise<{
    id: string;
    name: string;
    group: string;
    requests: number;
    errors: number;
    avgResponseTime: number;
    p99ResponseTime: number;
    qps: number;
    concurrency: number;
    cpuUsage: number;
    memUsage: number;
    jvmHeapUsed: number;
    jvmHeapMax: number;
    jvmHeapUsage: string;
    threadCount: number;
    gcCount: number;
    dbActive: number;
    dbIdle: number;
    timestamp: string;
}[]>;
/**
 * 获取网络接口列表
 */
export declare function getNetworkList(): Promise<{
    list: any[];
    total: number;
}>;
/**
 * 获取日志列表
 */
export declare function getLogList(params: {
    page?: number;
    pageSize?: number;
    level?: string;
    serviceName?: string;
    keyword?: string;
    startTime?: string;
    endTime?: string;
}): Promise<{
    list: {
        id: string;
        timestamp: string;
        level: string;
        source: string;
        serviceName: string;
        host: string;
        message: string;
        traceId: string;
        spanId: string;
    }[];
    total: number;
    page: number;
    pageSize: number;
}>;
/**
 * 获取日志统计
 */
export declare function getLogStatistics(): Promise<{
    totalCount: number;
    todayCount: number;
    errorCount: number;
    warnCount: number;
    infoCount: number;
    levels: {
        DEBUG: number;
        INFO: number;
        WARN: number;
        ERROR: number;
        FATAL: number;
    };
    services: {
        'dgkj-api': number;
        nginx: number;
        mysql: number;
    };
    timestamp: string;
}>;
/**
 * 获取告警列表
 */
export declare function getAlertList(params: {
    page?: number;
    pageSize?: number;
    level?: string;
    status?: string;
}): Promise<{
    list: any[];
    total: number;
    page: number;
    pageSize: number;
}>;
/**
 * 获取告警规则
 */
export declare function getAlertRules(): Promise<{
    list: {
        id: string;
        name: string;
        metric: string;
        threshold: number;
        level: string;
        enabled: boolean;
    }[];
    total: number;
}>;
/**
 * 生成系统告警
 */
export declare function generateSystemAlerts(): Promise<any[]>;
/**
 * 获取业务概览
 */
export declare function getBusinessOverview(): Promise<{
    orderCount: number;
    orderAmount: number;
    successRate: number;
    avgResponseTime: number;
    activeUsers: number;
    activeConnections: number;
    queueLength: number;
    cacheHitRate: number;
    timestamp: string;
}>;
/**
 * 获取业务趋势
 */
export declare function getBusinessTrend(params: {
    days?: number;
}): Promise<any[]>;
declare const _default: {
    getServerOverview: typeof getServerOverview;
    getServerList: typeof getServerList;
    getServerDetail: typeof getServerDetail;
    getServiceList: typeof getServiceList;
    getServiceDetail: typeof getServiceDetail;
    getAppMetrics: typeof getAppMetrics;
    getNetworkList: typeof getNetworkList;
    getLogList: typeof getLogList;
    getLogStatistics: typeof getLogStatistics;
    getAlertList: typeof getAlertList;
    getAlertRules: typeof getAlertRules;
    getBusinessOverview: typeof getBusinessOverview;
    getBusinessTrend: typeof getBusinessTrend;
};
export default _default;
//# sourceMappingURL=monitor.service.d.ts.map
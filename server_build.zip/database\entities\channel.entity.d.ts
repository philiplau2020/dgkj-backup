export declare enum ChannelStatus {
    DISABLED = 0,
    ENABLED = 1
}
export declare class ChannelInfo {
    id: string;
    channelCode: string;
    channelName: string;
    channelShortName: string;
    channelType: string;
    provider: string;
    appId: string;
    appSecret: string;
    mchId: string;
    apiKey: string;
    publicKey: string;
    privateKey: string;
    payUrl: string;
    notifyUrl: string;
    queryUrl: string;
    settleUrl: string;
    logo: string;
    config: any;
    status: ChannelStatus;
    remark: string;
    createTime: Date;
    updateTime: Date;
}
export declare class ChannelMch {
    id: string;
    channelCode: string;
    channelMchId: string;
    mchNo: string;
    mchName: string;
    appId: string;
    appSecret: string;
    status: number;
    remark: string;
    createTime: Date;
    updateTime: Date;
}
export declare class ChannelRoute {
    id: string;
    routeName: string;
    routeCode: string;
    payType: string;
    priority: number;
    channelCodes: string;
    routeType: number;
    routeRule: any;
    status: number;
    remark: string;
    createTime: Date;
    updateTime: Date;
}
export declare class PoolStrategy {
    id: string;
    strategyName: string;
    strategyCode: string;
    strategyType: number;
    channelCode: string;
    weight: number;
    maxAmount: number;
    minAmount: number;
    timeRange: any;
    weekDays: any;
    status: number;
    remark: string;
    createTime: Date;
    updateTime: Date;
}
export declare class PoolChannel {
    id: string;
    poolId: string;
    channelCode: string;
    weight: number;
    status: number;
    createTime: Date;
}
export declare class PoolConfig {
    id: string;
    poolName: string;
    poolCode: string;
    poolType: number;
    description: string;
    status: number;
    createTime: Date;
    updateTime: Date;
}
//# sourceMappingURL=channel.entity.d.ts.map
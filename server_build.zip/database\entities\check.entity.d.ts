/** 对账批次状态 */
export declare enum CheckBatchStatus {
    PROCESSING = 0,// 处理中
    SUCCESS = 1,// 成功
    DIFF_FOUND = 2,// 有差异
    FAILED = 3
}
export declare class CheckBatch {
    id: string;
    batchNo: string;
    checkDate: string;
    channelCode: string;
    channelName: string;
    platformOrderCount: number;
    platformTotalAmount: number;
    channelOrderCount: number;
    channelTotalAmount: number;
    diffOrderCount: number;
    diffAmount: number;
    status: CheckBatchStatus;
    completeTime: Date;
    remark: string;
    createTime: Date;
    updateTime: Date;
}
export declare class CheckChannelBill {
    id: string;
    batchNo: string;
    channelCode: string;
    orderNo: string;
    channelOrderNo: string;
    amount: number;
    fee: number;
    status: string;
    createTime: Date;
}
export declare class CheckDiffBill {
    id: string;
    batchNo: string;
    orderNo: string;
    channelOrderNo: string;
    diffType: number;
    platformAmount: number;
    channelAmount: number;
    diffAmount: number;
    platformStatus: string;
    channelStatus: string;
    handleStatus: number;
    handleRemark: string;
    handleTime: Date;
    remark: string;
    createTime: Date;
    updateTime: Date;
}
//# sourceMappingURL=check.entity.d.ts.map
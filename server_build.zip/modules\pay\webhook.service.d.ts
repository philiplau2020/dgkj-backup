/**
 * DGKJ 支付平台 - Webhook 通知服务
 *
 * 向商户系统发送支付结果通知
 */
/**
 * Webhook 通知数据
 */
export interface WebhookData {
    /** 通知类型: pay | refund | transfer */
    type: 'pay' | 'refund' | 'transfer';
    /** 通知ID */
    notifyId: string;
    /** 商户订单号 */
    orderNo: string;
    /** 平台订单号 */
    platformOrderNo?: string;
    /** 通道订单号 */
    channelOrderNo?: string;
    /** 商户号 */
    mchNo: string;
    /** 订单金额 (分) */
    amount: number;
    /** 实际支付金额 (分) */
    paidAmount?: number;
    /** 状态 */
    status: string;
    /** 支付时间 */
    paidTime?: string;
    /** 附加数据 */
    attach?: string;
    /** 错误信息 */
    errorMsg?: string;
    /** 签名 */
    sign?: string;
    /** 时间戳 */
    timestamp: string;
}
/**
 * 发送 Webhook 通知
 */
export declare function sendWebhookNotification(url: string, data: {
    type: 'pay' | 'refund' | 'transfer';
    orderNo: string;
    mchNo: string;
    amount: number;
    paidAmount?: number;
    status: string;
    paidTime?: string;
    attach?: string;
}, secret?: string): Promise<{
    success: boolean;
    notifyId: string;
}>;
/**
 * 验证签名
 */
export declare function verifySign(data: Record<string, any>, sign: string, secret: string): boolean;
/**
 * 查询通知状态
 */
export declare function getNotifyStatus(notifyId: string): Promise<{
    notifyId: string;
    orderNo: string;
    status: string;
    notifyCount: number;
    lastNotifyTime: Date;
    nextNotifyTime: Date;
    responseResult: string;
}>;
/**
 * 手动重试通知
 */
export declare function retryNotify(notifyId: string): Promise<boolean>;
declare const _default: {
    sendWebhookNotification: typeof sendWebhookNotification;
    verifySign: typeof verifySign;
    getNotifyStatus: typeof getNotifyStatus;
    retryNotify: typeof retryNotify;
};
export default _default;
//# sourceMappingURL=webhook.service.d.ts.map
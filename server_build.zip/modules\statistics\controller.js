"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatisticsController = void 0;
const data_source_1 = require("../../config/data-source");
const statistics_entity_1 = require("../../database/entities/statistics.entity");
const trade_entity_1 = require("../../database/entities/trade.entity");
class StatisticsController {
    constructor() {
        this.tradeRepo = data_source_1.AppDataSource.getRepository(statistics_entity_1.StatTrade);
        this.mchRepo = data_source_1.AppDataSource.getRepository(statistics_entity_1.StatMch);
        this.agentRepo = data_source_1.AppDataSource.getRepository(statistics_entity_1.StatAgent);
        this.channelRepo = data_source_1.AppDataSource.getRepository(statistics_entity_1.StatChannel);
        this.financeRepo = data_source_1.AppDataSource.getRepository(statistics_entity_1.StatFinance);
    }
    // ============== Dashboard Stats ==============
    async getDashboardStats(req, res, next) {
        try {
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            const tradeRepo = data_source_1.AppDataSource.getRepository(trade_entity_1.PayOrder);
            // Today's trade stats
            const todayStats = await tradeRepo.createQueryBuilder('order')
                .select('COUNT(*)', 'totalCount')
                .addSelect('SUM(CASE WHEN order.status = 1 THEN 1 ELSE 0 END)', 'successCount')
                .addSelect('SUM(CASE WHEN order.status = 1 THEN order.amount ELSE 0 END)', 'successAmount')
                .where('order.createTime >= :today', { today })
                .getRawOne();
            // Yesterday's trade stats
            const yesterday = new Date(today);
            yesterday.setDate(yesterday.getDate() - 1);
            const yesterdayStats = await tradeRepo.createQueryBuilder('order')
                .select('SUM(CASE WHEN order.status = 1 THEN 1 ELSE 0 END)', 'successCount')
                .addSelect('SUM(CASE WHEN order.status = 1 THEN order.amount ELSE 0 END)', 'successAmount')
                .where('order.createTime >= :yesterday AND order.createTime < :today', { yesterday, today })
                .getRawOne();
            // This month's stats
            const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
            const monthStats = await tradeRepo.createQueryBuilder('order')
                .select('SUM(CASE WHEN order.status = 1 THEN 1 ELSE 0 END)', 'successCount')
                .addSelect('SUM(CASE WHEN order.status = 1 THEN order.amount ELSE 0 END)', 'successAmount')
                .addSelect('SUM(CASE WHEN order.status = 5 THEN 1 ELSE 0 END)', 'refundCount')
                .addSelect('SUM(CASE WHEN order.status = 5 THEN order.amount ELSE 0 END)', 'refundAmount')
                .where('order.createTime >= :monthStart', { monthStart })
                .getRawOne();
            // Count stats
            const mchCount = await data_source_1.AppDataSource.getRepository('MchInfo').count();
            const agentCount = await data_source_1.AppDataSource.getRepository('AgentInfo').count();
            const orderCount = await tradeRepo.count();
            res.json({
                code: 0,
                message: 'success',
                data: {
                    today: {
                        totalCount: Number(todayStats.totalCount) || 0,
                        successCount: Number(todayStats.successCount) || 0,
                        successAmount: Number(todayStats.successAmount) || 0,
                    },
                    yesterday: {
                        successCount: Number(yesterdayStats.successCount) || 0,
                        successAmount: Number(yesterdayStats.successAmount) || 0,
                    },
                    month: {
                        successCount: Number(monthStats.successCount) || 0,
                        successAmount: Number(monthStats.successAmount) || 0,
                        refundCount: Number(monthStats.refundCount) || 0,
                        refundAmount: Number(monthStats.refundAmount) || 0,
                    },
                    counts: {
                        mchCount,
                        agentCount,
                        orderCount,
                    },
                },
                timestamp: new Date().toISOString(),
            });
        }
        catch (error) {
            next(error);
        }
    }
    // ============== Trade Statistics ==============
    async getTradeStatList(req, res, next) {
        try {
            const { page = 1, pageSize = 10, startDate, endDate, channelCode, payType } = req.query;
            const skip = (Number(page) - 1) * Number(pageSize);
            const queryBuilder = this.tradeRepo.createQueryBuilder('stat');
            if (startDate)
                queryBuilder.andWhere('stat.statDate >= :startDate', { startDate });
            if (endDate)
                queryBuilder.andWhere('stat.statDate <= :endDate', { endDate });
            if (channelCode)
                queryBuilder.andWhere('stat.channelCode = :channelCode', { channelCode });
            if (payType)
                queryBuilder.andWhere('stat.payType = :payType', { payType });
            const [list, total] = await queryBuilder.skip(skip).take(Number(pageSize)).orderBy('stat.statDate', 'DESC').getManyAndCount();
            res.json({ code: 0, message: 'success', data: { list, total }, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    // ============== Merchant Statistics ==============
    async getMchStatList(req, res, next) {
        try {
            const { page = 1, pageSize = 10, startDate, endDate } = req.query;
            const skip = (Number(page) - 1) * Number(pageSize);
            const queryBuilder = this.mchRepo.createQueryBuilder('stat');
            if (startDate)
                queryBuilder.andWhere('stat.statDate >= :startDate', { startDate });
            if (endDate)
                queryBuilder.andWhere('stat.statDate <= :endDate', { endDate });
            const [list, total] = await queryBuilder.skip(skip).take(Number(pageSize)).orderBy('stat.statDate', 'DESC').getManyAndCount();
            res.json({ code: 0, message: 'success', data: { list, total }, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    // ============== Agent Statistics ==============
    async getAgentStatList(req, res, next) {
        try {
            const { page = 1, pageSize = 10, startDate, endDate } = req.query;
            const skip = (Number(page) - 1) * Number(pageSize);
            const queryBuilder = this.agentRepo.createQueryBuilder('stat');
            if (startDate)
                queryBuilder.andWhere('stat.statDate >= :startDate', { startDate });
            if (endDate)
                queryBuilder.andWhere('stat.statDate <= :endDate', { endDate });
            const [list, total] = await queryBuilder.skip(skip).take(Number(pageSize)).orderBy('stat.statDate', 'DESC').getManyAndCount();
            res.json({ code: 0, message: 'success', data: { list, total }, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    // ============== Channel Statistics ==============
    async getChannelStatList(req, res, next) {
        try {
            const { page = 1, pageSize = 10, startDate, endDate } = req.query;
            const skip = (Number(page) - 1) * Number(pageSize);
            const queryBuilder = this.channelRepo.createQueryBuilder('stat');
            if (startDate)
                queryBuilder.andWhere('stat.statDate >= :startDate', { startDate });
            if (endDate)
                queryBuilder.andWhere('stat.statDate <= :endDate', { endDate });
            const [list, total] = await queryBuilder.skip(skip).take(Number(pageSize)).orderBy('stat.statDate', 'DESC').getManyAndCount();
            res.json({ code: 0, message: 'success', data: { list, total }, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    // ============== Finance Statistics ==============
    async getFinanceStatList(req, res, next) {
        try {
            const { page = 1, pageSize = 10, startDate, endDate } = req.query;
            const skip = (Number(page) - 1) * Number(pageSize);
            const queryBuilder = this.financeRepo.createQueryBuilder('stat');
            if (startDate)
                queryBuilder.andWhere('stat.statDate >= :startDate', { startDate });
            if (endDate)
                queryBuilder.andWhere('stat.statDate <= :endDate', { endDate });
            const [list, total] = await queryBuilder.skip(skip).take(Number(pageSize)).orderBy('stat.statDate', 'DESC').getManyAndCount();
            res.json({ code: 0, message: 'success', data: { list, total }, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    // ============== Trade Trend ==============
    async getTradeTrend(req, res, next) {
        try {
            const { startDate, endDate, type = 'daily' } = req.query;
            const orderRepo = data_source_1.AppDataSource.getRepository(trade_entity_1.PayOrder);
            let dateFormat = '%Y-%m-%d';
            if (type === 'weekly')
                dateFormat = '%Y-%u';
            if (type === 'monthly')
                dateFormat = '%Y-%m';
            const data = await orderRepo.createQueryBuilder('order')
                .select(`DATE_FORMAT(order.createTime, '${dateFormat}')`, 'date')
                .addSelect('COUNT(*)', 'count')
                .addSelect('SUM(CASE WHEN order.status = 1 THEN 1 ELSE 0 END)', 'successCount')
                .addSelect('SUM(CASE WHEN order.status = 1 THEN order.amount ELSE 0 END)', 'amount')
                .where('order.createTime >= :startDate', { startDate: startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) })
                .andWhere('order.createTime <= :endDate', { endDate: endDate || new Date() })
                .groupBy(`DATE_FORMAT(order.createTime, '${dateFormat}')`)
                .orderBy('date', 'ASC')
                .getRawMany();
            res.json({ code: 0, message: 'success', data, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
    // ============== Pay Type Stats ==============
    async getPayTypeStats(req, res, next) {
        try {
            const { startDate, endDate } = req.query;
            const orderRepo = data_source_1.AppDataSource.getRepository(trade_entity_1.PayOrder);
            const data = await orderRepo.createQueryBuilder('order')
                .select('order.payType', 'payType')
                .addSelect('COUNT(*)', 'count')
                .addSelect('SUM(CASE WHEN order.status = 1 THEN 1 ELSE 0 END)', 'successCount')
                .addSelect('SUM(CASE WHEN order.status = 1 THEN order.amount ELSE 0 END)', 'amount')
                .where('order.createTime >= :startDate', { startDate: startDate || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) })
                .andWhere('order.createTime <= :endDate', { endDate: endDate || new Date() })
                .groupBy('order.payType')
                .getRawMany();
            res.json({ code: 0, message: 'success', data, timestamp: new Date().toISOString() });
        }
        catch (error) {
            next(error);
        }
    }
}
exports.StatisticsController = StatisticsController;
exports.default = new StatisticsController();
//# sourceMappingURL=controller.js.map
/**
 * DGKJ 支付平台 - 设备管理服务
 *
 * 支持设备注册、激活、绑定、解绑、固件管理
 */
export declare class DeviceService {
    private deviceRepo;
    /**
     * 注册设备
     */
    registerDevice(params: {
        deviceNo: string;
        deviceType: number;
        deviceModel: string;
        manufacturer: string;
        mchNo?: string;
    }): Promise<any>;
    /**
     * 激活设备
     */
    activateDevice(params: {
        deviceNo: string;
        mchNo: string;
        storeId?: string;
    }): Promise<any>;
    /**
     * 设备心跳
     */
    heartbeat(deviceNo: string, params: {
        firmwareVersion?: string;
        batteryLevel?: number;
        deviceIp?: string;
    }): Promise<any>;
    /**
     * 获取设备列表
     */
    getDeviceList(params: {
        page?: number;
        pageSize?: number;
        mchNo?: string;
        status?: number;
        deviceType?: number;
        keyword?: string;
    }): Promise<any>;
    /**
     * 获取设备详情
     */
    getDeviceDetail(id: string): Promise<any>;
    /**
     * 更新设备信息
     */
    updateDevice(id: string, params: {
        deviceName?: string;
        storeId?: string;
        remark?: string;
    }): Promise<any>;
    /**
     * 绑定商户
     */
    bindMerchant(id: string, mchNo: string): Promise<any>;
    /**
     * 解绑设备
     */
    unbindDevice(id: string): Promise<any>;
    /**
     * 禁用设备
     */
    disableDevice(id: string, reason: string): Promise<any>;
    /**
     * 启用设备
     */
    enableDevice(id: string): Promise<any>;
    /**
     * 报损设备
     */
    reportDamage(id: string, reason: string): Promise<any>;
    /**
     * 生成设备二维码
     */
    generateDeviceQR(id: string): Promise<any>;
    /**
     * 获取设备交易统计
     */
    getDeviceStats(id: string): Promise<any>;
    /**
     * 生成设备密钥
     */
    private generateDeviceSecret;
    /**
     * 格式化设备信息
     */
    private formatDevice;
}
declare const _default: DeviceService;
export default _default;
//# sourceMappingURL=device.service.d.ts.map
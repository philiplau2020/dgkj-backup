"use strict";
/**
 * DGKJ 支付平台 - 支付回调路由
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const pay_service_1 = __importDefault(require("./pay.service"));
const router = (0, express_1.Router)();
/**
 * 微信支付回调
 * POST /basic-api/pay/callback/wechat
 */
router.post('/callback/wechat', async (req, res) => {
    try {
        const result = await pay_service_1.default.handleCallback('wechat', req.body);
        if (result.success) {
            res.type('xml').send(result.message || 'success');
        }
        else {
            res.type('xml').status(400).send(result.message || 'fail');
        }
    }
    catch (error) {
        console.error('微信支付回调处理失败:', error);
        res.type('xml').status(500).send('error');
    }
});
/**
 * 支付宝回调
 * POST /basic-api/pay/callback/alipay
 */
router.post('/callback/alipay', async (req, res) => {
    try {
        const result = await pay_service_1.default.handleCallback('alipay', req.body);
        if (result.success) {
            res.send('success');
        }
        else {
            res.status(400).send('fail');
        }
    }
    catch (error) {
        console.error('支付宝回调处理失败:', error);
        res.status(500).send('error');
    }
});
/**
 * 银联支付回调
 * POST /basic-api/pay/callback/unionpay
 */
router.post('/callback/unionpay', async (req, res) => {
    try {
        const result = await pay_service_1.default.handleCallback('unionpay', req.body);
        if (result.success) {
            res.json({ status: 'success' });
        }
        else {
            res.status(400).json({ status: 'fail', message: result.message });
        }
    }
    catch (error) {
        console.error('银联支付回调处理失败:', error);
        res.status(500).json({ status: 'error' });
    }
});
/**
 * 通用回调处理
 * POST /basic-api/pay/callback/:channelCode
 */
router.post('/callback/:channelCode', async (req, res) => {
    try {
        const { channelCode } = req.params;
        const result = await pay_service_1.default.handleCallback(channelCode, req.body);
        if (result.success) {
            res.json({ code: 'SUCCESS', message: '处理成功' });
        }
        else {
            res.status(400).json({ code: 'FAIL', message: result.message });
        }
    }
    catch (error) {
        console.error('支付回调处理失败:', error);
        res.status(500).json({ code: 'ERROR', message: error.message });
    }
});
exports.default = router;
//# sourceMappingURL=callback.routes.js.map
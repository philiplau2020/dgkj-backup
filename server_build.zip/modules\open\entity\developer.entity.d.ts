export declare class OpDeveloper {
    id: string;
    developerId: string;
    developerName: string;
    username: string;
    password: string;
    email: string;
    mobile: string;
    company: string;
    businessLicense: string;
    businessLicenseUrl: string;
    contactPerson: string;
    contactPhone: string;
    description: string;
    website: string;
    status: 'pending' | 'active' | 'suspended' | 'rejected';
    level: 'trial' | 'basic' | 'professional' | 'enterprise';
    appCount: number;
    totalCallCount: number;
    lastLoginTime: Date;
    lastLoginIp: string;
    reviewTime: Date;
    reviewBy: string;
    reviewRemark: string;
    createTime: Date;
    updateTime: Date;
}
//# sourceMappingURL=developer.entity.d.ts.map
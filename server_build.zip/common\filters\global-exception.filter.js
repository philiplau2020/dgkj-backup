"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotFoundException = exports.ForbiddenException = exports.UnauthorizedException = exports.BadRequestException = exports.ApiException = void 0;
exports.errorHandler = errorHandler;
class ApiException extends Error {
    constructor(code = 500, message = 'Internal server error', data) {
        super(message);
        this.code = code;
        this.message = message;
        this.data = data;
        this.name = 'ApiException';
    }
}
exports.ApiException = ApiException;
class BadRequestException extends ApiException {
    constructor(message = 'Bad request') {
        super(400, message);
    }
}
exports.BadRequestException = BadRequestException;
class UnauthorizedException extends ApiException {
    constructor(message = 'Unauthorized') {
        super(401, message);
    }
}
exports.UnauthorizedException = UnauthorizedException;
class ForbiddenException extends ApiException {
    constructor(message = 'Forbidden') {
        super(403, message);
    }
}
exports.ForbiddenException = ForbiddenException;
class NotFoundException extends ApiException {
    constructor(message = 'Resource not found') {
        super(404, message);
    }
}
exports.NotFoundException = NotFoundException;
function errorHandler(err, req, res, next) {
    console.error('Error:', err.message);
    if (err instanceof ApiException) {
        const response = {
            code: err.code,
            message: err.message,
            data: err.data,
            timestamp: new Date().toISOString(),
        };
        res.status(err.code);
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify(response));
        return;
    }
    // Validation errors
    if (err.name === 'ValidationError') {
        const response = {
            code: 400,
            message: err.message,
            data: null,
            timestamp: new Date().toISOString(),
        };
        res.status(400);
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify(response));
        return;
    }
    // Default error
    const response = {
        code: 500,
        message: process.env.NODE_ENV === 'development' ? err.message : 'Internal server error',
        data: null,
        timestamp: new Date().toISOString(),
    };
    res.status(500);
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(response));
}
//# sourceMappingURL=global-exception.filter.js.map
import { Request, Response, NextFunction } from 'express';
export declare class AgentController {
    private agentRepo;
    private profitRepo;
    private withdrawRepo;
    getAgentList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getAgentById(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    createAgent(req: Request, res: Response, next: NextFunction): Promise<void>;
    updateAgent(req: Request, res: Response, next: NextFunction): Promise<void>;
    reviewAgent(req: Request, res: Response, next: NextFunction): Promise<void>;
    getProfitList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getWithdrawList(req: Request, res: Response, next: NextFunction): Promise<void>;
    createWithdraw(req: Request, res: Response, next: NextFunction): Promise<void>;
    reviewWithdraw(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    getAuditList(req: Request, res: Response, next: NextFunction): Promise<void>;
    getAgentInfo(req: Request, res: Response, next: NextFunction): Promise<Response<any, Record<string, any>>>;
    getAgentStats(req: Request, res: Response, next: NextFunction): Promise<void>;
}
declare const _default: AgentController;
export default _default;
//# sourceMappingURL=controller.d.ts.map
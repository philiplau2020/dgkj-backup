"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SysNotice = exports.SysLog = exports.SysConfig = exports.SysDictData = exports.SysDict = exports.SysRoleMenu = exports.SysUserRole = exports.SysMenu = exports.SysDept = exports.SysRole = exports.SysUser = exports.UserType = exports.UserStatus = void 0;
const typeorm_1 = require("typeorm");
var UserStatus;
(function (UserStatus) {
    UserStatus[UserStatus["DISABLED"] = 0] = "DISABLED";
    UserStatus[UserStatus["ENABLED"] = 1] = "ENABLED";
})(UserStatus || (exports.UserStatus = UserStatus = {}));
var UserType;
(function (UserType) {
    UserType[UserType["SUPER_ADMIN"] = 0] = "SUPER_ADMIN";
    UserType[UserType["ADMIN"] = 1] = "ADMIN";
    UserType[UserType["AGENT"] = 2] = "AGENT";
    UserType[UserType["MERCHANT"] = 3] = "MERCHANT";
})(UserType || (exports.UserType = UserType = {}));
let SysUser = class SysUser {
};
exports.SysUser = SysUser;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], SysUser.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'username', length: 64, unique: true }),
    __metadata("design:type", String)
], SysUser.prototype, "username", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'password', length: 255 }),
    __metadata("design:type", String)
], SysUser.prototype, "password", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'nickname', length: 64 }),
    __metadata("design:type", String)
], SysUser.prototype, "nickname", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'email', length: 128, nullable: true }),
    __metadata("design:type", String)
], SysUser.prototype, "email", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'mobile', length: 32, nullable: true }),
    __metadata("design:type", String)
], SysUser.prototype, "mobile", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'avatar', length: 255, nullable: true }),
    __metadata("design:type", String)
], SysUser.prototype, "avatar", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'dept_id', length: 64, nullable: true }),
    __metadata("design:type", String)
], SysUser.prototype, "deptId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'user_type', type: 'tinyint', default: UserType.ADMIN }),
    __metadata("design:type", Number)
], SysUser.prototype, "userType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: UserStatus.ENABLED }),
    __metadata("design:type", Number)
], SysUser.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'last_login_ip', length: 64, nullable: true }),
    __metadata("design:type", String)
], SysUser.prototype, "lastLoginIp", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'last_login_time', nullable: true }),
    __metadata("design:type", Date)
], SysUser.prototype, "lastLoginTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], SysUser.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], SysUser.prototype, "updateTime", void 0);
exports.SysUser = SysUser = __decorate([
    (0, typeorm_1.Entity)('sys_user')
], SysUser);
let SysRole = class SysRole {
};
exports.SysRole = SysRole;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], SysRole.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'role_name', length: 64 }),
    __metadata("design:type", String)
], SysRole.prototype, "roleName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'role_code', length: 64, unique: true }),
    __metadata("design:type", String)
], SysRole.prototype, "roleCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'role_desc', length: 255, nullable: true }),
    __metadata("design:type", String)
], SysRole.prototype, "roleDesc", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], SysRole.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'sort', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], SysRole.prototype, "sort", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], SysRole.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], SysRole.prototype, "updateTime", void 0);
exports.SysRole = SysRole = __decorate([
    (0, typeorm_1.Entity)('sys_role')
], SysRole);
let SysDept = class SysDept {
};
exports.SysDept = SysDept;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], SysDept.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'parent_id', length: 64, default: '0' }),
    __metadata("design:type", String)
], SysDept.prototype, "parentId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'dept_name', length: 64 }),
    __metadata("design:type", String)
], SysDept.prototype, "deptName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'dept_code', length: 64, nullable: true }),
    __metadata("design:type", String)
], SysDept.prototype, "deptCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'leader', length: 64, nullable: true }),
    __metadata("design:type", String)
], SysDept.prototype, "leader", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'phone', length: 32, nullable: true }),
    __metadata("design:type", String)
], SysDept.prototype, "phone", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'email', length: 128, nullable: true }),
    __metadata("design:type", String)
], SysDept.prototype, "email", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], SysDept.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'sort', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], SysDept.prototype, "sort", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], SysDept.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], SysDept.prototype, "updateTime", void 0);
exports.SysDept = SysDept = __decorate([
    (0, typeorm_1.Entity)('sys_dept')
], SysDept);
let SysMenu = class SysMenu {
};
exports.SysMenu = SysMenu;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], SysMenu.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'parent_id', length: 64, default: '0' }),
    __metadata("design:type", String)
], SysMenu.prototype, "parentId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'menu_name', length: 64 }),
    __metadata("design:type", String)
], SysMenu.prototype, "menuName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'menu_code', length: 64, nullable: true }),
    __metadata("design:type", String)
], SysMenu.prototype, "menuCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'icon', length: 64, nullable: true }),
    __metadata("design:type", String)
], SysMenu.prototype, "icon", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'path', length: 255, nullable: true }),
    __metadata("design:type", String)
], SysMenu.prototype, "path", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'component', length: 255, nullable: true }),
    __metadata("design:type", String)
], SysMenu.prototype, "component", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'redirect', length: 255, nullable: true }),
    __metadata("design:type", String)
], SysMenu.prototype, "redirect", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'menu_type', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], SysMenu.prototype, "menuType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'visible', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], SysMenu.prototype, "visible", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], SysMenu.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'perms', length: 255, nullable: true }),
    __metadata("design:type", String)
], SysMenu.prototype, "perms", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'sort', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], SysMenu.prototype, "sort", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'keep_alive', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], SysMenu.prototype, "keepAlive", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], SysMenu.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], SysMenu.prototype, "updateTime", void 0);
exports.SysMenu = SysMenu = __decorate([
    (0, typeorm_1.Entity)('sys_menu')
], SysMenu);
let SysUserRole = class SysUserRole {
};
exports.SysUserRole = SysUserRole;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ name: 'user_id', length: 64 }),
    __metadata("design:type", String)
], SysUserRole.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.PrimaryColumn)({ name: 'role_id', length: 64 }),
    __metadata("design:type", String)
], SysUserRole.prototype, "roleId", void 0);
exports.SysUserRole = SysUserRole = __decorate([
    (0, typeorm_1.Entity)('sys_user_role'),
    (0, typeorm_1.Entity)('sys_user_role')
], SysUserRole);
let SysRoleMenu = class SysRoleMenu {
};
exports.SysRoleMenu = SysRoleMenu;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ name: 'role_id', length: 64 }),
    __metadata("design:type", String)
], SysRoleMenu.prototype, "roleId", void 0);
__decorate([
    (0, typeorm_1.PrimaryColumn)({ name: 'menu_id', length: 64 }),
    __metadata("design:type", String)
], SysRoleMenu.prototype, "menuId", void 0);
exports.SysRoleMenu = SysRoleMenu = __decorate([
    (0, typeorm_1.Entity)('sys_role_menu')
], SysRoleMenu);
let SysDict = class SysDict {
};
exports.SysDict = SysDict;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], SysDict.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'dict_name', length: 64 }),
    __metadata("design:type", String)
], SysDict.prototype, "dictName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'dict_code', length: 64, unique: true }),
    __metadata("design:type", String)
], SysDict.prototype, "dictCode", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'description', length: 255, nullable: true }),
    __metadata("design:type", String)
], SysDict.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], SysDict.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], SysDict.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], SysDict.prototype, "updateTime", void 0);
exports.SysDict = SysDict = __decorate([
    (0, typeorm_1.Entity)('sys_dict')
], SysDict);
let SysDictData = class SysDictData {
};
exports.SysDictData = SysDictData;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], SysDictData.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'dict_id', length: 64 }),
    __metadata("design:type", String)
], SysDictData.prototype, "dictId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'dict_label', length: 64 }),
    __metadata("design:type", String)
], SysDictData.prototype, "dictLabel", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'dict_value', length: 64 }),
    __metadata("design:type", String)
], SysDictData.prototype, "dictValue", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'dict_type', length: 64, nullable: true }),
    __metadata("design:type", String)
], SysDictData.prototype, "dictType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'sort', type: 'int', default: 0 }),
    __metadata("design:type", Number)
], SysDictData.prototype, "sort", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'css_class', length: 64, nullable: true }),
    __metadata("design:type", String)
], SysDictData.prototype, "cssClass", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'list_class', length: 64, nullable: true }),
    __metadata("design:type", String)
], SysDictData.prototype, "listClass", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'is_default', type: 'tinyint', default: 0 }),
    __metadata("design:type", Number)
], SysDictData.prototype, "isDefault", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], SysDictData.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], SysDictData.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], SysDictData.prototype, "updateTime", void 0);
exports.SysDictData = SysDictData = __decorate([
    (0, typeorm_1.Entity)('sys_dict_data')
], SysDictData);
let SysConfig = class SysConfig {
};
exports.SysConfig = SysConfig;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], SysConfig.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'config_name', length: 64 }),
    __metadata("design:type", String)
], SysConfig.prototype, "configName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'config_key', length: 64, unique: true }),
    __metadata("design:type", String)
], SysConfig.prototype, "configKey", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'config_value', type: 'text' }),
    __metadata("design:type", String)
], SysConfig.prototype, "configValue", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'config_type', length: 32, nullable: true }),
    __metadata("design:type", String)
], SysConfig.prototype, "configType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'group_name', length: 64, nullable: true }),
    __metadata("design:type", String)
], SysConfig.prototype, "groupName", void 0);
__decorate([
    (0, typeorm_1.Column)({ length: 255, nullable: true }),
    __metadata("design:type", String)
], SysConfig.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.Column)({ default: 1 }),
    __metadata("design:type", Number)
], SysConfig.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], SysConfig.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], SysConfig.prototype, "updateTime", void 0);
exports.SysConfig = SysConfig = __decorate([
    (0, typeorm_1.Entity)('sys_config')
], SysConfig);
let SysLog = class SysLog {
};
exports.SysLog = SysLog;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], SysLog.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'user_id', length: 64, nullable: true }),
    __metadata("design:type", String)
], SysLog.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'username', length: 64, nullable: true }),
    __metadata("design:type", String)
], SysLog.prototype, "username", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'operation', length: 64 }),
    __metadata("design:type", String)
], SysLog.prototype, "operation", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'method', length: 64 }),
    __metadata("design:type", String)
], SysLog.prototype, "method", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'url', length: 255 }),
    __metadata("design:type", String)
], SysLog.prototype, "url", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'ip', length: 64, nullable: true }),
    __metadata("design:type", String)
], SysLog.prototype, "ip", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'location', length: 128, nullable: true }),
    __metadata("design:type", String)
], SysLog.prototype, "location", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'params', type: 'text', nullable: true }),
    __metadata("design:type", String)
], SysLog.prototype, "params", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'result', type: 'text', nullable: true }),
    __metadata("design:type", String)
], SysLog.prototype, "result", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], SysLog.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'error_msg', type: 'text', nullable: true }),
    __metadata("design:type", String)
], SysLog.prototype, "errorMsg", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'duration', type: 'int', nullable: true }),
    __metadata("design:type", Number)
], SysLog.prototype, "duration", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], SysLog.prototype, "createTime", void 0);
exports.SysLog = SysLog = __decorate([
    (0, typeorm_1.Entity)('sys_log')
], SysLog);
let SysNotice = class SysNotice {
};
exports.SysNotice = SysNotice;
__decorate([
    (0, typeorm_1.PrimaryColumn)({ length: 64 }),
    __metadata("design:type", String)
], SysNotice.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'notice_title', length: 128 }),
    __metadata("design:type", String)
], SysNotice.prototype, "noticeTitle", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'notice_type', type: 'tinyint' }),
    __metadata("design:type", Number)
], SysNotice.prototype, "noticeType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'notice_content', type: 'text' }),
    __metadata("design:type", String)
], SysNotice.prototype, "noticeContent", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 1 }),
    __metadata("design:type", Number)
], SysNotice.prototype, "scope", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'tinyint', default: 0 }),
    __metadata("design:type", Number)
], SysNotice.prototype, "isTop", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'publisher', length: 64, nullable: true }),
    __metadata("design:type", String)
], SysNotice.prototype, "publisher", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'status', type: 'tinyint', default: 1 }),
    __metadata("design:type", Number)
], SysNotice.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'create_time' }),
    __metadata("design:type", Date)
], SysNotice.prototype, "createTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'update_time' }),
    __metadata("design:type", Date)
], SysNotice.prototype, "updateTime", void 0);
exports.SysNotice = SysNotice = __decorate([
    (0, typeorm_1.Entity)('sys_notice')
], SysNotice);
//# sourceMappingURL=sys.entity.js.map
/**
 * DGKJ 支付平台 - 银联支付通道实现
 *
 * 支持: 银联二维码、APP支付、网关支付
 */
import { IPaymentChannel, ChannelConfig, UnifiedPayRequest, UnifiedPayResponse, UnifiedQueryRequest, UnifiedQueryResponse, UnifiedRefundRequest, UnifiedRefundResponse, UnifiedTransferRequest, UnifiedTransferResponse, UnifiedCallbackData, PayWay, ChannelCode } from './interface';
export declare class UnionPayChannel implements IPaymentChannel {
    readonly channelCode = ChannelCode.UNIONPAY;
    readonly channelName = "\u94F6\u8054\u652F\u4ED8";
    readonly supportedPayWays: PayWay[];
    private config;
    private getBaseUrl;
    initialize(config: ChannelConfig): void;
    /**
     * 执行支付
     */
    pay(request: UnifiedPayRequest): Promise<UnifiedPayResponse>;
    /**
     * 查询订单
     */
    query(request: UnifiedQueryRequest): Promise<UnifiedQueryResponse>;
    /**
     * 申请退款
     */
    refund(request: UnifiedRefundRequest): Promise<UnifiedRefundResponse>;
    /**
     * 转账 (暂不支持)
     */
    transfer(request: UnifiedTransferRequest): Promise<UnifiedTransferResponse>;
    /**
     * 验证回调签名
     */
    verifyCallback(data: any, headers: any): Promise<{
        success: boolean;
        errorMsg?: string;
    }>;
    /**
     * 解析回调数据
     */
    parseCallback(data: any): Promise<UnifiedCallbackData>;
    /**
     * 响应回调成功
     */
    responseCallbackSuccess(): string;
    /**
     * 响应回调失败
     */
    responseCallbackFail(): string;
    /**
     * 构建支付参数
     */
    private buildPayParams;
    /**
     * 构建查询参数
     */
    private buildQueryParams;
    /**
     * 构建退款参数
     */
    private buildRefundParams;
    /**
     * 发送请求
     */
    private request;
    /**
     * 构建 Form Data
     */
    private buildFormData;
    /**
     * 解析响应
     */
    private parseResponse;
    /**
     * 获取签名字符串
     */
    private getSignString;
    /**
     * 签名
     */
    private sign;
    /**
     * 验签
     */
    private verifySign;
    /**
     * 生成二维码
     */
    private generateQRCode;
}
declare const _default: UnionPayChannel;
export default _default;
//# sourceMappingURL=unionpay.d.ts.map